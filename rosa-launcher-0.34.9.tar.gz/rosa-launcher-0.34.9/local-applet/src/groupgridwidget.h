/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef __groupgridwidget_h_
#define __groupgridwidget_h_

#include <QGraphicsLinearLayout>
#include <QGraphicsWidget>
#include <QString>
#include <QList>

#include <Plasma/Label>
#include <Plasma/ItemBackground>
#include <Plasma/Separator>
//#include <Plasma/ScrollWidget>
#include "scrollwidget/scrollwidget.h"

#include "config.h"

class GroupGridWidgetGroup;

enum TransferDirection
  {
    TD_UP,
    TD_DOWN,
    TD_LEFT,
    TD_RIGHT
  };

class GroupGridWidget : public QGraphicsWidget
{
  Q_OBJECT
    public:
  GroupGridWidget(QGraphicsItem *parent = 0, Qt::WindowFlags wFlags = 0);
  virtual ~GroupGridWidget();

  GroupGridWidgetGroup* newGroup(QString name);
  bool hasGroup(QString name) { return m_groupNames.contains(name); };
  GroupGridWidgetGroup* getGroup(QString name);
  void removeGroup(QString name);
  void clear();

  void iconSelectionTransfer(TransferDirection transferDirection, int colIndex);

  SWScrollWidget *scrollWidget(void) { return m_scrollWidget; };
  void setScrollWidget(SWScrollWidget *scrollWidget) { m_scrollWidget = scrollWidget; };

  void resetSelection(GroupGridWidgetGroup *exception = NULL);

  void setGroupsMarginsForWidth(qreal newWidth);
  
 public slots:
  void resetFocusBefore(void) { m_hadFocusBefore = false; };
  void forceUpdate(void);
  
 protected:
  void resizeEvent(QGraphicsSceneResizeEvent *event);

  void keyPressEvent(QKeyEvent *event);
  void keyReleaseEvent(QKeyEvent *event);

  void focusInEvent(QFocusEvent *event);

  /*
 public slots:
  void mousePressEvent(QGraphicsSceneMouseEvent *event);
  void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);

  void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
  void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);
  */
  
 private:
  QGraphicsLinearLayout *m_layout;

  QStringList m_groupNames;
  QList<GroupGridWidgetGroup*> m_groups;

  int m_selectedGroup;

  SWScrollWidget *m_scrollWidget;

  bool m_hadFocusBefore;
  
  /*
  QList<QString> m_groupNames;
  QList<QList<QGraphicsWidget*>> m_groups;
  */
};

class GroupGridWidgetGroup : public QGraphicsWidget
{
  Q_OBJECT
    public:
  GroupGridWidgetGroup(QGraphicsItem *parent = 0, Qt::WindowFlags wFlags = 0);
  virtual ~GroupGridWidgetGroup(void);

  QString name() { return m_nameLabel->text(); };
  void setName(QString name) { m_nameLabel->setText(name); };

  void setGroupParent(GroupGridWidget *parent) { m_groupParent = parent; };
  
  // Interface
  QGraphicsWidget* at(int i) { return m_elements.at(i); };
  //int size(void) { return m_elements.size(); };
  int count(void) { return m_elements.count(); };
  bool empty(void) { return m_elements.empty(); };
  void append(QGraphicsWidget* element);
  void clear(void);

  // Icon selection interface
  void iconSelectUp(void);
  void iconSelectDown(void);
  void iconSelectLeft(void);
  void iconSelectRight(void);

  void transferIconSelection(TransferDirection transferDirection, int colIndex);
  void selectIcon(int index);
  
  void launchIcon(void);
  
  void repopulate(void);

  void setMarginsForWidth(qreal newWidth);
  
 public slots:
  void setTargetItem(QGraphicsWidget*);
  void forceUpdate(void);
  void showElements(void);

 protected:
  void hoverLeaveEvent(QGraphicsSceneHoverEvent *evt);
  
 private:
  Plasma::Label *m_nameLabel;
  QGraphicsLinearLayout *m_layout;
  Plasma::Separator * m_separator;
  //QList<QGraphicsLinearLayout*> m_rows;

  GroupGridWidget *m_groupParent;
  
  int m_selectedIconIndex;

  QList<QGraphicsWidget*> m_elements;

  QList<QGraphicsWidget*> m_innerMargins;
  QList<QGraphicsWidget*> m_outerMargins;

  Plasma::ItemBackground *m_hoverIndicator;

  QGraphicsLinearLayout *m_marginLayout;
  QGraphicsLinearLayout *m_marginContentLayout;
};

#endif // __groupgridwidget_h_
