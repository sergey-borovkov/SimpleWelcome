/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef __rosa_launcher_h_
#define __rosa_launcher_h_

#include <KIcon>
#include <KActionCollection>

#include <QGraphicsLinearLayout>
#include <QList>

#include <Plasma/Applet>
#include <Plasma/Svg>
#include <Plasma/Label>
#include <Plasma/DataEngine>
#include <Plasma/RunnerManager>
#include <Plasma/QueryMatch>
#include <Plasma/LineEdit>

#include "tabbar.h"
#include "button.h"

class QSizeF;

class WelcomeWidget;

class ROSA_Launcher : public Plasma::Applet
{
 Q_OBJECT
 public:
  ROSA_Launcher(QObject *parent, const QVariantList &args);
  ~ROSA_Launcher();

  void paintInterface(QPainter *p, const QStyleOptionGraphicsItem *option, const QRect& contentsRect);
  void init();

  Plasma::DataEngine* appsEngine(void) { return m_appsEngine; };

  bool focusNextPrevChild(bool next);
  
 public slots:
  void resizeSelf(void);
  void lockScreen(void);
  void shutdownDialog(void);

  void runSearch(void) {};

  void postSetup(void);
  void setSearchFocus(void);
  void setIconsFocus(void);
  
  void searchTextChanged(const QString &text);
  void showSearchWidget(void);
  void hideSearchWidget(void);

  void clearSearchBar(void);
  void clearSearchBarOnly(void);
  
  void newSearchMatches(const QList<Plasma::QueryMatch> &matches);

  void registerLaunchedApp(QString appName);

  void checkFocus(void);
  
  //void actionTriggered(Qt::MouseButtons mouseButtons, Qt::KeyboardModifiers keyboardModifiers);

 protected:
  void keyPressEvent(QKeyEvent *event);
  void keyReleaseEvent(QKeyEvent *event);
  
 private:
  KIcon m_icon;
  QGraphicsLinearLayout *m_mainLayout;
  TabBar *m_tabBar;
  Plasma::RunnerManager *m_runnerManager;
  Plasma::LineEdit *m_searchBar;
  
  Plasma::DataEngine* m_appsEngine;

  bool m_searchWidgetShown;
  bool m_searchBarClearOnly;
  bool m_searchBarJustCleared;

  WelcomeWidget *m_welcomeWidget;

  QTimer *m_setupTimer;
  KActionCollection *m_actionCollection;
  KAction *m_toggleAction;
};

#endif // __rosa_launcher_h_
