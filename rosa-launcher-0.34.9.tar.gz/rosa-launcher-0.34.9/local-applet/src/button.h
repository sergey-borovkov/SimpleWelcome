/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef __button_h_
#define __button_h_

#include <QGraphicsLinearLayout>
#include <QGraphicsWidget>
#include <QString>
#include <QProcess>
#include <QPoint>
#include <QGraphicsSceneMouseEvent>
#include <QCursor>

#include <KIconLoader>

#include <Plasma/IconWidget>
#include <Plasma/QueryMatch>
#include <Plasma/RunnerManager>

//#include <Plasma/Label>
#include "elidedlabel.h"

class AppButton : public QGraphicsWidget
{
  Q_OBJECT
    public:
  AppButton(QIcon icon, QString name, QString description, QString desktopFile, QGraphicsItem *parent = 0, Qt::WindowFlags wFlags = 0);
  AppButton(QIcon icon, QString name, QString description, Plasma::RunnerManager *manager, const Plasma::QueryMatch *match, QGraphicsItem *parent = 0, Qt::WindowFlags wFlags = 0);
  virtual ~AppButton();

  void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = 0);

 public slots:
  void mousePressEvent(QGraphicsSceneMouseEvent *event);
  void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
  void mouseMoveEvent(QGraphicsSceneMouseEvent *event);

  void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
  void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);

  void runApp(void);

  void forceUpdate(void);
  
 signals:
  void hoverEnter(QGraphicsWidget*);
  void hoverLeave(QGraphicsWidget*);
  void appLaunched(QString);

 private:
  void init(QIcon icon, QString name, QString description);
  
  QGraphicsLinearLayout *m_layout;
  Plasma::IconWidget *m_icon;
  ElidedLabel *m_label;
  QString m_desktopFile;

  QProcess *m_process;

  // Drag 'n Drop
  QPoint m_mousePressPosition;

  // QueryMatch
  Plasma::RunnerManager *m_manager;
  const Plasma::QueryMatch *m_match;

  bool m_firstPaintSkiped;
};

#endif // __button_h_
