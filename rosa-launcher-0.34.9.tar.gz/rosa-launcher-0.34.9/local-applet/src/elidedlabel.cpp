/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "elidedlabel.h"

#include <QFont>
#include <QFontMetrics>
#include <QRegExp>

#include <KDebug>

ElidedLabel::ElidedLabel(QGraphicsWidget *parent)
  : Plasma::Label(parent)
{
  connect(this, SIGNAL(geometryChanged()), this, SLOT(resetText()));
}

ElidedLabel::~ElidedLabel()
{
}

void ElidedLabel::setText(const QString &text)
{
  m_fullText = text;

  resetText();
}

QString ElidedLabel::text() const
{
  return Plasma::Label::text();
}

void ElidedLabel::resetText(void)
{
  QFontMetrics fontMetrics(font());

  int availableWidth = size().width();
  
  int linesAvailable = size().height() / fontMetrics.height() + 1;
  /*
  kDebug() << "Lines count: " << linesAvailable;
  kDebug() << "Height: " << size().height();
  kDebug() << "Font height: " << fontMetrics.height();
  */
  
  QStringList wordList = m_fullText.split(QRegExp("\\b"));

  QStringList lines;
  QString finalText;
  QString currentLine;
  
  currentLine.clear();

  int overflowLine = 0;
  
  for(int i = 0; i < wordList.size(); i++)
    {
      bool lineWasEmpty = currentLine.isEmpty();
      currentLine += wordList[i];
      
      int lineWidth = fontMetrics.boundingRect(currentLine).width();

      if(lineWidth <= availableWidth) // If we are fitting 
        {
          if(i == wordList.size()-1)
    	      lines.append(currentLine);
          continue;
	}
      if(lineWasEmpty) // If single word bigger than availableWidth
        {
          if(overflowLine == 0)
            overflowLine = lines.size() + 1;
        }
      else // If recently added word is redundant
        {
          currentLine.chop(wordList[i].size());
          if( ((i>0) && wordList[i-1].contains(".")) || 
             wordList[i].contains("."))
    	      currentLine.append(" ");
          i--; // To use current word on next line
        }

      lines.append(currentLine);
      currentLine.clear();
    }

  /*
  kDebug() << "Lines: " << lines;
  kDebug() << "OverflowLine: " << overflowLine;
  kDebug() << "----------------------------------------";
  */
  
  // Right side eliding
  if(overflowLine > 0 && overflowLine < linesAvailable)
    {
      QStringList leftPartList(lines.mid(0, overflowLine - 1));
      QString leftPart = leftPartList.join("\n");
      QStringList rightPartList(lines.mid(overflowLine - 1));
      QString rightPart = rightPartList.join("\n");
      rightPart = fontMetrics.elidedText(rightPart, Qt::ElideRight, availableWidth);
  
      finalText = leftPart + rightPart;
    }
  else if(lines.size() > linesAvailable)
    {
      QStringList leftPartList(lines.mid(0, linesAvailable - 1));
      QString leftPart = leftPartList.join("\n");
      QStringList rightPartList(lines.mid(linesAvailable - 1));
      QString rightPart = rightPartList.join("\n");
      rightPart += "...";
      rightPart = fontMetrics.elidedText(rightPart, Qt::ElideRight, availableWidth);
  
      finalText = leftPart + rightPart;
    }
  else
    {
      finalText = lines.join("\n")/*m_fullText*/;
    }
  
  Plasma::Label::setText(finalText);
}

