/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "applicationswidget.h"
#include "groupgridwidget.h"
#include "button.h"

#include <KIcon>
#include <QIcon>
#include <KServiceGroup>
#include <KSycoca>
#include <KDebug>
#include <KSharedConfig>
#include <KConfigGroup>

#include <QVariant>
#include <QTimer>

#include "rosa-launcher.h"

ApplicationsWidget::ApplicationsWidget(QGraphicsItem *parent)
  : SWScrollWidget(parent),
    m_appLaunchReciever(0)
{
  setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
  setOverShoot(false);

  GroupGridWidget *groupGrid = new GroupGridWidget();
  groupGrid->setScrollWidget(this);
  setWidget(groupGrid);

  // Doesn't work..
  //setAlignment(Qt::AlignCenter);

  //kDebug() << "CONTENTSSIZE: " << contentsSize();
  
  // ScrollWheelSpeed
  KSharedConfig::Ptr config = KGlobal::config();
  KConfigGroup *configGroup = new KConfigGroup(config, "General");

  QVariant scrollWheelSpeedVariant(2.0);
  scrollWheelSpeedVariant = configGroup->readEntry("ScrollWheelSpeed", scrollWheelSpeedVariant);

  configGroup->writeEntry("ScrollWheelSpeed", scrollWheelSpeedVariant);
  configGroup->sync();

  m_scrollWheelSpeed = scrollWheelSpeedVariant.toDouble();

  // delete config; // Smart pointer used
  delete configGroup;

  m_repositionNeeded = false;

  QTimer *repositionTimer = new QTimer(this);
  connect(repositionTimer, SIGNAL(timeout()), this, SLOT(repositionIfNeeded()));
  repositionTimer->start(1000);
  
  /*
  GroupGridWidgetGroup *group = groupGrid->newGroup("Office");

  for(int i = 0; i < 35; i++)
    {
      AppButton *button = new AppButton(static_cast<QIcon>(KIcon("face-wink")), QString("Smiley smile ") + QString::number(i), QString("This is Smily. Glad to know U!"), QString("file:///usr/share/applications/kde4/kcalc.desktop"));
      group->append(button);
    }

  group->repopulate();

  group = groupGrid->newGroup("Internet");

  for(int i = 0; i < 31; i++)
    {
      AppButton *button = new AppButton(static_cast<QIcon>(KIcon("face-wink")), QString("Smiley smile ") + QString::number(i), QString("This is Smily. Glad to know U!"), QString("file:///usr/share/applications/kde4/kcalc.desktop"));
      group->append(button);
    }

  group->repopulate();
  */

  //retrieveApps();
  //connectToEngine();
}

ApplicationsWidget::~ApplicationsWidget()
{
}

void ApplicationsWidget::repositionIfNeeded(void)
{
  //kDebug() << "CONTENTSSIZE: " << contentsSize();
  
  if(m_repositionNeeded)
    {
      reposition();
      m_repositionNeeded = false;
    };
}

void ApplicationsWidget::reposition()
{
  if(! m_appEntities.contains("/"))
    return;
  
  AppData *rootEntity = m_appEntities["/"];
  QStringList rootList = (*rootEntity->entries());
  QStringList childrenList;
  QString groupName;
  AppData *group;

  QStringList rootEntities;

  AppData *childEntity;
  AppButton *button;

  m_allDesktopFiles.clear();
  
  // Preparing groupGrid
  GroupGridWidget *gridWidget = static_cast<GroupGridWidget*>(widget());
  gridWidget->clear();

  for(int i = 0; i < rootList.size(); i++)
    {
      groupName = rootList[i];
      if(! m_appEntities.contains(groupName))
        continue;
      
      group = m_appEntities[groupName];

      if(group->isApp())
        {
          rootEntities.append(groupName);
          continue;
        }

      if(! group->display())
        continue;

      childrenList = deepFlaten((*group->entries()));

      if(childrenList.empty())
        continue;
      
      // Creating grid group
      GroupGridWidgetGroup *gridWidgetGroup = gridWidget->newGroup(group->name());

      for(int i = 0; i < childrenList.size(); i++)
        {
          if(! m_appEntities.contains(childrenList[i]))
            continue;

          childEntity = m_appEntities[childrenList[i]];

          if(! childEntity->display())
            continue;

          //button = new AppButton(static_cast<QIcon>(KIcon(childEntity->iconName())), childEntity->name() + "\n" + childEntity->genericName(), childEntity->comment(), childEntity->entryPath());
          button = new AppButton(static_cast<QIcon>(KIcon(childEntity->iconName())), childEntity->name(), childEntity->comment(), childEntity->entryPath());
          if(m_appLaunchReciever != NULL)
            connect(button, SIGNAL(appLaunched(QString)), m_appLaunchReciever, SLOT(registerLaunchedApp(QString)));

          m_allDesktopFiles.append(childEntity->entryPath());
          
          gridWidgetGroup->append(button);
        }

      if(gridWidgetGroup->empty())
        {
          gridWidget->removeGroup(group->name());
        }
      else
        {
          gridWidgetGroup->repopulate();
        }
      
    }
  
  gridWidget->setGroupsMarginsForWidth(gridWidget->size().width());
}

void ApplicationsWidget::setAppsEngine(Plasma::DataEngine* appsEngine)
{
  m_appsEngine = appsEngine;
  m_appsEngine->connectAllSources(this);

  connect(m_appsEngine, SIGNAL(sourceAdded(const QString&)), this, SLOT(sourceAdded(const QString&)));
  connect(m_appsEngine, SIGNAL(sourceRemoved(const QString&)), this, SLOT(sourceRemoved(const QString&)));

  reposition();
}

QStringList ApplicationsWidget::allEntries(void)
{
  /*
  kDebug() << "TESTING OLOLO!";
  kDebug() << deepFlaten(rootList).size();
  kDebug() << deepFlaten(rootList);
  kDebug() << "TESTING OLOLO! END";
  */
  /*
  AppData *rootEntity = m_appEntities["/"];
  QStringList rootList = (*rootEntity->entries());

  return(deepFlaten(rootList));
  */

  return m_allDesktopFiles;
}

void ApplicationsWidget::sourceAdded(const QString &name)
{
  //kDebug() << "SOURCE ADDED: " << name;
  m_appsEngine->connectSource(name, this);
}

void ApplicationsWidget::sourceRemoved(const QString &name)
{
  //kDebug() << "SOURCE REMOVED: " << name;
  m_appsEngine->disconnectSource(name, this);
  m_appEntities.remove(name);

  m_repositionNeeded = true;
}

void ApplicationsWidget::dataUpdated(const QString &name, const Plasma::DataEngine::Data &data)
{
  //kDebug() << "DATA UPDATED: " << name;
  AppData *appData = new AppData(name, data);

  if(appData->valid())  
    m_appEntities.insert(name, appData);

  m_repositionNeeded = true;
}

QStringList ApplicationsWidget::deepFlaten(QStringList entityNames)
{
  QStringList returnList;
  QString entityName;
  AppData *entity;

  for(int i = 0; i < entityNames.size(); i++)
    {
      entityName = entityNames[i];

      if(! m_appEntities.contains(entityName))
        continue;

      entity = m_appEntities[entityName];

      if(entity->isApp())
        returnList.append(entityName);
      else
        {
          returnList += deepFlaten(QStringList((*entity->entries())));
        }
    }

  return returnList;
}

void ApplicationsWidget::wheelEvent(QGraphicsSceneWheelEvent *event)
{
  event->setDelta(event->delta() * m_scrollWheelSpeed);
  
  SWScrollWidget::wheelEvent(event);
}

void ApplicationsWidget::tabActivated(void)
{
  setScrollPosition(QPointF(0,0));
}


// ----------------------------------------------------------------------------------------
// AppData class
AppData::AppData(QString sourceName, const Plasma::DataEngine::Data &data) : m_valid(true)
{
  m_sourceName = sourceName;
  
  if(data.contains("isApp"))
    m_isApp = data["isApp"].toBool();
  else
    m_valid = false;

  if(data.contains("name"))
     m_name = data["name"].toString();

  if(data.contains("display"))
    m_display = data["display"].toBool();
  else
    m_display = false;

  if(data.contains("iconName"))
    m_iconName = data["iconName"].toString();

  if(data.contains("comment"))
    m_comment = data["comment"].toString();


  if(data.contains("genericName"))
    m_genericName = data["genericName"].toString();

  if(data.contains("menuId"))
    m_menuId = data["menuId"].toString();

  if(data.contains("entryPath"))
    m_entryPath = data["entryPath"].toString();


  if(data.contains("entries"))
      m_entries = data["entries"].toStringList();

}

/*
void recursiveRetrieval(KServiceGroup* group)
{
  if (!group || !group->isValid()) return;

  KServiceGroup::List list = group->entries();

  kDebug() << "Submerging: " << group->name().toLatin1();
 
  // Iterate over all entries in the group
  for( KServiceGroup::List::Iterator it = list.begin();
       it != list.end(); it++)
    {
      KSycocaEntry *p = (*it).data();
      if (p->isType(KST_KService))
        {
          KService *s = static_cast<KService *>(p);
          //printf("Name = %s\n", s->name().toLatin1());
          //kDebug() << "Entry: " << s->name().toLatin1();
        }
      else if (p->isType(KST_KServiceGroup))
        {
          KServiceGroup *g = static_cast<KServiceGroup *>(p);
          // Sub group ...
          recursiveRetrieval(g);
        }
    }

  kDebug() << "Emerging: " << group->name().toLatin1();
}

void ApplicationsWidget::retrieveApps()
{
  // Start from root group
  KServiceGroup *group = KServiceGroup::root()->data();

  recursiveRetrieval(group);
}
*/
