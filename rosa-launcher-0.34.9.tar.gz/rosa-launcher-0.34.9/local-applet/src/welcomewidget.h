/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef __welcomewidget_h_
#define __welcomewidget_h_

#include <QGraphicsLinearLayout>
#include <QGraphicsWidget>
#include <QTimer>

//#include <Plasma/ScrollWidget>
#include <KDebug>

#include "scrollwidget/scrollwidget.h"
#include "applicationswidget.h"

class WelcomeWidget : public SWScrollWidget
{
  Q_OBJECT
    public:
  WelcomeWidget(QGraphicsItem *parent = 0);
  virtual ~WelcomeWidget();

  void setApplicationsWidget(ApplicationsWidget *applicationsWidget) { m_applicationsWidget = applicationsWidget; };

  void reposition(void);

 public slots:
  void tabActivated(void) { reposition(); };
  void registerLaunchedApp(QString desktopFile);
  void checkRecentApps(void);
  
  /*
 public slots:
  void mousePressEvent(QGraphicsSceneMouseEvent *event);
  void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);

  void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
  void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);
  */
  
 private:

  void readRecentApps(void);
  void writeRecentApps(void);

  QStringList m_hiddenPlaces;
  QStringList m_recentApplications;

  QStringList m_lastRecentApplications;
  QStringList m_lastPlaces;
  QStringList m_lastRecentDocuments;

  ApplicationsWidget *m_applicationsWidget;

  QTimer *m_checkRecentAppsTimer;
};

#endif // __welcomewidget_h_
