/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "groupgridwidget.h"

#include <QGraphicsSceneResizeEvent>
#include <QFont>
#include <QTimer>

#include <KDebug>

#include "button.h"

GroupGridWidget::GroupGridWidget(QGraphicsItem *parent, Qt::WindowFlags wFlags)
  : QGraphicsWidget(parent, wFlags),
    m_selectedGroup(0),
    m_scrollWidget(0),
    m_hadFocusBefore(false)
{
  m_layout = new QGraphicsLinearLayout(Qt::Vertical);

  setLayout(m_layout);

  m_layout->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
  setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
  m_layout->setInstantInvalidatePropagation(true); // Need Qt 4.7.4

  setFlag(QGraphicsItem::ItemIsFocusable, true);
  setData(0, 2);

  QTimer::singleShot(0, this, SLOT(forceUpdate()));
  connect(this, SIGNAL(visibleChanged()), this, SLOT(forceUpdate()));
  connect(this, SIGNAL(enabledChanged()), this, SLOT(forceUpdate()));
  connect(this, SIGNAL(opacityChanged()), this, SLOT(forceUpdate()));
  connect(this, SIGNAL(parentChanged()), this, SLOT(forceUpdate()));
}

GroupGridWidget::~GroupGridWidget()
{
  clear();
}

void GroupGridWidget::forceUpdate(void)
{
  adjustSize();
  update();
  updateGeometry();
}

GroupGridWidgetGroup* GroupGridWidget::newGroup(QString name)
{
  GroupGridWidgetGroup *group = new GroupGridWidgetGroup();
  m_groupNames.append(name);
  m_groups.append(group);

  m_layout->addItem(group);

  group->setName(name);
  group->setGroupParent(this);

  m_hadFocusBefore = false;

  return group;
}

GroupGridWidgetGroup* GroupGridWidget::getGroup(QString name)
{
  if(m_groupNames.contains(name))
    {
      return m_groups[m_groupNames.indexOf(name)];
    }
  else
    {
      return static_cast<GroupGridWidgetGroup*>(NULL);
    };
};
 
void GroupGridWidget::removeGroup(QString name)
{
  int index = m_groupNames.indexOf(name);

  GroupGridWidgetGroup* group = m_groups[index];

  m_layout->removeItem(group);
  group->deleteLater();
  m_groups.removeAt(index);
  m_groupNames.removeAt(index);

  m_hadFocusBefore = false;
}

void GroupGridWidget::clear(void)
{
  while(m_groups.size() > 0)
    {
      GroupGridWidgetGroup* group = m_groups[0];

      m_layout->removeItem(group);
      group->deleteLater();
      //delete group;
      m_groups.removeAt(0);
      m_groupNames.removeAt(0);
    }
  m_hadFocusBefore = false;

  QSizeF newSize = size();
  adjustSize();
  newSize.setHeight(size().height());
  resize(newSize);
}

void GroupGridWidget::setGroupsMarginsForWidth(qreal newWidth)
{
  for(int i = 0; i < m_groups.size(); i++)
    {
      m_groups[i]->setMarginsForWidth(newWidth);
    }
}

void GroupGridWidget::resizeEvent(QGraphicsSceneResizeEvent *event)
{
  //kDebug() << "Resize event, from " << event->oldSize() << " to " << event->newSize();

  setGroupsMarginsForWidth(event->newSize().width());
}



void GroupGridWidget::keyPressEvent(QKeyEvent *event)
{
  switch(event->key())
    {
    case Qt::Key_Up:
      m_groups[m_selectedGroup]->iconSelectUp();
      event->accept();
      break;
    case Qt::Key_Down:
      m_groups[m_selectedGroup]->iconSelectDown();
      event->accept();
      break;
    case Qt::Key_Left:
      m_groups[m_selectedGroup]->iconSelectLeft();
      event->accept();
      break;
    case Qt::Key_Right:
      m_groups[m_selectedGroup]->iconSelectRight();
      event->accept();
      break;
    case Qt::Key_Enter:
    case Qt::Key_Return:
      m_groups[m_selectedGroup]->launchIcon();
      break;
    default:
      event->ignore();
    }
  
}

void GroupGridWidget::keyReleaseEvent(QKeyEvent *event)
{
  Q_UNUSED(event);
}

void GroupGridWidget::focusInEvent(QFocusEvent *event)
{
  //kDebug() << "Got a focusInEvent";
  Q_UNUSED(event);

  if((! m_hadFocusBefore) && m_groups.size() && m_groups[0]->count())
    {
      m_groups[0]->selectIcon(0);
      m_hadFocusBefore = true;
    }

}

void GroupGridWidget::resetSelection(GroupGridWidgetGroup *exception)
{
  for(int i = 0; i < m_groups.size(); i++)
    {
      if(exception != NULL && m_groups[i] == exception)
        continue;
      
      m_groups[i]->setTargetItem(NULL);
    }

}


void GroupGridWidget::iconSelectionTransfer(TransferDirection transferDirection, int colIndex)
{
  //kDebug() << "transferDirection called: " << transferDirection << colIndex;

  m_groups[m_selectedGroup]->setTargetItem(0);

  if(transferDirection == TD_UP || transferDirection == TD_LEFT)
    {
      m_selectedGroup--;

      if(m_selectedGroup < 0)
        m_selectedGroup = m_groups.size() - 1;

      m_groups[m_selectedGroup]->transferIconSelection(transferDirection, colIndex);
    }
  else
    {
      m_selectedGroup++;

      if(m_selectedGroup >= m_groups.size())
        m_selectedGroup = 0;

      m_groups[m_selectedGroup]->transferIconSelection(transferDirection, colIndex);
    }
}

// -----------------------------------------------------------
// GroupGridWidgetGroup

GroupGridWidgetGroup::GroupGridWidgetGroup(QGraphicsItem *parent, Qt::WindowFlags wFlags)
  : QGraphicsWidget(parent, wFlags),
    m_marginLayout(0),
    m_marginContentLayout(0)
{
  m_layout = new QGraphicsLinearLayout(Qt::Vertical);

  setLayout(m_layout);

  m_layout->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
  setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);

  m_layout->setInstantInvalidatePropagation(true); // Need Qt 4.7.4
  
  m_nameLabel = new Plasma::Label();
  m_nameLabel->setFlag(QGraphicsItem::ItemIsFocusable, false);
  //m_nameLabel->setStyleSheet("font: bold 16px");
  QFont labelFont;
  labelFont.setPointSize(11);
  labelFont.setBold(true);
  m_nameLabel->setFont(labelFont);
  
  m_layout->addItem(m_nameLabel);

  m_separator = new Plasma::Separator();
  m_layout->addItem(m_separator);

  setAcceptHoverEvents(true);
  m_hoverIndicator = new Plasma::ItemBackground(this);
  m_hoverIndicator->setZValue(-100);
  m_hoverIndicator->hide();

  m_selectedIconIndex = 0;

  QTimer::singleShot(0, this, SLOT(forceUpdate()));
  connect(this, SIGNAL(visibleChanged()), this, SLOT(forceUpdate()));
  connect(this, SIGNAL(enabledChanged()), this, SLOT(forceUpdate()));
  connect(this, SIGNAL(opacityChanged()), this, SLOT(forceUpdate()));
  connect(this, SIGNAL(parentChanged()), this, SLOT(forceUpdate()));

}

GroupGridWidgetGroup::~GroupGridWidgetGroup()
{
  clear();
  
  if(m_layout)
    while(m_layout->count())
      {
        m_layout->removeAt(0);
      }

  delete m_nameLabel;
  delete m_hoverIndicator;
  delete m_separator;
}

void GroupGridWidgetGroup::forceUpdate(void)
{
  adjustSize();
  update();
  updateGeometry();
}

void GroupGridWidgetGroup::iconSelectUp(void)
{
  int newIndex = m_selectedIconIndex - ICONS_IN_A_ROW;
  //int iconsInLastRow = m_elements.size() % ICONS_IN_A_ROW;
  
  if(newIndex >= 0) // If new selection is in same group
    {
      selectIcon(newIndex);
    }
  else
    {
      int colIndex = m_selectedIconIndex % ICONS_IN_A_ROW;
      m_groupParent->iconSelectionTransfer(TD_UP, colIndex);
    }
}

void GroupGridWidgetGroup::iconSelectDown(void)
{
  int newIndex = m_selectedIconIndex + ICONS_IN_A_ROW;
  //int iconsInLastRow = m_elements.size() % ICONS_IN_A_ROW;

  if(newIndex < m_elements.size()) // If new selection is in same group
    {
      selectIcon(newIndex);
    }
  else
    {
      int colIndex = m_selectedIconIndex % ICONS_IN_A_ROW;
      m_groupParent->iconSelectionTransfer(TD_DOWN, colIndex);
    }
}

void GroupGridWidgetGroup::iconSelectLeft(void)
{
  int newIndex = m_selectedIconIndex - 1;
  //int iconsInLastRow = m_elements.size() % ICONS_IN_A_ROW;

  if(newIndex >= 0) // If new selection is in same group
    {
      selectIcon(newIndex);
    }
  else
    {
      int colIndex = m_selectedIconIndex % ICONS_IN_A_ROW;
      m_groupParent->iconSelectionTransfer(TD_LEFT, colIndex);
    }
}

void GroupGridWidgetGroup::iconSelectRight(void)
{
  int newIndex = m_selectedIconIndex + 1;
  //int iconsInLastRow = m_elements.size() % ICONS_IN_A_ROW;

  if(newIndex < m_elements.size()) // If new selection is in same group
    {
      selectIcon(newIndex);
    }
  else
    {
      int colIndex = m_selectedIconIndex % ICONS_IN_A_ROW;
      m_groupParent->iconSelectionTransfer(TD_RIGHT, colIndex);
    }
}

void GroupGridWidgetGroup::transferIconSelection(TransferDirection transferDirection, int colIndex)
{
  if(m_elements.size() == 0)
    return;

  int lastIconIndex = (m_elements.size() - 1);

  int rows = lastIconIndex / ICONS_IN_A_ROW + 1;
  int lastIconColIndex = lastIconIndex % ICONS_IN_A_ROW;

  
  switch(transferDirection)
    {
    case TD_RIGHT:
      selectIcon(0);
      break;
    case TD_LEFT:
      selectIcon(m_elements.size() - 1);
      break;
    case TD_DOWN:
      if(rows > 1)
        selectIcon(colIndex);
      else if(colIndex <= lastIconColIndex)
        selectIcon(colIndex);
      else
        selectIcon(lastIconColIndex);
      break;
    case TD_UP:
      if(colIndex <= lastIconColIndex)
        selectIcon((rows - 1) * ICONS_IN_A_ROW + colIndex);
      else
        selectIcon(lastIconIndex);
      break;
    }
}


void GroupGridWidgetGroup::selectIcon(int index)
{
  m_selectedIconIndex = index;
  setTargetItem(m_elements[index]);

  if(m_groupParent->scrollWidget())
    m_groupParent->scrollWidget()->ensureItemVisible(static_cast<QGraphicsItem*>(m_elements[index]));
}

void GroupGridWidgetGroup::launchIcon(void)
{
  AppButton *button = dynamic_cast<AppButton*>(m_elements[m_selectedIconIndex]);

  if(button)
      button->runApp();
}

void GroupGridWidgetGroup::append(QGraphicsWidget* element)
{
  m_elements.append(element);

  //kDebug() << "ELEMENTS: " << m_elements.size();
  
  connect(element, SIGNAL(hoverEnter(QGraphicsWidget*)), this, SLOT(setTargetItem(QGraphicsWidget*)));
};

void GroupGridWidgetGroup::clear(void)
{
  QGraphicsLinearLayout *row;

  if(m_marginContentLayout)
    while(m_marginContentLayout->count())
      {
        row = static_cast<QGraphicsLinearLayout*>(m_marginContentLayout->itemAt(0));

        while(row->count())
          {
            QGraphicsLayoutItem *item = row->itemAt(0);
            row->removeAt(0);
            delete item;
          }

        m_marginContentLayout->removeAt(0);
        delete row;
      }
  
  m_innerMargins.clear();

  m_elements.clear();
  
  while(m_outerMargins.count())
    {
      QGraphicsWidget *margin = m_outerMargins.at(0);
      m_outerMargins.removeAt(0);

      delete margin;
    }

  m_selectedIconIndex = 0;  
};

void GroupGridWidgetGroup::setTargetItem(QGraphicsWidget* item)
{
  if(item != NULL)
    m_groupParent->resetSelection(this);
  
  m_hoverIndicator->setTargetItem(item);
}

void GroupGridWidgetGroup::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
  Q_UNUSED(event);
  m_hoverIndicator->setTargetItem(NULL);
}

void GroupGridWidgetGroup::repopulate(void)
{
  //kDebug() << "REPOPULATING";
  //kDebug() << "Layout count: " << m_layout->count();
  //kDebug() << "Elements count: " << m_elements.size();
  QGraphicsLinearLayout *row;

  for(int i = 0; i < m_elements.count(); i++)
    {
      m_elements[i]->setVisible(false);
    }
  
  if(m_layout->count() > 2 && m_marginLayout && m_marginContentLayout) // Checking if main layout is populated
    {
      /*
      //kDebug() << "Getting marginLayout";
      marginLayout = static_cast<QGraphicsLinearLayout*>(m_layout->itemAt(2));
      //kDebug() << "Getting marginContentLayout -- " << marginLayout->count();
      marginContentLayout = static_cast<QGraphicsLinearLayout*>(marginLayout->itemAt(1));
      //kDebug() << "Done";

      //kDebug() << marginContentLayout->count();
      */
      
      while(m_marginContentLayout->count() > 0)
        {
          row = static_cast<QGraphicsLinearLayout*>(m_marginContentLayout->itemAt(0));
          
          while(row->count())
            {
              //QGraphicsLayoutItem *item = row->itemAt(0);
              row->removeAt(0);
              //delete item;
            }
          
          m_marginContentLayout->removeAt(0); // Removing rows
          delete row;
        }

      row = NULL;

      //kDebug() << "Done2";

      m_marginLayout->removeAt(1); // Removing marginContentLayout
      m_layout->removeAt(2); // Removing marginLayout

      delete m_marginContentLayout;
      delete m_marginLayout;
            
      //kDebug() << "Done3";
    }

  //kDebug() << "Done4";

  /*
  // Removing margin objects
  while(m_innerMargins.count())
    {
      QGraphicsWidget *margin = m_innerMargins.at(0);
      m_innerMargins.removeAt(0);

      delete margin;
    }
  */
  
  while(m_outerMargins.count())
    {
      QGraphicsWidget *margin = m_outerMargins.at(0);
      m_outerMargins.removeAt(0);

      delete margin;
    }
  
  // Layout for horizontal margins
  m_marginLayout = new QGraphicsLinearLayout(Qt::Horizontal);
  m_marginContentLayout = new QGraphicsLinearLayout(Qt::Vertical);
  m_marginLayout->setInstantInvalidatePropagation(true); // Need Qt 4.7.4
  m_marginContentLayout->setInstantInvalidatePropagation(true); // Need Qt 4.7.4


  // Left margin widget
  QGraphicsWidget *leftMarginWidget = new QGraphicsWidget();
  m_outerMargins.append(leftMarginWidget);
  
  // Right margin widget
  QGraphicsWidget *rightMarginWidget = new QGraphicsWidget();
  m_outerMargins.append(rightMarginWidget);
  
  m_marginLayout->addItem(leftMarginWidget);
  m_marginLayout->addItem(m_marginContentLayout);
  m_marginLayout->addItem(rightMarginWidget);

  m_layout->addItem(m_marginLayout);

  row = NULL;
  for(int i = 0; i < m_elements.size(); i++)
    {
      //kDebug() << "i: " << i;
      //kDebug() << "i mod " << ICONS_IN_A_ROW << ": " << i % ICONS_IN_A_ROW;
      if(i % ICONS_IN_A_ROW == 0)
        {
          row = new QGraphicsLinearLayout(Qt::Horizontal);
          row->setInstantInvalidatePropagation(true); // Need Qt 4.7.4
          m_marginContentLayout->addItem(row);
          row->setContentsMargins(0, 0, 0, 0);
        }
      else
        {
          // inter icon margin widget
          QGraphicsWidget *marginWidget = new QGraphicsWidget();
          m_innerMargins.append(marginWidget);
          //kDebug() << marginWidget->minimumSize();
          row->addItem(marginWidget);
        }
      //kDebug() << "Adding element " << i;
      row->addItem(m_elements[i]);
    }

  int iconsInLastRow = m_elements.size() % ICONS_IN_A_ROW;
  int fillersNeeded = iconsInLastRow != 0 ? ICONS_IN_A_ROW - iconsInLastRow : 0;

  //kDebug() << name() << "FillersNeeded: " << fillersNeeded;
  

  // Fillers
  for(int i = 0; i < fillersNeeded; i++)
    {
      // inter icon margin widget
      //kDebug() << "Adding margin";
      QGraphicsWidget *marginWidget = new QGraphicsWidget();
      m_innerMargins.append(marginWidget);
      //kDebug() << marginWidget->minimumSize();
      row->addItem(marginWidget);

      // Filler
      //kDebug() << "Adding filler";
      QGraphicsWidget *fillerWidget = new QGraphicsWidget();
      //fillerWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Minimum);
      fillerWidget->setMinimumWidth(ICON_SIZE + BUTTON_MARGIN * 2 + BUTTON_MARGIN * 2);
      fillerWidget->setMaximumWidth(ICON_SIZE + BUTTON_MARGIN * 2 + BUTTON_MARGIN * 2);
      row->addItem(fillerWidget);
    }

  QTimer::singleShot(0, this, SLOT(showElements()));
}

void GroupGridWidgetGroup::showElements(void)
{
    for(int i = 0; i < m_elements.count(); i++)
    {
      m_elements[i]->setVisible(true);
    }
}

void GroupGridWidgetGroup::setMarginsForWidth(qreal newWidth)
{
  //kDebug() << name() << ": got margins resize request for size - " << newSize;

  int outerMarginSize = INITIAL_OUTERMARGIN_WIDTH;
  
  if(newWidth > WIDTH_BORDERLINE + INITIAL_OUTERMARGIN_WIDTH * 2)
    {
      outerMarginSize = (newWidth - WIDTH_BORDERLINE) / 2;
    }

  //kDebug() << newSize.width() << " " << WIDTH_BORDERLINE << " " << outerMarginSize;
  
  for(int i = 0; i < m_outerMargins.size(); i++)
    {
      //m_outerMargins[i]->setMinimumWidth(outerMarginSize);
      m_outerMargins[i]->setMaximumWidth(outerMarginSize);
      m_outerMargins[i]->setPreferredWidth(outerMarginSize);
    }

  for(int i = 0; i < m_innerMargins.size(); i++)
    {
      m_innerMargins[i]->setMinimumWidth(0);
    }
  
}
