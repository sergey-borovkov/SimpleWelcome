/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "rosa-launcher.h"

#include <QtDBus/QtDBus>

#include <iostream>

#include <QPainter>
#include <QFontMetrics>
#include <QSizeF>
#include <QDesktopWidget>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsWidget>
#include <QTabBar>
#include <QIcon>
#include <QObject>
#include <QApplication>
#include <QAction>
#include <QKeySequence>

#include <Plasma/TabBar>
#include <Plasma/Separator>
#include <Plasma/IconWidget>
#include <Plasma/Label>
#include <Plasma/ScrollWidget>

#include <KUser>
#include <KIcon>
#include <KGlobalAccel>

#include <plasma/svg.h>
#include <plasma/theme.h>

#include <klocalizedstring.h>

#include "welcomewidget.h"
#include "applicationswidget.h"
#include "searchwidget.h"
#include "lnswidget.h"
#include "searchbar.h"

#ifdef TIMEFRAME_ENABLED
#include "timeframe/timeframe.h"
#endif

ROSA_Launcher::ROSA_Launcher(QObject *parent, const QVariantList &args)
  : Plasma::Applet(parent, args),
    m_icon("document"),
    m_searchWidgetShown(false),
    m_searchBarJustCleared(false)
{
  setBackgroundHints(NoBackground);
  //setBackgroundHints(DefaultBackground);
  setContentsMargins(8, 8, 8, 8);
  //resize(200, 200);
}

ROSA_Launcher::~ROSA_Launcher()
{
  if(hasFailedToLaunch()) {
    // Cleanup
  } else {
    // Save settings
  }
}

void ROSA_Launcher::init()
{
  m_mainLayout = new QGraphicsLinearLayout(Qt::Vertical, this);
  /*
  Plasma::Label *label = new Plasma::Label(this);

  label->setText("Hello world!!!");
  m_mainLayout->addItem(label);
  */

  setAcceptHoverEvents(true);

  QGraphicsLinearLayout* topSection = new QGraphicsLinearLayout(Qt::Horizontal);
  topSection->setMaximumHeight(64);
  topSection->setMinimumHeight(64);

  /*
  Plasma::TabBar* tabBar = new Plasma::TabBar();
  tabBar->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Minimum);
  tabBar->nativeWidget()->setShape(QTabBar::RoundedSouth);
  tabBar->addTab("Welcome");
  tabBar->addTab("Applications");
  tabBar->addTab("Documents");
  */
  m_tabBar = new TabBar();

  m_tabBar->setApplet(this);
  
  /*
  Plasma::Label *label = new Plasma::Label();
  label->setText("Welcome");
  label->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
  label->setAlignment(Qt::AlignCenter);
  m_tabBar->addTab(QString("Welcome"), label);
  */




  /*

  Plasma::ScrollWidget *scrollWidget = new Plasma::ScrollWidget();
  QGraphicsWidget *scrollWidgetProxy = new QGraphicsWidget();
  QGraphicsLinearLayout *scrollWidgetLayout = new QGraphicsLinearLayout(Qt::Vertical);
  scrollWidgetProxy->setLayout(scrollWidgetLayout);
  scrollWidget->setWidget(scrollWidgetProxy);
  scrollWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);

  Plasma::Label *label = new Plasma::Label();
  label->setText("Recent Applications");
  label->setStyleSheet("color: #fff; font: bold 12px; margin-top: 8px; margin-bottom: 2px;");
  scrollWidgetLayout->addItem(label);
  Plasma::Separator *separator = new Plasma::Separator();
  scrollWidgetLayout->addItem(separator);

  
  AppButton *appButton = new AppButton(static_cast<QIcon>(KIcon("face-wink")), QString("Smily"), QString("This is Smily. Glad to know U!"), QString("file:///usr/share/applications/kde4/kcalc.desktop"));
  scrollWidgetLayout->addItem(appButton);
  scrollWidgetLayout->addStretch();
  */

  SearchWidget *searchWidget = new SearchWidget();
  searchWidget->setAppLaunchReciever(this);
  m_tabBar->addTab(QString(i18n("Search")), searchWidget, true);
  

  
  WelcomeWidget *welcomeWidget = new WelcomeWidget();
  m_welcomeWidget = welcomeWidget;
  m_tabBar->addTab(QString(i18n("Welcome")), welcomeWidget);
  m_welcomeWidget->setFlag(QGraphicsItem::ItemIsFocusable, false);

  /*
  Plasma::Label *label = new Plasma::Label();
  label->setText("Applications");
  label->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
  label->setAlignment(Qt::AlignCenter);
  */

  ApplicationsWidget *applicationsWidget = new ApplicationsWidget();
  applicationsWidget->setAppLaunchReciever(welcomeWidget);
  welcomeWidget->setApplicationsWidget(applicationsWidget);
  m_tabBar->addTab(QString(i18n("Applications")), applicationsWidget);

  /*
  Plasma::Label *label = new Plasma::Label();
  label->setText("Documents");
  label->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
  label->setAlignment(Qt::AlignCenter);
  m_tabBar->addTab(QString("Documents"), label);
  */

#ifdef TIMEFRAME_ENABLED
  // TimeFrame tab
  QTimeFrame *timeFrame = new QTimeFrame();
  m_tabBar->addTab(QString(i18n("TimeFrame")), timeFrame);
#endif
  
  Plasma::Separator *sep = new Plasma::Separator();
  
  m_mainLayout->addItem(topSection);
  m_mainLayout->addItem(sep);
  //m_mainLayout->addStretch();
  m_mainLayout->addItem(m_tabBar);
  m_tabBar->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

  /*
  Plasma::TabBar *tabBar = new Plasma::TabBar();
  tabBar->addTab("Bla1");
  tabBar->addTab("Bla2");
  tabBar->addTab("Bla3");

  tabBar->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Minimum);
  m_mainLayout->addItem(tabBar);
  */
  

  // TopSection
  KUser *userInfoData = new KUser();

  // User icon
  Plasma::IconWidget *userIcon = new Plasma::IconWidget();
  QString iconFilename = userInfoData->faceIconPath();

  if(! iconFilename.isEmpty()) {
    userIcon->setIcon(QIcon(iconFilename));
  }
  else {
    //userIcon->setIcon(KIcon("face-wink"));
    userIcon->setIcon(KIcon("/usr/share/faces/default.png"));
  }

  userIcon->setPreferredHeight(64);
  userIcon->setPreferredWidth(64);

  userIcon->setFlag(QGraphicsItem::ItemIsFocusable, false);
  topSection->addItem(userIcon);

  // Nameplate
  QGraphicsLinearLayout *userInfoLayout = new QGraphicsLinearLayout(Qt::Vertical);
  userInfoLayout->setContentsMargins(4, 4, 0, 0);
  Plasma::Label *userInfoUsername = new Plasma::Label();
  QFont labelFont;
  labelFont.setPointSize(16);
  //labelFont.setBold(true);
  userInfoUsername->setFont(labelFont);

  userInfoUsername->setFlag(QGraphicsItem::ItemIsFocusable, false);
  userInfoLayout->addItem(userInfoUsername);
  //userInfoLayout->addStretch();
  userInfoLayout->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Expanding);
  //userInfoLayout->setPreferredWidth(150);
  QString username = userInfoData->fullName();

  if(username.isEmpty()) {
    username = userInfoData->loginName();
  }

  userInfoUsername->setText(username);
  userInfoUsername->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
  topSection->addItem(userInfoLayout);

  // Search bar
  QGraphicsLinearLayout *searchBarLayout = new QGraphicsLinearLayout(Qt::Vertical);
  m_searchBar = new SearchBar();
  
  searchBarLayout->setSizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::Minimum);

  searchBarLayout->addStretch();
  searchBarLayout->addItem(m_searchBar);
  searchBarLayout->addStretch();

  topSection->addStretch();
  topSection->addItem(searchBarLayout);
  topSection->addStretch();

  connect(m_tabBar->nativeWidget(), SIGNAL(currentChanged(int)), this, SLOT(clearSearchBarOnly()));

  // New buttons
  LNSWidget *lnsButtons = new LNSWidget();
  lnsButtons->setAcceptHoverEvents(true);

  connect(lnsButtons, SIGNAL(lockButtonClicked()), this, SLOT(lockScreen()));
  connect(lnsButtons, SIGNAL(offButtonClicked()), this, SLOT(shutdownDialog()));

  lnsButtons->setFlag(QGraphicsItem::ItemIsFocusable, false);
  topSection->addItem(lnsButtons);
  
  // Buttons
  /* // Configure button
  Plasma::IconWidget *buttonConfigure = new Plasma::IconWidget();

  buttonConfigure->setIcon(KIcon("configure"));
  topSection->addItem(buttonConfigure);

  connect(buttonConfigure, SIGNAL(clicked()), this, SLOT(showConfigurationInterface()));
  */

  // Replaced by LNSWidget
  /*
  Plasma::IconWidget *buttonLock = new Plasma::IconWidget();

  buttonLock->setIcon(KIcon("system-lock-screen"));
  topSection->addItem(buttonLock);

  connect(buttonLock, SIGNAL(clicked()), this, SLOT(lockScreen()));

  Plasma::IconWidget *buttonShutdown = new Plasma::IconWidget();

  buttonShutdown->setIcon(KIcon("system-shutdown"));
  topSection->addItem(buttonShutdown);

  connect(buttonShutdown, SIGNAL(clicked()), this, SLOT(shutdownDialog()));
  */
  
  // DataEngine
  m_appsEngine = dataEngine("apps");
  applicationsWidget->setAppsEngine(m_appsEngine);

  // Runners
  m_runnerManager = new Plasma::RunnerManager();
  kDebug() << "RUNNERS:";
  QList<KPluginInfo> availableRunners = Plasma::RunnerManager::listRunnerInfo();

  /*
  for(int i = 0; i < availableRunners.size(); i++)
    {
      kDebug() << "--------";
      kDebug() << "PluginName:" << availableRunners[i].pluginName();
      kDebug() << "Name:" << availableRunners[i].name();
      //kDebug() << "Version:" << availableRunners[i].version();
      //kDebug() << "Author:" << availableRunners[i].author();
      kDebug() << "Comment:" << availableRunners[i].comment();
      //kDebug() << "Website: " << availableRunners[i].website();      
    }
  */

  QStringList activeRunners;
  activeRunners << "recentdocuments"
    // << "nepomuksearch"
    // << "services"
                << "shell"
                << "rosa-services";

  m_runnerManager->setAllowedRunners(activeRunners);

  searchWidget->registerRunnerManager(m_runnerManager);
  
  //connect(m_runnerManager, SIGNAL(matchesChanged(const QList<Plasma::QueryMatch> &)), this, SLOT(newSearchMatches(const QList<Plasma::QueryMatch> &)));
  
  //m_runnerManager->launchQuery("word");

  //connect(m_searchBar, SIGNAL(returnPressed()), this, SLOT(runSearch()));
  //connect(m_searchBar, SIGNAL(returnPressed()), this, SLOT(showSearchWidget()));
  connect(m_searchBar, SIGNAL(textChanged(const QString &)), this, SLOT(searchTextChanged(const QString &)));

  connect(m_searchBar, SIGNAL(returnPressed()), searchWidget, SLOT(runFirstApp()));

  m_tabBar->reset();

  scene()->setFocusItem(m_searchBar);

  /*
  QTimer::singleShot(500, this, SLOT(postSetup()));
  QTimer::singleShot(1000, this, SLOT(postSetup()));
  QTimer::singleShot(2000, this, SLOT(postSetup()));
  QTimer::singleShot(5000, this, SLOT(postSetup()));
  QTimer::singleShot(10000, this, SLOT(postSetup()));
  */

  m_setupTimer = new QTimer(this);

  connect(m_setupTimer, SIGNAL(timeout()), this, SLOT(postSetup()));
  
  m_setupTimer->setSingleShot(false);
  m_setupTimer->start(500);

  /*
  QTimer *debugTimer = new QTimer(this);
  connect(debugTimer, SIGNAL(timeout()), this, SLOT(checkFocus()));
  debugTimer->setSingleShot(false);
  debugTimer->start(500);
  */
  
  
  //connect(QApplication::topLevelWidgets().first(), SIGNAL(shown()), this, SLOT(setSearchFocus()));

  //kDebug() << "TOPLEVELWIDGETS: " << QApplication::topLevelWidgets().count();

  //kDebug() << "IS GLOBAL SHORTCUT AVAILABLE: " << KGlobalAccel::isGlobalShortcutAvailable(QKeySequence(Qt::Key_Meta));

  //setGlobalShortcut(KShortcut(QKeySequence(Qt::Key_Meta)));

  if(globalShortcut().isEmpty())
    setGlobalShortcut(KShortcut(QKeySequence(Qt::ALT + Qt::Key_F1)));

  //KGlobalAccel::stealShortcutSystemwide(QKeySequence(Qt::Key_Meta));

  //kDebug() << "IS GLOBAL SHORTCUT AVAILABLE: " << KGlobalAccel::isGlobalShortcutAvailable(QKeySequence(Qt::Key_Meta));
  //setGlobalShortcut(KShortcut(Qt::Key_Meta));
  //kDebug() << "IS GLOBAL SHORTCUT AVAILABLE: " << KGlobalAccel::isGlobalShortcutAvailable(QKeySequence(Qt::Key_Meta));

  /*
  m_actionCollection = new KActionCollection(this);
  m_toggleAction = qobject_cast<KAction*>(m_actionCollection->addAction(QString("Toggle Window")));

  //m_toggleAction->setGlobalShortcut(KShortcut(QKeySequence(Qt::Key_Meta)), KAction::ActiveShortcut | KAction::DefaultShortcut, KAction::NoAutoloading);
  m_toggleAction->setGlobalShortcut(KShortcut(QKeySequence(Qt::CTRL + Qt::SHIFT + Qt::Key_P)), KAction::ActiveShortcut | KAction::DefaultShortcut, KAction::NoAutoloading);
  */
}

void ROSA_Launcher::registerLaunchedApp(QString appName)
{
  m_welcomeWidget->registerLaunchedApp(appName);
  clearSearchBar();
}

void ROSA_Launcher::clearSearchBarOnly(void)
{
  if(m_searchWidgetShown)
    {
      m_searchBarClearOnly = true;
      m_searchBar->setText(QString(""));
    }
}

void ROSA_Launcher::clearSearchBar(void)
{
  m_searchBar->setText(QString(""));
}

void ROSA_Launcher::postSetup(void)
{
  bool connectOnShownEvent = false, connectOnHiddenEvent = false, connectOnHotKeyEvent = false;
  
  if(QApplication::activeWindow() != NULL)
  {
    connectOnShownEvent = connect(QApplication::activeWindow(), SIGNAL(shown()), this, SLOT(setSearchFocus()));
    connectOnHiddenEvent = connect(QApplication::activeWindow(), SIGNAL(hiden()), this, SLOT(clearSearchBar()));
    connectOnHotKeyEvent = connect(this, SIGNAL(activate()), QApplication::activeWindow(), SLOT(toggleWindow()));
  }

  //connect(m_toggleAction, SIGNAL(triggered(Qt::MouseButtons, Qt::KeyboardModifiers)), QApplication::activeWindow(), SLOT(toggleWindow()));
  //connect(m_toggleAction, SIGNAL(triggered(Qt::MouseButtons, Qt::KeyboardModifiers)), this, SLOT(actionTriggered(Qt::MouseButtons, Qt::KeyboardModifiers)));

  if(connectOnShownEvent && connectOnHiddenEvent && connectOnHotKeyEvent)
    m_setupTimer->stop();

  kDebug() << focusItem();
  
  setSearchFocus();
}

bool ROSA_Launcher::focusNextPrevChild(bool next)
{
  QGraphicsItem *current = focusItem();
  if(current)
    {
      int currentOrder = current->data(0).toInt();

      QGraphicsItem *target;

      /*
      kDebug() << current;
      kDebug() << "PREPARING TO CHANGE FOCUS.";
      kDebug() << "CURRENT ORDER: " << currentOrder;
      */
  
      QMap<int, QGraphicsItem*> orderList;

      // Building focus list
      foreach(QGraphicsItem *item, scene()->items())
        {
          int itemOrder = item->data(0).toInt();
          if(itemOrder > 0)
            orderList[itemOrder] = item;
        }

      if(! orderList.isEmpty())
        {
          /*
          if(currentOrder == 0)
            {
              current->setFlag(QGraphicsItem::ItemIsFocusable, false);
              orderList[0]->setFocus(Qt::MouseFocusReason);
              return true;
            }
          */
      
          QMap<int, QGraphicsItem*>::iterator listIter = orderList.find(currentOrder);

          if(next)
            {
              listIter++;
              if(listIter == orderList.end())
                {
                  target = (*orderList.begin());
                }
              else
                {
                  target = (*listIter);
                }
            }
          else // prev
            {
              if(listIter == orderList.begin())
                {
                  listIter = orderList.end();
                  listIter--;

                  target = (*listIter);
                }
              else
                {
                  listIter--;
                  target = (*listIter);
                }
            }

          if(target)
            {
              /*
                if(target->data(0).toInt() == 0)
                target->setFlag(QGraphicsItem::ItemIsFocusable, false);
                else
                {
              */
              target->setFocus(Qt::MouseFocusReason);
              //}
              return true;
            }
          else
            {
              kDebug() << "Target is null. Shouldn't happen at all.";
            }

        }

    }
  
  kDebug() << "ROSA_Launcher::focusNextPrevChild failed!";
  return false;
}

/*
void ROSA_Launcher::actionTriggered(Qt::MouseButtons mouseButtons, Qt::KeyboardModifiers keyboardModifiers)
{
}
*/

void ROSA_Launcher::setSearchFocus(void)
{
  scene()->setFocusItem(m_searchBar);
}

void ROSA_Launcher::setIconsFocus(void)
{
  /*
  if(m_tabBar->currentItem())
    m_tabBar->currentItem()->setFocus(Qt::MouseFocusReason);
  */
  
  if(m_searchBarJustCleared)
    {
      m_searchBarJustCleared = false;
      kDebug() << "SKIPPING FOCUS REMOVAL!";
    }
  else
    {
      kDebug() << "REMOVING FOCUS!";
      setSearchFocus();
      focusNextPrevChild(true);
    }
}

void ROSA_Launcher::searchTextChanged(const QString &text)
{
  if(text.size() > 0)
    {
      showSearchWidget();
      m_runnerManager->launchQuery(text);
    }
  else
    {
      m_searchBarJustCleared = true;
      m_runnerManager->reset();
      hideSearchWidget();
    }
}

void ROSA_Launcher::showSearchWidget()
{
  if(! m_searchWidgetShown)
    {
      m_tabBar->tabChanged(0, true);

      m_searchWidgetShown = true;
    }
}

void ROSA_Launcher::hideSearchWidget()
{
  kDebug() << "SEARCHWIDGETSHOWN: " << m_searchWidgetShown;
  kDebug() << "SEARCHBARCLEARONLY: " << m_searchBarClearOnly;
  kDebug() << "SEARCHBARJUSTCLEARED: " << m_searchBarJustCleared;
  
  if(m_searchWidgetShown && ! m_searchBarClearOnly)
    {
      m_tabBar->reset();      
    }

  m_searchBarClearOnly = false;
  m_searchWidgetShown = false;
}

void ROSA_Launcher::newSearchMatches(const QList<Plasma::QueryMatch> &matches)
{
  Q_UNUSED(matches);
}

void ROSA_Launcher::lockScreen()
{
  QDBusMessage message = QDBusMessage::createMethodCall("org.kde.screensaver", "/ScreenSaver", "org.freedesktop.ScreenSaver", "Lock");

  QDBusConnection::sessionBus().send(message);
}

void ROSA_Launcher::shutdownDialog()
{
  QDBusMessage message = QDBusMessage::createMethodCall("org.kde.ksmserver", "/KSMServer", "org.kde.KSMServerInterface", "logout");

  message << -1 << -1 << -1; // Arguments

  QDBusConnection::sessionBus().send(message);
}

void ROSA_Launcher::checkFocus(void)
{
  kDebug() << scene()->focusItem();
}

void ROSA_Launcher::keyPressEvent(QKeyEvent *event)
{
  if(event->key() == Qt::Key_Escape)
    {
      QMetaObject::invokeMethod(static_cast<QObject*>(QApplication::activeWindow()), "hideWindow");
    }

  if(event->modifiers() & Qt::AltModifier)
    {
      if(event->key() == Qt::Key_1)
        {
          m_tabBar->changeTab(0);
          //QTimer::singleShot(500, this, SLOT(setIconsFocus()));
        }
      else if(event->key() == Qt::Key_2)
        {
          m_tabBar->changeTab(1);
          //QTimer::singleShot(500, this, SLOT(setIconsFocus()));
        }
      else if(event->key() == Qt::Key_3)
        {
          m_tabBar->changeTab(2);
          //QTimer::singleShot(500, this, SLOT(setIconsFocus()));
        }
    }
  else if(event->modifiers() & Qt::ControlModifier)
    if(event->key() == Qt::Key_Tab)
      {
        int currentTab = m_tabBar->currentTabIndex();
        currentTab++;
        if(currentTab > 2)
          currentTab = 0;

        m_tabBar->changeTab(currentTab);
        //QTimer::singleShot(500, this, SLOT(setIconsFocus()));
      }
}

void ROSA_Launcher::keyReleaseEvent(QKeyEvent *event)
{
  Q_UNUSED(event);
}

void ROSA_Launcher::resizeSelf(void)
{
  /*
  QRectF screenRect = QDesktopWidget().screenGeometry();
  std::cout << "Screen size: " << screenRect.width() << "x" << screenRect.height() << std::endl;
  std::cout << "Parent size: " << parentWidget()->geometry().width() << "x" << parentWidget()->geometry().height() << std::endl;
  std::cout << "topLevelWidget size: " << static_cast<Plasma::Applet*>(topLevelWidget())->screenRect().width() << "x" << static_cast<Plasma::Applet*>(topLevelWidget())->screenRect().height() << std::endl;
  std::cout << "View size: " << scene()->views().first()->size().width() << "x" << scene()->views().first()->size().height() << std::endl;
  */
  QSize contSize = scene()->views().first()->size();

  resize(contSize);
}

void ROSA_Launcher::paintInterface(QPainter *p,
                                   const QStyleOptionGraphicsItem *option, const QRect &contentsRect)
{

  Q_UNUSED(option);
  Q_UNUSED(contentsRect);
  
  // construct a transparent image
  QImage image(boundingRect().size().toSize(),
               QImage::Format_ARGB32_Premultiplied);
  image.fill(0);
 
  // construct a dedicated offline painter for this image
  QPainter imagePainter(&image);
  imagePainter.translate(-boundingRect().topLeft());
 
  // paint the item using imagePainter
  /*
  imagePainter.setPen(Qt::blue);
  imagePainter.setBrush(Qt::green);
  imagePainter.drawEllipse(-50, -50, 100, 100);
 
  imagePainter.end();
  */

  //convertToGrayScale(image); // <- your code goes here

  //Plasma::Applet::paintInteface(imagePainter, option, contentsRect);

  p->setClipping(true);
  p->setClipRect(QRect(0, 0, 100, 100));
  
  p->drawImage(boundingRect(), image);

  //image.save("blabla-test.png");
  
  /*
  p->setRenderHint(QPainter::SmoothPixmapTransform);
  p->setRenderHint(QPainter::Antialiasing);

  m_svg.resize((int)contentsRect.width(), (int)contentsRect.height());
  m_svg.paint(p, (int)contentsRect.left(), (int)contentsRect.top());

  p->drawPixmap(7, 0, m_icon.pixmap((int)contentsRect.width(), (int)contentsRect.width() - 14));
  p->save();
  p->setPen(Qt::white);
  p->drawText(contentsRect,
              Qt::AlignBottom | Qt::AlignHCenter,
              "Hello Plasmoid!");
  p->restore();
  */
}

K_EXPORT_PLASMA_APPLET(rosa-launcher, ROSA_Launcher)

#include "rosa-launcher.moc"
