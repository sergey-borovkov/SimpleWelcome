/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "button.h"

#include "config.h"

#include <QApplication>
#include <QObject>
#include <QWidget>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QTimer>

#include <krun.h>
#include <kurl.h>

AppButton::AppButton(QIcon icon, QString name, QString description, QString desktopFile, QGraphicsItem *parent, Qt::WindowFlags wFlags)
  : QGraphicsWidget(parent, wFlags),
    m_layout(0),
    m_icon(0),
    m_label(0),
    m_desktopFile(desktopFile),
    m_process(0),
    m_manager(0),
    m_match(0),
    m_firstPaintSkiped(false)
{
  init(icon, name, description);
}

AppButton::AppButton(QIcon icon, QString name, QString description, Plasma::RunnerManager *manager, const Plasma::QueryMatch *match, QGraphicsItem *parent, Qt::WindowFlags wFlags)
  : QGraphicsWidget(parent, wFlags),
    m_layout(0),
    m_icon(0),
    m_label(0),
    m_desktopFile(""),
    m_process(0),
    m_manager(manager),
    m_match(match),
    m_firstPaintSkiped(false)
{
  init(icon, name, description);
}

void AppButton::init(QIcon icon, QString name, QString description)
{
  Q_UNUSED(description);
  
  m_layout = new QGraphicsLinearLayout(Qt::Vertical);
  m_layout->setContentsMargins(BUTTON_MARGIN, 0, BUTTON_MARGIN, 0);
  setLayout(m_layout);

  setContentsMargins(0, 8, 0, 8);

  setAcceptHoverEvents(true);
  setAcceptedMouseButtons(Qt::LeftButton);

  m_icon = new Plasma::IconWidget();
  m_label = new ElidedLabel();
  m_label->setFlag(QGraphicsItem::ItemIsFocusable, false);

  QFont labelFont;
  labelFont.setBold(true);
  labelFont.setPointSize(10);
  m_label->setFont(labelFont);

  
  m_layout->addItem(m_icon);
  m_layout->addItem(m_label);

  m_layout->setAlignment(m_icon, Qt::AlignHCenter);

  m_icon->setIcon(icon);
  m_label->setText(name);

  m_icon->setAcceptHoverEvents(false);
  m_icon->setAcceptedMouseButtons(Qt::NoButton);

  m_label->setAlignment(Qt::AlignHCenter);
  m_label->setWordWrap(true);
  m_label->setMaximumWidth(ICON_SIZE + BUTTON_MARGIN * 2);
  m_label->setMinimumWidth(ICON_SIZE + BUTTON_MARGIN * 2);

  int current_height = m_label->geometry().height();

  m_label->setMinimumHeight(current_height * 3);
  m_label->setMaximumHeight(current_height * 3);

  m_icon->setMaximumWidth(ICON_SIZE);
  m_icon->setMinimumWidth(ICON_SIZE);
  m_icon->setMaximumHeight(ICON_SIZE);
  m_icon->setMinimumHeight(ICON_SIZE);

  QTimer::singleShot(0, this, SLOT(forceUpdate()));
  connect(this, SIGNAL(visibleChanged()), this, SLOT(forceUpdate()));
  connect(this, SIGNAL(enabledChanged()), this, SLOT(forceUpdate()));
  connect(this, SIGNAL(opacityChanged()), this, SLOT(forceUpdate()));
  connect(this, SIGNAL(parentChanged()), this, SLOT(forceUpdate()));
}

AppButton::~AppButton()
{
  if(m_layout)
    while(m_layout->count() > 0)
      {
        m_layout->removeAt(0);
      }

  delete m_icon;
  delete m_label;
  //delete m_layout;
}

void AppButton::forceUpdate(void)
{
  adjustSize();
  update();
  updateGeometry();
}

void AppButton::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
  // Drag 'n Drop

  if(event->button() & Qt::LeftButton)
    m_mousePressPosition = event->screenPos();
}

void AppButton::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
  runApp();
  
  // Drag 'n Drop
  if(event->button() & Qt::LeftButton)
    m_mousePressPosition = QPoint();
}

void AppButton::runApp(void)
{
  if(m_manager != NULL && m_match != NULL)
    {
      m_manager->run(*m_match);
      //kDebug() << "DATA: " << m_match->data();
      emit appLaunched(m_match->data().toString());
    }
  else
    {
      KRun *krunner = new KRun(KUrl(m_desktopFile), QApplication::activeWindow());

      Q_UNUSED(krunner);
      
      emit appLaunched(m_desktopFile);
    }

  QMetaObject::invokeMethod(static_cast<QObject*>(QApplication::activeWindow()), "hideWindow");
}

/*
void AppButton::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
  QString program = "/usr/bin/kioclient";
  QStringList arguments;

  arguments << "exec" << m_desktopFile;

  if(m_process == 0)
    {
      m_process = new QProcess(this);

      m_process->start(program, arguments);
      m_process->waitForStarted();
    }
  else if(m_process->state() == QProcess::NotRunning)
    {
      delete m_process;

      m_process = new QProcess(this);

      m_process->start(program, arguments);
      m_process->waitForStarted();
    }

  //kDebug() << m_desktopFile;
  emit appLaunched(m_desktopFile);

  QMetaObject::invokeMethod(static_cast<QObject*>(QApplication::activeWindow()), "hideWindow");

  // Drag 'n Drop
  if(event->button() & Qt::LeftButton)
    m_mousePressPosition = QPoint();
}
*/

void AppButton::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
  if(! m_mousePressPosition.isNull()) // If dragging
    {
      int mousePressDistance = (event->screenPos() - m_mousePressPosition).manhattanLength();

      if(mousePressDistance >= QApplication::startDragDistance()) // If dragged far enough
        {
          QMimeData *mimeData = new QMimeData();
          if(! m_match)
            mimeData->setData("text/uri-list", m_desktopFile.toAscii());
          else
            mimeData->setData("text/uri-list", m_match->data().toString().toAscii());
          mimeData->setText(mimeData->text());
          QDrag *drag = new QDrag(static_cast<QWidget*>(scene()->views().first()));
          drag->setMimeData(mimeData);

          QIcon icon = m_icon->icon();
          drag->setPixmap(icon.pixmap(IconSize(KIconLoader::Desktop)));

          m_mousePressPosition = QPoint();

          Qt::DropAction dropAction = drag->exec();
          Q_UNUSED(dropAction);
        }
    }
}

void AppButton::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
  Q_UNUSED(event);
  //m_icon->hoverEnterEvent(event);
  emit hoverEnter(static_cast<QGraphicsWidget*>(this));
}

void AppButton::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
  Q_UNUSED(event);
  //m_icon->hoverLeaveEvent(event);
  emit hoverLeave(static_cast<QGraphicsWidget*>(this));
}

void AppButton::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
  if(m_firstPaintSkiped)
    {
      QGraphicsWidget::paint(painter, option, widget);
    }
  else
    {
      m_firstPaintSkiped = true;
    }
}
