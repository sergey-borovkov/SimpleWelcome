/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef __applicationswidget_h_
#define __applicationswidget_h_

#include <QGraphicsLinearLayout>
#include <QGraphicsWidget>
#include <QString>
#include <QList>
#include <QObject>
#include <QGraphicsSceneWheelEvent>

//#include <Plasma/ScrollWidget>
#include "scrollwidget/scrollwidget.h"
#include <Plasma/DataEngine>
#include <Plasma/Applet>

#include "config.h"

class AppData;

class ApplicationsWidget : public SWScrollWidget
{
  Q_OBJECT
    public:
  ApplicationsWidget(QGraphicsItem *parent = 0);
  virtual ~ApplicationsWidget();

  void setAppsEngine(Plasma::DataEngine* appsEngine);
  void setAppLaunchReciever(QObject* reciever) { m_appLaunchReciever = reciever; };

  QStringList allEntries(void);
  
 public slots:
  void dataUpdated(const QString &name, const Plasma::DataEngine::Data &data);
  void sourceAdded(const QString &name);
  void sourceRemoved(const QString &name);
  /*
  void mousePressEvent(QGraphicsSceneMouseEvent *event);
  void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);

  void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
  void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);
  */

  void wheelEvent(QGraphicsSceneWheelEvent *event);

  void reposition(void);

  void repositionIfNeeded(void);

  void tabActivated(void);
  
 private:
  //void retrieveApps(void);

  Plasma::DataEngine* m_appsEngine;
  QHash<QString, AppData*> m_appEntities;

  QStringList deepFlaten(QStringList entityNames);

  QObject *m_appLaunchReciever;

  double m_scrollWheelSpeed;

  bool m_repositionNeeded;

  QStringList m_allDesktopFiles;
  
  //QList<QString> m_groupNames;
};

class AppData
{
 public:
  AppData();
  AppData(QString sourceName, const Plasma::DataEngine::Data &data);
  ~AppData();

  QString sourceName() { return m_sourceName; };
  void setSourceName(QString value) { m_sourceName = value; };
  QString name() { return m_name; };
  void setName(QString value) { m_name = value; };
  bool isApp() { return m_isApp; };
  void setIsApp(bool value) { m_isApp = value; };
  bool display() { return m_display; };
  void setDisplay(bool value) { m_display = value; };
  QString iconName() { return m_iconName; };
  void setIconName(QString value) { m_iconName = value; };
  QString comment() { return m_comment; };
  void setComment(QString value) { m_comment = value; };
  bool valid() { return m_valid; };

  QString genericName() { return m_genericName; };
  void setGenericName(QString value) { m_genericName = value; };
  QString menuId() { return m_menuId; };
  void setMenuId(QString value) { m_menuId = value; };
  QString entryPath() { return m_entryPath; };
  void setEntryPath(QString value) { m_entryPath = value; };

  QStringList* entries() { return &m_entries; };
  
 private:
  // Group and App members
  QString m_sourceName;
  QString m_name;
  bool m_isApp;
  bool m_display;
  QString m_iconName;
  QString m_comment;
  bool m_valid;

  // App only members
  QString m_genericName;
  QString m_menuId;
  QString m_entryPath;

  // Group only members
  QStringList m_entries;
};

#endif // __applicationswidget_h_
