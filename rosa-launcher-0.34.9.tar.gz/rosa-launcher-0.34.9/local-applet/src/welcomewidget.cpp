/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "welcomewidget.h"
#include "groupgridwidget.h"
#include "button.h"

#include <KRecentDocument>
#include <KDesktopFile>
#include <KFilePlacesModel>

#include <QFile>
#include <QString>
#include <QList>
#include <KIcon>
#include <QIcon>
#include <KDebug>
#include <KConfig>

#include <klocalizedstring.h>

WelcomeWidget::WelcomeWidget(QGraphicsItem *parent)
  : SWScrollWidget(parent),
    m_applicationsWidget(0)
{
  setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
  //setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
  setOverShoot(false);

  GroupGridWidget *groupGrid = new GroupGridWidget();
  groupGrid->setScrollWidget(this);
  setWidget(groupGrid);

  /*
  GroupGridWidgetGroup *group = groupGrid->newGroup("Recent Applications");

  for(int i = 0; i < 35; i++)
    {
      AppButton *button = new AppButton(static_cast<QIcon>(KIcon("face-wink")), QString("Smiley smile ") + QString::number(i), QString("This is Smily. Glad to know U!"), QString("file:///usr/share/applications/kde4/kcalc.desktop"));
      group->append(button);
    }

  group->repopulate();

  group = groupGrid->newGroup("Recent Documents");

  for(int i = 0; i < 31; i++)
    {
      AppButton *button = new AppButton(static_cast<QIcon>(KIcon("face-wink")), QString("Smiley smile ") + QString::number(i), QString("This is Smily. Glad to know U!"), QString("file:///usr/share/applications/kde4/kcalc.desktop"));
      group->append(button);
    }

  group->repopulate();
  */

  // Read recent applications from config
  readRecentApps();

  m_checkRecentAppsTimer = new QTimer(this);
  connect(m_checkRecentAppsTimer, SIGNAL(timeout()), this, SLOT(checkRecentApps()));
  m_checkRecentAppsTimer->start(3000);
  
  // Fill groups with elements
  reposition();
}

WelcomeWidget::~WelcomeWidget()
{
}

void WelcomeWidget::checkRecentApps(void) // Should be renamed to checkRefreshNeed or something
{
  // Recent Apps check
  
  QStringList deleteList;

  QStringList origList = m_recentApplications;

  // Checking
  for(int i = 0; i < m_recentApplications.size(); i++)
    {
      QString fileName = m_recentApplications[i];
      //kDebug() << fileName;

      if(! KDesktopFile::isDesktopFile(fileName) || ! QFile::exists(fileName))
        deleteList.append(fileName);
    }

  deleteList.removeDuplicates();
  
  for(int i = 0; i < deleteList.size(); i++)
    {
      m_recentApplications.removeAll(deleteList[i]);
    }

  if(m_recentApplications != origList)
    reposition();

  // Last docuements
  QStringList documentsList = KRecentDocument::recentDocuments();

  if(m_lastRecentDocuments != documentsList)
    reposition();  
}

void WelcomeWidget::registerLaunchedApp(QString desktopFile)
{
  // Checking if app is in applications list
  if(m_applicationsWidget)
    {
      QStringList applications = m_applicationsWidget->allEntries();

      if(! applications.contains(desktopFile))
        return;
    }

  int position = m_recentApplications.indexOf(desktopFile);

  if(position == -1) // If no matches found - just insert
    {  
      m_recentApplications.insert(0, desktopFile);
      while(m_recentApplications.size() > ICONS_IN_A_ROW)
        {
          m_recentApplications.removeLast();
        };
    }
  else
    {
      m_recentApplications.move(position, 0);
    };

  writeRecentApps();
};


void WelcomeWidget::readRecentApps()
{
  KSharedConfig::Ptr config = KGlobal::config();
  KConfigGroup *configGroup = new KConfigGroup(config, "General");

  m_recentApplications = configGroup->readEntry("Recent applications", QStringList());  

  //delete config; // Smart pointer used
  delete configGroup;
}

void WelcomeWidget::writeRecentApps()
{
  KSharedConfig::Ptr config = KGlobal::config();
  KConfigGroup *configGroup = new KConfigGroup(config, "General");

  configGroup->writeEntry("Recent applications", m_recentApplications);

  configGroup->sync();

  //delete config; // Smart pointer used
  delete configGroup;
}



void WelcomeWidget::reposition()
{
  GroupGridWidget *gridWidget = static_cast<GroupGridWidget*>(widget());
  AppButton *button;
  GroupGridWidgetGroup *gridWidgetGroup;
  KDesktopFile *desktopFile;

  kDebug() << "REPOSITION CALLED!";
  
  //gridWidget->clear(); // Fixer
  
  // ----------------------------------------------------------------
  // Recent Applications

  if(m_lastRecentApplications != m_recentApplications) // Check, if we need reposition
    {
      
      if(gridWidget->hasGroup(i18n("Recent Applications")))
        {
          gridWidgetGroup = gridWidget->getGroup(i18n("Recent Applications"));
          gridWidgetGroup->clear();
        }
      else
        {
          gridWidgetGroup = gridWidget->newGroup(i18n("Recent Applications"));
        }

      for(int i = 0; i < m_recentApplications.size(); i++)
        {
          QString fileName = m_recentApplications[i];
          //kDebug() << fileName;

          if(! KDesktopFile::isDesktopFile(fileName))
            continue;

          if(! QFile::exists(fileName))
            continue;
          
          desktopFile = new KDesktopFile(fileName);

          if(desktopFile->noDisplay())
            continue;

          button = new AppButton(static_cast<QIcon>(KIcon(desktopFile->readIcon())), desktopFile->readName(), fileName, fileName);

          gridWidgetGroup->append(button);

          delete desktopFile;
      
        }

      gridWidgetGroup->repopulate();

      m_lastRecentApplications = m_recentApplications;
    }

  // ----------------------------------------------------------------
  // Places
  QStringList currentPlaces;

  KFilePlacesModel *places = new KFilePlacesModel();

  for(int i = 0; i < places->rowCount(); i++)
    {
      currentPlaces.append(places->index(i, 0).data(KFilePlacesModel::UrlRole).toString());
    }
  
  if(m_lastPlaces != currentPlaces) // Check, if we need reposition
    {
      
      if(gridWidget->hasGroup(i18n("Places")))
        {
          gridWidgetGroup = gridWidget->getGroup(i18n("Places"));
          gridWidgetGroup->clear();
        }
      else
        {
          gridWidgetGroup = gridWidget->newGroup(i18n("Places"));
        }

      for(int i = 0; i < places->rowCount(); i++)
        {
          QVariant variantName = places->index(i, 0).data(Qt::DisplayRole);
          QVariant variantUrl = places->index(i, 0).data(KFilePlacesModel::UrlRole);
          QVariant variantIcon = places->index(i, 0).data(Qt::DecorationRole);

          m_hiddenPlaces.append(variantUrl.toString());

          button = new AppButton(variantIcon.value<QIcon>(), variantName.toString(), variantUrl.toString(), variantUrl.toString());

          gridWidgetGroup->append(button);
      
        }

  
      gridWidgetGroup->repopulate();
      m_lastPlaces = currentPlaces;
    }

  delete places;
  
  // ----------------------------------------------------------------
  // Recent Documents
  QStringList documentsList = KRecentDocument::recentDocuments();

  if(m_lastRecentDocuments != documentsList)
    {
      if(gridWidget->hasGroup(i18n("Recent Documents")))
        {
          gridWidgetGroup = gridWidget->getGroup(i18n("Recent Documents"));
          gridWidgetGroup->clear();
        }
      else
        {
          gridWidgetGroup = gridWidget->newGroup(i18n("Recent Documents"));
        }
  
      for(int i = 0; i < documentsList.size(); i++)
        {
          QString fileName = documentsList[i];
          //kDebug() << fileName;

          if(! KDesktopFile::isDesktopFile(fileName))
            continue;

          // Reusing previously declared desktopFile
          desktopFile = new KDesktopFile(fileName);

          if(desktopFile->noDisplay())
            continue;

          if(m_hiddenPlaces.contains(desktopFile->readUrl()))
            continue;

          button = new AppButton(static_cast<QIcon>(KIcon(desktopFile->readIcon())), desktopFile->readName(), desktopFile->readUrl(), desktopFile->readUrl());

          gridWidgetGroup->append(button);

          delete desktopFile;
        }

      gridWidgetGroup->repopulate();
      
      m_lastRecentDocuments = documentsList;
    }

  gridWidget->setGroupsMarginsForWidth(gridWidget->size().width());
}
