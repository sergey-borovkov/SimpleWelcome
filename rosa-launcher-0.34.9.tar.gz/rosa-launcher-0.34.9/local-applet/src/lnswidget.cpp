/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <QPainter>
#include <KDebug>

#include "lnswidget.h"

#define LOCK_OFFSET_X 7
#define LOCK_OFFSET_Y 18
#define OFF_OFFSET_X 52
#define OFF_OFFSET_Y 7

LNSWidget::LNSWidget(QGraphicsItem *parent)
  : QGraphicsWidget(parent)
{
  //kDebug() << "Creating LNSWidget";
  loadPixmaps();

  m_lockButtonState = BS_DEFAULT;
  m_offButtonState = BS_DEFAULT;

  setAcceptHoverEvents(true);
}

LNSWidget::~LNSWidget(void)
{
  unloadPixmaps();
}

void LNSWidget::loadPixmaps(void)
{
  m_pixmaps["background"] = new QPixmap(QString(PIXMAP_PATH) + "buttons_background.png");
  m_pixmaps["lock_default"] = new QPixmap(QString(PIXMAP_PATH) + "lock_default.png");
  m_pixmaps["lock_disable"] = new QPixmap(QString(PIXMAP_PATH) + "lock_disable.png");
  m_pixmaps["lock_hover"] = new QPixmap(QString(PIXMAP_PATH) + "lock_hover.png");
  m_pixmaps["lock_press"] = new QPixmap(QString(PIXMAP_PATH) + "lock_press.png");
  m_pixmaps["off_default"] = new QPixmap(QString(PIXMAP_PATH) + "off_default.png");
  m_pixmaps["off_disable"] = new QPixmap(QString(PIXMAP_PATH) + "off_disable.png");
  m_pixmaps["off_hover"] = new QPixmap(QString(PIXMAP_PATH) + "off_hover.png");
  m_pixmaps["off_press"] = new QPixmap(QString(PIXMAP_PATH) + "off_press.png");

  m_backgroundSize = m_pixmaps["background"]->size();
  setMinimumSize(m_backgroundSize);

  m_lockButtonRect.setX(LOCK_OFFSET_X);
  m_lockButtonRect.setY(LOCK_OFFSET_Y);
  m_lockButtonRect.setWidth(m_pixmaps["lock_default"]->width());
  m_lockButtonRect.setHeight(m_pixmaps["lock_default"]->height());

  m_offButtonRect.setX(OFF_OFFSET_X);
  m_offButtonRect.setY(OFF_OFFSET_Y);
  m_offButtonRect.setWidth(m_pixmaps["off_default"]->width());
  m_offButtonRect.setHeight(m_pixmaps["off_default"]->height());
}

void LNSWidget::unloadPixmaps(void)
{
  QPixmap *pixmap;
  foreach(pixmap, m_pixmaps.values())
    delete(pixmap);

  m_pixmaps.clear();
}

QRectF LNSWidget::boundingRect() const
{
  //kDebug() << "Returning LNSWidget size: " << m_backgroundSize;
  return QRectF(0, 0, m_backgroundSize.width(), m_backgroundSize.height());
}

void LNSWidget::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
  QGraphicsItem::hoverEnterEvent(event);

  bool onLockButton = m_lockButtonRect.contains(event->pos().toPoint());
  bool onOffButton = m_offButtonRect.contains(event->pos().toPoint());
  
  if(onLockButton && m_lockButtonState != BS_HOVER) // if hovered over lock button
  {
    m_lockButtonState = BS_HOVER;
    update(m_lockButtonRect);
  }
  else if(! onLockButton && (m_lockButtonState == BS_HOVER || m_lockButtonState == BS_PRESS)) // if not hovered, but was hovered, revert to default
  {
    m_lockButtonState = BS_DEFAULT;
    update(m_lockButtonRect);
  }

  if(onOffButton && m_offButtonState != BS_HOVER) // if hovered over off button
  {
    m_offButtonState = BS_HOVER;
    update(m_offButtonRect);
  }
  else if(! onOffButton && (m_offButtonState == BS_HOVER || m_offButtonState == BS_PRESS)) // if not hovered, but was hovered, revert to default
  {
    m_offButtonState = BS_DEFAULT;
    update(m_offButtonRect);
  }
    
}

void LNSWidget::hoverMoveEvent(QGraphicsSceneHoverEvent *event)
{
  QGraphicsItem::hoverMoveEvent(event);
  
  bool onLockButton = m_lockButtonRect.contains(event->pos().toPoint());
  bool onOffButton = m_offButtonRect.contains(event->pos().toPoint());
  
  if(onLockButton && m_lockButtonState != BS_HOVER) // if hovered over lock button
  {
    m_lockButtonState = BS_HOVER;
    update(m_lockButtonRect);
  }
  else if(! onLockButton && (m_lockButtonState == BS_HOVER || m_lockButtonState == BS_PRESS)) // if not hovered, but was hovered, revert to default
  {
    m_lockButtonState = BS_DEFAULT;
    update(m_lockButtonRect);
  }

  if(onOffButton && m_offButtonState != BS_HOVER) // if hovered over off button
  {
    m_offButtonState = BS_HOVER;
    update(m_offButtonRect);
  }
  else if(! onOffButton && (m_offButtonState == BS_HOVER || m_offButtonState == BS_PRESS)) // if not hovered, but was hovered, revert to default
  {
    m_offButtonState = BS_DEFAULT;
    update(m_offButtonRect);
  }
    
}

void LNSWidget::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
  QGraphicsItem::hoverLeaveEvent(event);
  
  if(m_lockButtonState == BS_HOVER || m_lockButtonState == BS_PRESS) // if was hovered, revert to default
  {
    m_lockButtonState = BS_DEFAULT;
    update(m_lockButtonRect);
  }
  
  if(m_offButtonState == BS_HOVER || m_lockButtonState == BS_PRESS) // if was hovered, revert to default
  {
    m_offButtonState = BS_DEFAULT;
    update(m_offButtonRect);
  }
}

void LNSWidget::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
  QGraphicsItem::mousePressEvent(event);

  bool onLockButton = m_lockButtonRect.contains(event->pos().toPoint());
  bool onOffButton = m_offButtonRect.contains(event->pos().toPoint());
  
  if(onLockButton && event->button() == Qt::LeftButton) // if hovered over lock button and clicked leftButton
  {
    event->accept();
    m_lockButtonState = BS_PRESS;
    update(m_lockButtonRect);
  }

  else if(onOffButton && event->button() == Qt::LeftButton) // if hovered over off button and clicked leftButton
  {
    event->accept();
    m_offButtonState = BS_PRESS;
    update(m_offButtonRect);
  }
  
}

void LNSWidget::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
  QGraphicsItem::mouseReleaseEvent(event);

  //kDebug() << "Testing in mouseReleaseEvent";
  
  bool onLockButton = m_lockButtonRect.contains(event->pos().toPoint());
  bool onOffButton = m_offButtonRect.contains(event->pos().toPoint());

  if(onLockButton && m_lockButtonState == BS_PRESS && event->button() == Qt::LeftButton)
  {
    emit lockButtonClicked();
    //kDebug() << "LOCK EMITED";
    m_lockButtonState = BS_HOVER;
    update(m_lockButtonRect);
  }

  if(onOffButton && m_offButtonState == BS_PRESS && event->button() == Qt::LeftButton)
  {
    emit offButtonClicked();
    //kDebug() << "OFF EMITED";
    m_offButtonState = BS_HOVER;
    update(m_offButtonRect);
  }

  if(event->button() == Qt::LeftButton)
  {
    if(m_lockButtonState == BS_PRESS)
    {
      m_lockButtonState = BS_DEFAULT;
      update(m_lockButtonRect);
    }

    if(m_offButtonState == BS_PRESS)
    {
      m_offButtonState = BS_DEFAULT;
      update(m_offButtonRect);
    }
  }
  
}

void LNSWidget::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
  Q_UNUSED(option);
  Q_UNUSED(widget);
  
  //kDebug() << "Drawing LNSWidget size: " << m_backgroundSize;
  painter->drawPixmap(0, 0, (*m_pixmaps["background"]));

  QPixmap *lockPixmap;
  QPixmap *offPixmap;

  switch(m_lockButtonState)
  {
  case BS_DISABLE:
    lockPixmap = m_pixmaps["lock_disable"];
    break;
  case BS_HOVER:
    lockPixmap = m_pixmaps["lock_hover"];
    break;
  case BS_PRESS:
    lockPixmap = m_pixmaps["lock_press"];
    break;
  default:
    lockPixmap = m_pixmaps["lock_default"];
  };
  
  switch(m_offButtonState)
  {
  case BS_DISABLE:
    offPixmap = m_pixmaps["off_disable"];
    break;
  case BS_HOVER:
    offPixmap = m_pixmaps["off_hover"];
    break;
  case BS_PRESS:
    offPixmap = m_pixmaps["off_press"];
    break;
  default:
    offPixmap = m_pixmaps["off_default"];
  };
  
  painter->drawPixmap(LOCK_OFFSET_X, LOCK_OFFSET_Y, (*lockPixmap));
  painter->drawPixmap(OFF_OFFSET_X, OFF_OFFSET_Y, (*offPixmap));
  
}
