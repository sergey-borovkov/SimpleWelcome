/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#ifndef __activityeventwidget_h_
#define __activityeventwidget_h_

#include <QGraphicsWidget>
#include <QGraphicsSceneMouseEvent>

class QGraphicsItem;
class ActivityEvent;
class QProcess;

class QActivityEventWidget : public QGraphicsWidget
{
  Q_OBJECT

public:
  QActivityEventWidget(QGraphicsItem* parent = 0, Qt::WindowFlags wFlags = 0);
  virtual ~QActivityEventWidget();

  virtual void init(ActivityEvent* event, const QRectF& widgetRect);

  void setEvent(ActivityEvent* event) { m_activityEvent = event; };
  ActivityEvent* getEvent() const { return m_activityEvent; };

  void setWidgetRect(QRectF rect) { m_widgetRect = rect; };
  QRectF getWidgetRect() const { return m_widgetRect; };

public slots:
  virtual void openEvent();
  void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
  void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);
  void mousePressEvent(QGraphicsSceneMouseEvent *event);
  void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);

signals:
  void hoverEnter(QGraphicsWidget*);
  void hoverLeave(QGraphicsWidget*);

protected:
  ActivityEvent* m_activityEvent;
  QProcess*      m_process;
  QRectF         m_widgetRect;

};

#endif // __activityeventwidget_h_
