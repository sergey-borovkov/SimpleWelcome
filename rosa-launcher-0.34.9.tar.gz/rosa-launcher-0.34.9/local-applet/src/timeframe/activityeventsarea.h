/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#ifndef __activityeventsarea_h_
#define __activityeventsarea_h_

#include <map>
using namespace std;

#include <QGraphicsWidget>
#include <Plasma/ItemBackground>
#include <plasma/widgets/label.h>
#include <QRectF>
#include <QList>
#include <QMovie>

#include "activityeventssource.h"
#include "activityevent.h"
#include "nepomukactivitysource.h"

class QGraphicsItem;
class QActivityEventWidget;
class EventPeriod;
class QGraphicsLinearLayout;

#define K_ITEM   (50.0)
#define K_W      (3.0)
#define K_H      (2.0)
#define K_R      (1.0)
#define R_MIN    (0)
#define R_MAX    (10)

#define _W_R(r)       (K_ITEM * K_W * (1 + r * K_R / R_MAX))
#define _H_R(r)       (K_ITEM * K_H * (1 + r * K_R / R_MAX))

#define W_MIN         _W_R(R_MIN)
#define H_MIN         _H_R(R_MIN)

#define W_MAX         _W_R(R_MAX)
#define H_MAX         _H_R(R_MAX)

#define _S(w, h)      (w * h)

#define S_MIN         _S(W_MIN, H_MIN)
#define S_MAX         _S(W_MAX, H_MAX)

#define _N_W(w)       (w / W_MAX)
#define _N_H(h)       (h / H_MAX)
#define _N_MAX(w, h)  (_N_W(w) * _N_H(h))

// способы отображения событий
enum ShowType
{
  Cloud = 0,
  Gallery
};

// структура, описывающая тип и способ отображения событий
struct ShowEventType
{
  EventType eventType;
  ShowType  showType;
  QString   eventName;
  Qt::Alignment alignmentCaption;
};


// describe events area (subarea)
class QActivityEventsArea : public QGraphicsWidget
{
  Q_OBJECT

public:
  QActivityEventsArea(QGraphicsItem *parent = 0, Qt::WindowFlags wFlags = 0);
  virtual ~QActivityEventsArea();

  virtual void init(ShowEventType showEventType, const EventPeriod* period);
  void setPeriod(const EventPeriod* period);

  void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget = 0);

protected slots:
  virtual void onGeometryChanged();

public slots:
  void setTargetItem(QGraphicsWidget*);
  virtual void stopAnimation();
  virtual void startAnimation();
  virtual void showNewEvent(ActivityEvent* event);

protected:
  void hoverLeaveEvent(QGraphicsSceneHoverEvent *evt);
  virtual void clearArea();

  virtual void setWidgetsGeometry();
  virtual void updateAreaGeometry();

  bool canShowEventWidget(const ActivityEvent* event);

  virtual QSizeF getWidgetSize();

protected:
  map<string, QActivityEventWidget*> m_widgetsMap;
  ShowEventType                      m_showEventType;
  const EventPeriod*                 m_period;
  Plasma::ItemBackground*            m_hoverIndicator;
  Plasma::Label*                     m_animationLabel;
  QMovie*                            m_movie;
  NepomukActivitySource*             m_nepomukSource;
  QGraphicsLinearLayout*             m_layout;

};

#endif // __activityeventsarea_h_
