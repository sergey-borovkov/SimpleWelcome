/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

// local
#include "timeframe.h"
#include "timeslider.h"
#include "eventtypesmenu.h"
#include "activityeventsscene.h"
#include "activityevent.h"

#include "qrc_rosa_launcher.h"

// Qt
#include <QGraphicsGridLayout>
#include <QGraphicsLinearLayout>
#include <QStringList>
#include <QDateTime>
#include <QDebug>
#include <QPointF>
#include <QObject>
#include <QMetaObject>
#include <QRectF>
#include <QApplication>
#include <QPainter>

//nepomuk
#include <Nepomuk/ResourceManager>

//nepomuk
#include <Nepomuk/ResourceManager>

// KDE
#include <klocalizedstring.h>
#include <ktoolinvocation.h>
#include <kmessagebox.h>

enum { HomeMenuItem = 0, PhotoMenuItem, VideoMenuItem, DocumentMenuItem };

QTimeFrame::QTimeFrame(QGraphicsItem *parent, Qt::WindowFlags wFlags)
    : QGraphicsWidget(parent, wFlags),
      m_layout(0),
      m_lineLayout(0),
      m_resetCallbackSet(0)
{
    qInitResources();

    // create menu
    QGraphicsWidget* item;
    m_menu = new QEventTypesMenu();
    item = m_menu->addMenuItem(i18n("Home"), true);
    connect(item, SIGNAL(clicked()), this, SLOT(showHome()));
    item = m_menu->addMenuItem(i18n("Photos"));
    connect(item, SIGNAL(clicked()), this, SLOT(showPhotos()));
    item = m_menu->addMenuItem(i18n("Video"));
    connect(item, SIGNAL(clicked()), this, SLOT(showVideo()));
    item = m_menu->addMenuItem(i18n("Documents"));
    connect(item, SIGNAL(clicked()), this, SLOT(showDocuments()));
    m_menu->addStretch();

    // top scene
    m_topScene = new QActivityEventsScene(this);

    // bottom scene
    m_bottomScene = new QActivityEventsScene(this);

    // slider widget
    m_timeSlider = new QTimeSlider(this);
    connect(m_timeSlider, SIGNAL(periodChanged(EventPeriod*)),
            this, SLOT(setNewPeriod(EventPeriod*)));

    // main layout
    m_layout = new QGraphicsGridLayout();
    m_layout->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    m_layout->addItem(m_menu, 0, 0);
    m_layout->addItem(m_topScene, 0, 1);
    m_layout->addItem(m_timeSlider, 1, 0, 1, 2);
    m_layout->addItem(m_bottomScene, 2, 1);

    m_layout->setRowMinimumHeight(2, 0);

    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
     setLayout(m_layout);

    //Set period
    QDate date = QDate::currentDate();
    date = date.addDays(-date.day() + 1);
    QDateTime time1(date);
    QDateTime time2(QDate(date.year(), date.month(), date.daysInMonth()));
    time2.setTime(QTime(23, 59, 59));
    EventPeriod period(time1.toTime_t(), time2.toTime_t());
    m_period = period;

    m_resetCallbackTimer = new QTimer(this);
    connect(m_resetCallbackTimer, SIGNAL(timeout()), this, SLOT(setResetCallback()));
    m_resetCallbackTimer->start(500);

    m_configButton = new Plasma::ToolButton(this);
    m_configButton->setText(i18n("Enable..."));
    m_configButton->setAutoRaise(false);
    m_configButton->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);
    connect(m_configButton,SIGNAL(clicked()),this,SLOT(slotConfigure()));

    m_sorryLabel = new Plasma::Label(this);
    m_sorryLabel->setAlignment(Qt::AlignCenter);
    m_sorryLabel->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Fixed);
    //Nepomuk is disabled. You can enable it in the KDE Control Centre. И название на кнопке "Enable...".
    m_sorryLabel->setText(i18n("Nepomuk is disabled. You can enable it in the KDE Control Centre"));

    m_warningWidget = new QGraphicsWidget(this);
    m_warningWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    m_lineLayout = new QGraphicsLinearLayout();
    m_lineLayout->setOrientation(Qt::Vertical);
    m_lineLayout->addStretch();
    m_lineLayout->addItem(m_sorryLabel);
    m_lineLayout->addItem(m_configButton);
    m_lineLayout->addStretch();
    m_lineLayout->setAlignment(m_lineLayout->itemAt(0),Qt::AlignCenter);
    m_lineLayout->setAlignment(m_lineLayout->itemAt(1),Qt::AlignCenter);

    m_warningWidget->setLayout(m_lineLayout);
    m_warningWidget->hide();
};

QTimeFrame::~QTimeFrame()
{
};


void QTimeFrame::tabActivated()
{
    //Check: is nepomuk enabled
    if (!Nepomuk::ResourceManager::instance()->initialized())
    {
        m_menu->hide();
        m_topScene->hide();
        m_timeSlider->hide(); 
        m_bottomScene->hide();
        while (m_layout->count() > 0)
            m_layout->removeAt(0);
        m_layout->addItem(m_warningWidget,0,0);
        m_warningWidget->show();
        return;
    }else
    {
        while (m_layout->count() > 0)
            m_layout->removeAt(0);
        m_menu->show();
        m_topScene->show();
        m_timeSlider->show();
        m_bottomScene->show();
        m_warningWidget->hide();
        m_layout->addItem(m_menu, 0, 0);
        m_layout->addItem(m_topScene, 0, 1);
        m_layout->addItem(m_timeSlider, 1, 0, 1, 2);
        m_layout->addItem(m_bottomScene, 2, 1);
    }
    QDate date = QDate::currentDate();
    date = date.addDays(-date.day() + 1);
    QDateTime time1(date);
    QDateTime time2(QDate(date.year(), date.month(), date.daysInMonth()));
    time2.setTime(QTime(23, 59, 59));
    EventPeriod period(time1.toTime_t(), time2.toTime_t());
    m_period = period;
    m_menu->setCurrentMenuItem(0);
    initHome();
    m_timeSlider->setPeriod(&m_period);
    m_timeSlider->monthButtonSlot();
}

void QTimeFrame::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    //QRectF g = contentsRect();
    //painter->drawRoundedRect(g.left(), g.top(), g.width(), g.height(), 5, 5);

    QGraphicsWidget::paint(painter, option, widget);
}



void QTimeFrame::setNewPeriod(EventPeriod* period)
{
    if (!period) return;
    if (m_period == *period) return;

    m_period = *period;

    // нужно установить в соответствующей сцене новый период просто и обновить сцену
    int id = m_menu->currentMenuItem();
    switch (id)
    {
    default:
    case HomeMenuItem:
        m_topScene->setPeriod(&m_period);
        m_bottomScene->setPeriod(&m_period);
        break;

    case PhotoMenuItem:
    case VideoMenuItem:
    case DocumentMenuItem:
        m_topScene->setPeriod(&m_period);
        break;
    };
};

void QTimeFrame::initHome()
{
    if (!m_bottomScene->isVisible())
    {
        m_bottomScene->show();
        m_layout->addItem(m_bottomScene, 2, 1);
    }

    ShowEventType set;

    // top scene
    set.showType = Cloud;
    set.alignmentCaption = Qt::AlignTop;
    set.eventType = Video;
    set.eventName = i18n("VIDEO");
    list<ShowEventType> showList;
    showList.push_back(set);

    set.eventType = Image;
    set.eventName = i18n("PHOTO");
    set.alignmentCaption = Qt::AlignTop;
    showList.push_back(set);

    m_topScene->init(&showList, &m_period);
    //m_topScene->setStrechFactor(0,5);
    //m_topScene->setStrechFactor(1,6);

    // bottom scene
    set.eventType = Document;
    set.eventName = i18n("DOCUMENTS");
    set.alignmentCaption = Qt::AlignBottom;
    showList.clear();
    showList.push_back(set);
    m_bottomScene->init(&showList, &m_period);
};

void QTimeFrame::initPhotos()
{
    if (m_bottomScene->isVisible())
    {
        m_bottomScene->hide();//
        m_layout->removeAt(3);
    }

    ShowEventType set = { Image, Gallery, i18n("PHOTO"), Qt::AlignTop };
    list<ShowEventType> showList;
    showList.push_back(set);
    m_topScene->init(&showList, &m_period);
};

void QTimeFrame::initVideo()
{
    if (m_bottomScene->isVisible())
    {
        m_bottomScene->hide();
        m_layout->removeAt(3);
    }

    ShowEventType set = { Video, Gallery, i18n("VIDEO"), Qt::AlignTop };
    list<ShowEventType> showList;
    showList.push_back(set);
    m_topScene->init(&showList, &m_period);
};


void QTimeFrame::initDocuments()
{
    if (m_bottomScene->isVisible())
    {
        m_bottomScene->hide();
        m_layout->removeAt(3);
    }

    ShowEventType set = { Document, Gallery, i18n("DOCUMENTS"), Qt::AlignTop };
    list<ShowEventType> showList;
    showList.push_back(set);
    m_topScene->init(&showList, &m_period);
};

void QTimeFrame::showHome()
{
    m_menu->setCurrentMenuItem(HomeMenuItem);
    initHome();
};

void QTimeFrame::showPhotos()
{
    m_menu->setCurrentMenuItem(PhotoMenuItem);
    initPhotos();
};

void QTimeFrame::showVideo()
{
    m_menu->setCurrentMenuItem(VideoMenuItem);
    initVideo();
};

void QTimeFrame::showDocuments()
{
    m_menu->setCurrentMenuItem(DocumentMenuItem);
    initDocuments();
};

void QTimeFrame::reset()
{
    m_topScene->clearScene();
    m_bottomScene->clearScene();
}

void QTimeFrame::setResetCallback()
{
    if(QApplication::activeWindow() != NULL)
        m_resetCallbackSet = connect((QObject*)QApplication::activeWindow(), SIGNAL(hiden()), this, SLOT(reset()));
    if(m_resetCallbackSet)
      m_resetCallbackTimer->stop();
}


void QTimeFrame::slotConfigure()
{
    QStringList args;
    args << "kcm_nepomuk";
    KToolInvocation::kdeinitExec("kcmshell4", args);
}
