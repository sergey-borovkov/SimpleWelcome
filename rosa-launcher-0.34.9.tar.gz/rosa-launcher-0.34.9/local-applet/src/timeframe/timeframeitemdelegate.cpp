/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *   Julia Mineeva <julia.mineeva@osinit.ru>
 *   Evgeniy Augin <evgeniy.augin@osinit.ru>
 *   Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "timeframeitemdelegate.h"
//#include <kcolorscheme.h>
#include <kfileitem.h>
#include <kdirmodel.h>

//#include <kglobalsettings.h>
#include <kicon.h>
#include <kjob.h>
//#include <kiconloader.h>
//#include <kstringhandler.h>


#include <QAbstractItemModel>
#include <QAbstractProxyModel>

#include <QDebug>
#include <QPainter>
#include <QImage>
#include <QModelIndex>
#include <QtSvg/QSvgRenderer>

TimeFrameItemDelegate::TimeFrameItemDelegate(QObject* parent) :
    KFileItemDelegate(parent),
    m_hash(0)

{
    setJobTransfersVisible(true);
    m_hash = new QHash<QString,Preview>;
}

TimeFrameItemDelegate::~TimeFrameItemDelegate()
{
    if (m_hash)
    {
        m_hash->clear();
        delete m_hash;
        m_hash = 0;
    }
    emit resetJob();
}

void TimeFrameItemDelegate::paint(QPainter* painter,
                                    const QStyleOptionViewItem& option,
                                    const QModelIndex& index) const
{
    KFileItemDelegate::paint(painter, option, index);
    const QAbstractProxyModel* proxyModel = static_cast<const QAbstractProxyModel*>(index.model());
    const KDirModel* kModel = static_cast<const KDirModel*>(proxyModel->sourceModel());
    const KFileItem item = kModel->itemForIndex(index);
    QHash<QString,Preview>::iterator it;
    if (!m_hash->contains(item.localPath()))
    {
           Preview pr;
           pr.item = item;
           QImage image;
           image.load(":/icons/pla-empty-box.png");
           pr.image = image;
           pr.index = index;
           m_hash->insert(item.localPath(),pr);
           KFileItemList klist;
           klist.append(item);
           QStringList list = KIO::PreviewJob::availablePlugins();
           KIO::PreviewJob* job = KIO::filePreview(klist, 100,0 , 0, 0, true, true, &list);
           connect(job, SIGNAL(gotPreview(const KFileItem&, const QPixmap&)),
                   this, SLOT(setPreview(const KFileItem&, const QPixmap&)));
           connect(job, SIGNAL(failed(const KFileItem&)), this, SLOT(setNullIcon(const KFileItem&)));
           connect(this, SIGNAL(resetJob()), job, SLOT(kill()));
     }
    it = m_hash->find(item.localPath());
    if (it == m_hash->end())
    {
        return;
    }else
    {

        const QRect rect = iconRect(option, index);
        QImage image = (*it).image;
        image = image.scaled(QSize(rect.width(), rect.height()), Qt::KeepAspectRatio, Qt::SmoothTransformation);
      //  KFileItemDelegate::paint(painter, option, index);
        painter->drawImage(rect.left() + (rect.width() - image.width())/2, rect.top() + (rect.height() - image.height())/2, image);
    }
}

void TimeFrameItemDelegate::reset()
{
    m_hash->clear();
    emit resetJob();
}

//Set Thumbs
void TimeFrameItemDelegate::setPreview(const KFileItem& item, const QPixmap& pix)
{
    //qDebug("Preview ok");
    QString mimeType = item.mimetype();
    QPixmap image = pix;
    //Draw Play icon on videos thumbs
    if (mimeType.contains("video"))
    {
        QSvgRenderer svgr(QString(":/icons/pla-empty-str.svg"));
        QPainter p(&image);
        QRectF rect(image.width()/3,(image.height()-(image.width()/3))/2,image.width()/3,image.width()/3);
        svgr.render(&p,rect);
        p.end();
    }
    QHash<QString,Preview>::iterator it;
    it = m_hash->find(item.localPath());
    if (it == m_hash->end()) return;
    (*it).image = image.toImage();
    if ((*it).index.isValid())
        emit iconChanged((*it).index);
    //emit iconChanged((*it).item);
}
//Set KDE icons
void TimeFrameItemDelegate::setNullIcon(const KFileItem& item)
{
    //qDebug("Preview failed");
    QHash<QString,Preview>::iterator it;
    it = m_hash->find(item.localPath());
    if (it == m_hash->end()) return;
    KIcon icon(item.iconName(), 0, item.overlays());
    QImage image = icon.pixmap(100).toImage();
    (*it).image = image;
    if ((*it).index.isValid())
        emit iconChanged((*it).index);
    //emit iconChanged((*it).item);
}

