/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *   Julia Mineeva <julia.mineeva@osinit.ru>
 *   Evgeniy Augin <evgeniy.augin@osinit.ru>
 *   Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#ifndef __nepomukactivitysource_h_
#define __nepomukactivitysource_h_

// std
#include <list>

// QT
#include <QHash>
#include <QTimer>

// KDE
#include <kurl.h>
#include <kfileitem.h>

// nepomuk
#include <nepomuk/query.h>
#include <nepomuk/andterm.h>
#include <nepomuk/queryserviceclient.h>

// local
#include "activityeventssource.h"

using namespace std;

class ActivityEvent;
class EventFilter;
//class KDirModel;
class TimeFrameDirModel;
class TimeFrameDirLister;

class NepomukActivitySource : public ActivityEventsSource
{
    Q_OBJECT
public:

    NepomukActivitySource();
    ~NepomukActivitySource();
    bool getEvents(const EventFilter* filter);
    //KDirModel* getDirModel() { return m_model; };
    TimeFrameDirModel* getDirModel() { return m_model; }
    Nepomuk::Query::AndTerm getResultTerm(const EventFilter* filter);
    TimeFrameDirLister* getLister(){return m_lister;}

private slots:

    void newItems(const KUrl &url, const KFileItemList & list);
    void repeatSearch();
    void finishSearch();
    void startSearch();

signals:

    void signalNewEvent(ActivityEvent*);
    void searchFinished();

private:

    //Nepomuk::Query::QueryServiceClient* m_searchClient;
    TimeFrameDirLister* m_lister;
    EventType getFileType(QString);
    //QStringList imageExt;
    //QStringList videoExt;
    QHash<QString, KFileItem> m_hash;
    KUrl m_queryUrl;
    QTimer* m_startTimer;
    list<int> m_minList;
    //KDirModel* m_model;
    TimeFrameDirModel* m_model;

};

#endif // __nepomukactivitysource_h_
