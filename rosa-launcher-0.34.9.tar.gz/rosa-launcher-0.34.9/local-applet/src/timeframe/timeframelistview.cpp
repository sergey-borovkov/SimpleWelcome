/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

// local
#include "timeframelistview.h"

#include "timeframestyle_p.h"

// QT
#include <QListView>
#include <QScrollBar>
#include <QProcess>
#include <QApplication>

// Plasma
#include <Plasma/Theme>

// KDE
#include <kcolorutils.h>
#include <kfileitemdelegate.h>
#include <kdirmodel.h>
#include <klocale.h>


class TimeFrameListViewPrivate
{
public:
    TimeFrameStyle::Ptr style;
};

TimeFrameListView::TimeFrameListView(QGraphicsWidget *parent)
    : QGraphicsProxyWidget(parent)
    , m_process(0)
    , d(new TimeFrameListViewPrivate)
    , m_delegate(0)
{
    QListView* native = new QListView();

    native->setViewMode(QListView::IconMode);
    native->setIconSize(QSize(100, 100));
    //native->setSpacing(20);
    native->setGridSize(QSize(160, 160));
    native->setUniformItemSizes(true);
    //  native->setLayoutMode(QListView::Batched);
    native->setResizeMode(QListView::Adjust);
    native->setMovement(QListView::Static);
    native->setEditTriggers(QAbstractItemView::NoEditTriggers);
    native->viewport()->setAttribute(Qt::WA_NoSystemBackground);
    native->setFrameStyle(QFrame::NoFrame);
    native->setSelectionMode(QAbstractItemView::NoSelection);
    native->setWordWrap(true);

    QPalette palette = native->palette();
    //palette.setColor(QPalette::WindowText, Plasma::Theme::defaultTheme()->color(Plasma::Theme::TextColor));
    // palette.setColor(QPalette::BrightText, Plasma::Theme::defaultTheme()->color(Plasma::Theme::HighlightColor));
    //  palette.setColor(QPalette::HighlightedText, Plasma::Theme::defaultTheme()->color(Plasma::Theme::HighlightColor));
    palette.setColor(QPalette::Text, Plasma::Theme::defaultTheme()->color(Plasma::Theme::TextColor));
    //  palette.setColor(QPalette::HighlightedText, Plasma::Theme::defaultTheme()->color(Plasma::Theme::HighlightColor));
    native->setPalette(palette);

    d->style = TimeFrameStyle::sharedStyle();
    native->verticalScrollBar()->setStyle(d->style.data());
    native->horizontalScrollBar()->setStyle(d->style.data());

    QString stylesheet = "";
    stylesheet += "QListView::item {background-image: transparent; background-color: transparent;padding: 0px; color: black;}";
    //    stylesheet += "QListView::item:selected {background-image: transparent; background-color: transparent;padding: 0px;color: black;}";
    //    stylesheet += "QListView::item:selected:active {background-image: transparent;background-color: transparent; color: black;}";
    //    stylesheet += "QListView::item:selected:!active {background-image: transparent;background-color: transparent; color: black;}";
    //  stylesheet += "QListView::item:selected { border: 1px solid #6a6ea9; }";
    stylesheet += "QListView::item:hover {background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #FAFBFE, stop: 1 #DCDEF1);}";

    native->setStyleSheet(stylesheet);
/*
#if 1
    TimeFrameItemDelegate *m_delegate = new TimeFrameItemDelegate(this);
    native->setItemDelegate(m_delegate);
    //TimeFrameItemDelegate::InformationList list;
    //list << TimeFrameItemDelegate::ModificationTime << TimeFrameItemDelegate::Size;
    //delegate->setShowInformation(list);
    m_delegate->setShowToolTipWhenElided(true);
#else
    KFileItemDelegate *delegate = new KFileItemDelegate(this);
    native->setItemDelegate(delegate);
    //    KFileItemDelegate::InformationList list;
    //    list << KFileItemDelegate::ModificationTime << KFileItemDelegate::Size;
    //    delegate->setShowInformation(list);
    delegate->setShowToolTipWhenElided(true);
//    delegate->setWrapMode(QTextOption::NoWrap);
#endif
*/
    setWidget(native);
    //connect(m_delegate,SIGNAL(iconChanged(QModelIndex)),native,SLOT(update(QModelIndex)));
  //  connect(m_delegate,SIGNAL(iconChanged(QModelIndex)),this,SLOT(iconChanged(QModelIndex)));
    connect(nativeWidget(), SIGNAL(clicked(const QModelIndex&)), this, SLOT(itemClicked(const QModelIndex&)));
};

TimeFrameListView::~TimeFrameListView()
{
    delete d;
    TimeFrameStyle::doneWithSharedStyle();
    if (m_delegate)
    {
        delete m_delegate;
        m_delegate = 0;
    }
};

void TimeFrameListView::itemClicked(const QModelIndex& index)
{
    KDirModel* model = static_cast<KDirModel*>(nativeWidget()->model());
    const KFileItem item = model->itemForIndex(index);

    QString program = "/usr/bin/kioclient";
    QStringList arguments;

    arguments << "exec" << item.localPath();

    if (m_process == 0)
    {
        m_process = new QProcess(this);

        m_process->start(program, arguments);
        m_process->waitForStarted();
    }
    else if(m_process->state() == QProcess::NotRunning)
    {
        delete m_process;

        m_process = new QProcess(this);

        m_process->start(program, arguments);
        m_process->waitForStarted();
    }
};

void TimeFrameListView::iconChanged(const QModelIndex& index)
{
   // nativeWidget()->dataChanged(index,index);
    //if index.parent()
   // nativeWidget()->update(index);
}

void TimeFrameListView::reset()
{
  //  if (!nativeWidget())
   // {
     //   return;
   // }
    //TimeFrameItemDelegate* delegate = static_cast<TimeFrameItemDelegate*>(nativeWidget()->itemDelegate());
    //if (delegate)
      //  delegate->reset();
}

void TimeFrameListView::setModel(QAbstractItemModel* model)
{
    nativeWidget()->setModel(model);
};

QAbstractItemModel* TimeFrameListView::model()
{
    return nativeWidget()->model();
};

QListView* TimeFrameListView::nativeWidget()
{
  return static_cast<QListView*>(widget());
};
