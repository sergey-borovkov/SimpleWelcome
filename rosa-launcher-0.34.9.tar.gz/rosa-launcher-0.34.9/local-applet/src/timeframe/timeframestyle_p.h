/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *   Julia Mineeva <julia.mineeva@osinit.ru>
 *   Evgeniy Augin <evgeniy.augin@osinit.ru>
 *   Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef TIMEFRAMESTYLE_P_H
#define TIMEFRAMESTYLE_P_H


#include <QtCore/QSharedData>
#include <QtGui/QCommonStyle>

#include <ksharedptr.h>

class TimeFrameStylePrivate;

class TimeFrameStyle : public QCommonStyle, public QSharedData
{
    Q_OBJECT

public:
    typedef KSharedPtr<TimeFrameStyle> Ptr;

    static TimeFrameStyle::Ptr sharedStyle();
    static void doneWithSharedStyle();

    explicit TimeFrameStyle();
    ~TimeFrameStyle();

    void drawPrimitive(PrimitiveElement element, const QStyleOption *option, QPainter *painter, const QWidget *widget = 0) const;

protected:
    void drawComplexControl(ComplexControl control,
                            const QStyleOptionComplex *option,
                            QPainter *painter,
                            const QWidget *widget) const;

    int pixelMetric(PixelMetric metric, const QStyleOption *option = 0, const QWidget *widget = 0) const;
    QRect subControlRect(ComplexControl control, const QStyleOptionComplex *option,
                         SubControl subControl, const QWidget *widget) const;

    QRect subElementRect(SubElement element, const QStyleOption * option, const QWidget *widget = 0) const;
    QSize sizeFromContents(ContentsType, const QStyleOption *option, const QSize &contentsSize,
                           const QWidget *widget = 0) const;
private:
    TimeFrameStylePrivate *d;
};



#endif // TIMEFRAMESTYLE_P_H
