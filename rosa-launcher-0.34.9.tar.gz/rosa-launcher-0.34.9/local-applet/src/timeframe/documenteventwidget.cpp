/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#include "documenteventwidget.h"
#include "activityeventssource.h"

#include <QPainter>
#include <QStringList>
#include <KIcon>

#include <kio/previewjob.h>
#include <kio/filejob.h>
#include <kurl.h>
#include <kfileitem.h>
#include <klocale.h>
#include <QDebug>


QDocumentEventWidget::QDocumentEventWidget(QGraphicsItem* parent, Qt::WindowFlags wFlags)
  : QActivityEventWidget(parent, wFlags)
{
    setContentsMargins(5,5,5,5);
    m_image.load(":/icons/pla-empty-box.png");
}

QDocumentEventWidget::~QDocumentEventWidget()
{
}

void QDocumentEventWidget::init(ActivityEvent *event, const QRectF &widgetRect)
{
  QActivityEventWidget::init(event, widgetRect);

  if (!event) return;

  QString ttText = i18n("%1\nrating: %2", QString::fromLocal8Bit(event->text().c_str()), event->rate());
  setToolTip(ttText);

  getEventThumb(event);
}

void QDocumentEventWidget::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
    if (!isVisible())
    {
        return;
    }
    QRectF g = contentsRect();
    QImage image;
    if (!m_image.isNull())
    {
        image = m_image.scaled(QSize(g.width(), g.height()), Qt::KeepAspectRatio, Qt::SmoothTransformation);
        painter->drawImage(g.left() + (g.width() - image.width())/2,g.top() + (g.height() - image.height())/2, image);
    }
    QActivityEventWidget::paint(painter, option, widget);
}

void QDocumentEventWidget::showPreview(const KFileItem&, const QPixmap& pix)
{
    m_image = pix.toImage();
    update();
}

void QDocumentEventWidget::getEventThumb(ActivityEvent* event)
{
  KUrl item(QString::fromLocal8Bit(event->url().data()));
  KFileItem kitem(KFileItem::Unknown, KFileItem::Unknown, item, false);
  KFileItemList klist;
  klist.append(kitem);
  QStringList list = KIO::PreviewJob::availablePlugins();
 // for (int i = 0; i< list.size(); ++i)
   //   qDebug() << list[i];
  KIO::PreviewJob* job = KIO::filePreview(klist, 256,0 , 0, 0, true, true, &list);
  job->setIgnoreMaximumSize(true);
  connect(job, SIGNAL(gotPreview(const KFileItem&, const QPixmap&)),
          this, SLOT(showPreview(const KFileItem&, const QPixmap&)));
  connect(job, SIGNAL(failed(const KFileItem&)), this, SLOT(setNullIcon(const KFileItem&)));
}

void QDocumentEventWidget::setNullIcon(const KFileItem& item)
{
  KIcon icon(item.iconName(), 0, item.overlays());
  m_image = icon.pixmap(256).toImage();
  update();
}


