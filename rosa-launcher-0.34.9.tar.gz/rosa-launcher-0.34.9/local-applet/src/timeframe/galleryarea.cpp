/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

// local
#include "galleryarea.h"

#include "timeframelistview.h"
#include "timeframedirmodel.h"
#include "timeframedirlister.h"
#include "timeframeitemdelegate.h"

// QT
#include <QListView>
#include <QGraphicsLinearLayout>
#include <QStringList>
#include <QModelIndex>
#include <QAbstractProxyModel>


// KDE
//#include <kfilepreviewgenerator.h>
#include <kdirlister.h>

// KIO
#include <kio/previewjob.h>
#include </usr/include/kfileitem.h>

QGalleryArea::QGalleryArea(QGraphicsItem *parent, Qt::WindowFlags wFlags)
    : QActivityEventsArea(parent, wFlags)
    , m_view(0)
    , m_model(0)
    , m_delegate(0)
{
    setupWidgets();
};

QGalleryArea::~QGalleryArea()
{
    if (m_view)
    {
        delete m_view;
        m_view =0;
    }
    if (m_model)
    {
        m_model->dirLister()->stop();
        delete m_model;
        m_model =0;
    }
    if (m_delegate)
    {
        delete m_delegate;
        m_delegate =0;
    }
}

void QGalleryArea::setupWidgets()
{
    // create list view
    m_view = new TimeFrameListView();

    // create and set model
    TimeFrameDirModel* m_model = m_nepomukSource->getDirModel();
    m_model->setJobTransfersVisible(true);

    m_view->nativeWidget()->setModel(m_model);

    m_delegate = new TimeFrameItemDelegate();
    m_delegate->setShowToolTipWhenElided(true);

    m_view->nativeWidget()->setItemDelegate(m_delegate);

    connect(m_delegate,SIGNAL(iconChanged(QModelIndex)),this,SLOT(updateIcon(QModelIndex)) );
};

void QGalleryArea::clearArea()
{
    m_delegate->reset();
    m_view->nativeWidget()->scrollToTop();
}

void QGalleryArea::updateIcon(const KFileItem& item)
{
    //m_view->nativeWidget()-
    //QModelIndex index = m_model->indexForItem(item);
    //if (index.isValid())
       // m_view->nativeWidget()->update(index);
}

void QGalleryArea::updateIcon(const QModelIndex& index)
{
    QModelIndex ind = m_view->nativeWidget()->model()->index(index.row(),index.column());
    if (ind.isValid())
        m_view->nativeWidget()->update(ind);
}

void QGalleryArea::stopAnimation()
{
    m_animationLabel->hide();
    m_view->show();
    m_layout->removeItem(m_animationLabel);
    m_layout->addItem(m_view);

};

void QGalleryArea::startAnimation()
{
    m_animationLabel->show();
    m_view->hide();
    m_layout->removeItem(m_view);
    m_layout->addItem(m_animationLabel);

};

void QGalleryArea::showNewEvent(ActivityEvent* event)
{
//    qDebug("NEW EVENT");
};
