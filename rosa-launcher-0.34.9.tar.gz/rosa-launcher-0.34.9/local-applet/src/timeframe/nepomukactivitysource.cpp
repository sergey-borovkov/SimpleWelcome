/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
// std
#include <time.h>

// nepomuk
#include <nepomuk/comparisonterm.h>
#include <nepomuk/literalterm.h>
#include <nepomuk/orterm.h>
#include <nepomuk/resourcetypeterm.h>
#include <nepomuk/filequery.h>
#include <nepomuk/nfo.h>
#include <nepomuk/nie.h>
#include <nepomuk/resource.h>
#include <nepomuk/term.h>
//#include <nepomuk/result.h>

// Soprano
#include <Soprano/Vocabulary/NAO>
#include <Soprano/Model>
#include <Soprano/QueryResultIterator>

// QT
#include <QDateTime>
#include <QUrl>


#include <QFileInfo>
#include <QStringList>

// KDE
#include <kdatetime.h>
//#include <kdirmodel.h>

// local
#include "nepomukactivitysource.h"
#include "activityevent.h"
#include "timeframedirlister.h"
#include "timeframedirmodel.h"


using namespace Soprano;

NepomukActivitySource::NepomukActivitySource()
  : ActivityEventsSource()
{
    /*m_searchClient = new Nepomuk::Query::QueryServiceClient( this );

    connect(m_searchClient, SIGNAL(newEntries(const QList<Nepomuk::Query::Result>&)),this, SLOT(slotNewEntries(const QList<Nepomuk::Query::Result>&)));
    connect( m_searchClient, SIGNAL( resultCount(int) ), this, SLOT( slotTotalCount(int) ) );
    connect( m_searchClient, SIGNAL( finishedListing() ), this, SLOT( slotStopSearch() ) );
    imageExt << "png" << "jpg" << "bmp" << "gif" << "jpeg";
    videoExt << "avi" << "mpg" << "3gp" << "mkv";
    */

    m_lister = new TimeFrameDirLister();
    //m_lister->setAutoUpdate(true);
//    m_model = new KDirModel(this);
    m_model = new TimeFrameDirModel(this);
    m_model->setDirLister(m_lister);
    m_startTimer = new QTimer(this);

    connect(m_startTimer, SIGNAL(timeout()), this, SLOT(startSearch()));
    connect(m_lister, SIGNAL(itemsAdded(const KUrl &, const KFileItemList &)), this, SLOT(newItems(const KUrl &, const KFileItemList & ) ) );
    connect(m_lister, SIGNAL(completed()), this, SLOT(finishSearch( ) ) );
    connect(m_lister, SIGNAL(errorMessage(QString)), this, SLOT(repeatSearch( ) ) );

};
NepomukActivitySource::~NepomukActivitySource()
{

    if (m_lister)
    {
        delete m_lister;
        m_lister=0;
    }
    if (m_model)
    {
        delete m_model;
        m_model=0;
    }
    if (m_startTimer)
    {
        delete m_startTimer;
        m_startTimer=0;
    }
}

bool NepomukActivitySource::getEvents(const EventFilter* eventFilter)
{
#if 0
  qDebug("NepomukActivitySource::getEvents():");
  QDateTime dtStart, dtEnd;
  dtStart.setTime_t(eventFilter->period().startTime());
  dtEnd.setTime_t(eventFilter->period().endTime());
  qDebug("   period:   startTime = %s", dtStart.toString("dd.MM.yyyy hh:mm:ss").toLocal8Bit().data());
  qDebug("             endTime   = %s", dtEnd.toString("dd.MM.yyyy hh:mm:ss").toLocal8Bit().data());
#endif

  m_hash.clear();
  m_minList.clear();
  m_lister->stop();
  if (m_startTimer->isActive())
      m_startTimer->stop();
  Nepomuk::Query::FileQuery query( getResultTerm(eventFilter));
  query.setFileMode(Nepomuk::Query::FileQuery::QueryFiles);
  QStringList mimeList;
  if (eventFilter->type() == Document)
  {
    mimeList << "application/msword" << "application/pdf" << "application/vnd.oasis.opendocument.text" << "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    m_lister->setMimeFilter(mimeList);
  } else
      m_lister->clearMimeFilter();
  m_queryUrl = query.toSearchUrl();
  if (m_queryUrl.isValid() && !m_queryUrl.isEmpty())
  {
      m_startTimer->start(1000);
      return true;
  }
  else
  {
      qDebug("invalid url");
      return false;
  }
};

void NepomukActivitySource::startSearch()
{
    m_startTimer->stop();
    m_lister->openUrl(m_queryUrl);
}

/*
  Return Nepomuk term
*/


Nepomuk::Query::AndTerm NepomukActivitySource::getResultTerm(const EventFilter* filter)
{

    Nepomuk::Query::ComparisonTerm startTimeTerm = Nepomuk::Vocabulary::NIE::lastModified() >
            Nepomuk::Query::LiteralTerm( QDateTime::fromTime_t(static_cast<unsigned int>(filter->period().startTime() ) ) );
    //qDebug("%s",QDateTime::fromTime_t(static_cast<unsigned int>(filter->period().startTime())).toString().toLocal8Bit().data());
    Nepomuk::Query::ComparisonTerm endTimeTerm = Nepomuk::Vocabulary::NIE::lastModified() <
            Nepomuk::Query::LiteralTerm( QDateTime::fromTime_t(static_cast<unsigned int>(filter->period().endTime() ) ) );
  //  qDebug("%s",QDateTime::fromTime_t(static_cast<unsigned int>(filter->period().endTime())).toString().toLocal8Bit().data());
        //Nepomuk::Query::AndTerm resTerm( startTimeTerm, endTimeTerm );
    Nepomuk::Query::AndTerm resTerm;
    resTerm.addSubTerm(startTimeTerm);
    resTerm.addSubTerm(endTimeTerm);
    EventType typeEvent = filter->type();
    Nepomuk::Query::OrTerm orTerm;
    if (typeEvent & Image)
    {
        Nepomuk::Query::ComparisonTerm image(Nepomuk::Vocabulary::NIE::mimeType(), Nepomuk::Query::LiteralTerm("image"));
        orTerm.addSubTerm(image);
    //    qDebug("add image term");
    }
    if (typeEvent & Video)
    {
        Nepomuk::Query::ComparisonTerm video(Nepomuk::Vocabulary::NIE::mimeType(), Nepomuk::Query::LiteralTerm("video"));
        orTerm.addSubTerm(video);
   //     qDebug("add video term");
    }
    if (typeEvent & Document)
    {
        //Nepomuk::Query::ComparisonTerm msword(Nepomuk::Vocabulary::NIE::mimeType(), Nepomuk::Query::LiteralTerm("application//msword"));
        Nepomuk::Query::ComparisonTerm pdf(Nepomuk::Vocabulary::NIE::mimeType(), Nepomuk::Query::LiteralTerm("application"));
        //Nepomuk::Query::ComparisonTerm odt(Nepomuk::Vocabulary::NIE::mimeType(), Nepomuk::Query::LiteralTerm("application//vnd.oasis.opendocument.text"));
        //Nepomuk::Query::ComparisonTerm docx(Nepomuk::Vocabulary::NIE::mimeType(), Nepomuk::Query::LiteralTerm("application//vnd.openxmlformats-officedocument.wordprocessingml.document"));
   //     orTerm.addSubTerm(msword);
        orTerm.addSubTerm(pdf);
  //      orTerm.addSubTerm(odt);
//        orTerm.addSubTerm(docx);

 //       qDebug("add document term");
    }

    resTerm.addSubTerm(orTerm);
//    qDebug("resTerm is: \n%s", resTerm.toString().toLocal8Bit().data());

    return resTerm;
}

/*
    Processing Nepomuk results
*/

void NepomukActivitySource::newItems(const KUrl &url, const KFileItemList & list)
{
    KFileItem item;
    bool send = false;
//    qDebug("new Event");
    for (int i=0; i< list.count(); ++i)
    {
        item = list[i];
        if (m_hash.contains(item.localPath()))
                continue;
        m_hash.insert(item.localPath(),item);

        Nepomuk::Resource res( item.localPath() );

        int rating = static_cast<int>(res.rating());
        if (m_minList.size() != 13)
        {
            m_minList.push_back(rating);
            send++;
        }else
        {

            std::list<int>::iterator it;
            int min=m_minList.front();
            for (it = m_minList.begin(); it != m_minList.end(); ++it )
            {
                if (min > (*it)) min = (*it);
            }
            if (rating > min)
            {
                for (it = m_minList.begin(); it != m_minList.end(); ++it )
                {
                    if (min == (*it)) m_minList.erase(it);
                }
                m_minList.push_back(rating);
                send++;
            }
        }
        if (send)
        {
            ActivityEvent* event = new ActivityEvent(string(item.localPath().toLocal8Bit().data( ) ),
                                                 string(item.text().toLocal8Bit().data()),
                                                 item.time(0),
                                                 "app",
                                                 rating,
                                                 getFileType(item.mimetype( ) ) );
                  //Send event
            //        qDebug("Local path %s",event->url().data());
            //        qDebug("Send Event");
            emit(signalNewEvent(event));
            send = false;
        }
     }
}

void NepomukActivitySource::repeatSearch()
{
    //qDebug("KDirLister error");
}

void NepomukActivitySource::finishSearch()
{
    KFileItemList list =  m_lister->items();
    emit(searchFinished());
    qDebug("result count: %d", list.count());
    m_lister->stop();
}

/*
    Return file type based on file extension
*/
EventType NepomukActivitySource::getFileType(QString mimeType)
{
    if (mimeType.contains("image/"))
        return Image;
    if (mimeType.contains("video/"))
        return Video;
    if (mimeType.contains("application/vnd.oasis.opendocument.text") ||
        mimeType.contains("application/pdf") ||
        mimeType.contains("application/vnd.openxmlformats-officedocument.wordprocessingml.document") ||
        mimeType.contains("application/msword"))
        return Document;

    return none;
 }

