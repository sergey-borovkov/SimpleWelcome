/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#ifndef __activityeventsource_h_
#define __activityeventsource_h_

#include <list>
#include <QObject>
using namespace std;

#include "activityevent.h"

class EventPeriod
{
public:
  EventPeriod()
    : m_startTime(0)
    , m_endTime(0)
  {
  };
  EventPeriod(time_t startTime, time_t endTime)
    : m_startTime(startTime)
    , m_endTime(endTime)
  {
  };

  bool operator==(const EventPeriod &ep) const
  {
    return (m_startTime == ep.startTime() && m_endTime == ep.endTime());
  };

  time_t startTime() const { return m_startTime; };
  void setStartTime(time_t st) { m_startTime = st; };

  time_t endTime() const { return m_endTime; };
  void setEndTime(time_t et) { m_endTime = et; };

private:
  time_t m_startTime;
  time_t m_endTime;

};

class EventFilter
{
public:
	EventFilter(EventType et, EventPeriod ep)
		: m_type(et)
		, m_period(ep)
	{};

	EventType type() const { return m_type; };
	void setType(EventType et) { m_type = et; };

	EventPeriod period() const { return m_period; };
	void setPeriod(EventPeriod ep) { m_period = ep; };

private:
	EventType   m_type;
	EventPeriod m_period;

};

class ActivityEventsSource : public QObject
{
    Q_OBJECT
public:
  ActivityEventsSource() {};
  virtual ~ActivityEventsSource() {};
  
  virtual bool getEvents(const EventFilter* eventFilter) = 0;
};

#endif // __activityeventsource_h_
