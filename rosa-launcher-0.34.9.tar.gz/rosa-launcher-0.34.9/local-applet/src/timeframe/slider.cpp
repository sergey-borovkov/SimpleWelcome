/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#include "slider.h"
#include <QString>
#include <QPainter>
#include <QRect>
#include <QRegion>
#include <QLayout>
#include <QPen>
#include <math.h>
#include <QDebug>
#include <QMouseEvent>
#include <klocalizedstring.h>

#include <plasma/theme.h>

Slider::Slider(QStringList namelist, QWidget *parent) :
    QSlider(parent)
{
    setOrientation(Qt::Horizontal);
    setMinimumHeight(60);
    setMinimumWidth(400);
    setTickPosition(QSlider::TicksBelow);

    setAttribute(Qt::WA_NoSystemBackground);

    m_namelist = namelist;
    m_tickCount = m_namelist.size();
    setMaximum(m_tickCount-1);
    setPageStep(1);
}

void Slider::paintEvent(QPaintEvent * event)
{
    QPainter painter;

    int wid = width();
    int heig = height();

    painter.begin(this);

    //Paint lines
    QPen pen(Qt::gray, 3, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    painter.setPen(pen);
    painter.drawLine(0,heig/2,wid-2,heig/2);
    int x=0,step,y0,y1;
    double tinc;
    tinc = static_cast<double>(width()) / m_tickCount;
    step = static_cast<int>(floor(tinc+0.5));

    if (m_tickCount < 15)
     {
        y0=heig/4;
        y1=(heig*3)/4;
     } else
    {
        y0=(heig*3)/8;
        y1=(heig*5)/8;
    }
    painter.drawLine(1,y0,1,y1);
    for (int i = 1; i < (m_tickCount); i++)
    {
        x=static_cast<int>(floor((tinc*i)+0.5));
        painter.drawLine(x,y0,x,y1);
    }
    painter.drawLine(wid-2,y0,wid-2,y1);

    //Paint text
    x=0;

    pen.setColor(Plasma::Theme::defaultTheme()->color(Plasma::Theme::TextColor));
    painter.setPen(pen);
    for (int i = 0; i < m_namelist.size(); ++i)
    {
        QRect rect(x, ((heig*3)/4)-3, step, heig/4);
        painter.drawText(rect, Qt::AlignCenter, m_namelist.at(i));
        x=static_cast<int>(floor((tinc*(i+1))+0.5));
    }
    painter.end();
    QSlider::paintEvent(event);
}


void Slider::resizeEvent ( QResizeEvent * event )
{
    updateStyle();
    QSlider::resizeEvent(event);
}

void Slider::updateStyle()
{
    QString css, sliderHandlerUrl;
    double tinc = static_cast<double>(width()) / m_tickCount;
    int step = static_cast<int>(floor(tinc+0.5));
    if (m_tickCount < 15)
        sliderHandlerUrl = ":/icons/slider.png";
    else
        sliderHandlerUrl = ":/icons/slidersmall.png";
    css.sprintf("QSlider::groove:horizontal { padding-left: %dpx; padding-right: %dpx ; background: transparent; top: -%dpx; } "
                "QSlider::handle:horizontal  {width: %dpx; image: url(%s); margin: 0 -%dpx}",
                step/2, step/2, height()-(height()/4), step, sliderHandlerUrl.toLocal8Bit().data(),step/2);
    setStyleSheet(css);
}

void Slider::setNewSkale(QStringList list)
{
    m_namelist = list;
    m_tickCount = m_namelist.size();
    setMaximum(m_tickCount-1);
    updateStyle();
    update();
}

void Slider::mousePressEvent ( QMouseEvent * event )
{
    if (event->button() == Qt::LeftButton)
    {
        if (orientation() == Qt::Vertical)
            setValue(minimum() + ((maximum()-minimum()) * (height()-event->y())) / height() ) ;
        else
        {
            int newValue = (minimum() + ((maximum()-minimum()) * static_cast<double>(event->x()) / static_cast<double>(width()))) + 0.5;
            if (newValue != value())
                setValue(newValue);
        }
            event->accept();
    }
   QSlider::mousePressEvent(event);
}

