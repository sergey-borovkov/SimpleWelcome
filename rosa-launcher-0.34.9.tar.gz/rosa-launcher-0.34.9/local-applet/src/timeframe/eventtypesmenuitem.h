/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#ifndef __eventtypesmenuitem_h_
#define __eventtypesmenuitem_h_

/*
 * Description of MenuBar class
 */

//#define __HOVER_INDICATOR__

#include <QColor>
#include <Plasma/Label>
#ifdef __HOVER_INDICATOR__
#include <Plasma/ItemBackground>
#endif
class QEventTypesMenuItem : public Plasma::Label
{
  Q_OBJECT

public:
  QEventTypesMenuItem(QGraphicsWidget* parent = 0);
  virtual ~QEventTypesMenuItem();

  void setChecked(bool checked);

protected:
  void hoverEnterEvent(QGraphicsSceneHoverEvent *);
  void hoverLeaveEvent(QGraphicsSceneHoverEvent *);

  void mousePressEvent(QGraphicsSceneMouseEvent *);
  void mouseReleaseEvent(QGraphicsSceneMouseEvent *);

  void setItemFont(int pointSize);
  void setItemPalette(const QColor& color);

signals:
  void clicked();

protected slots:
#ifdef __HOVER_INDICATOR__
  void setTarget();
#endif

private:
  bool m_checked;

#ifdef __HOVER_INDICATOR__
  Plasma::ItemBackground* m_hoverIndicator;
#endif
};

#endif // __eventypesmenuitem_h_
