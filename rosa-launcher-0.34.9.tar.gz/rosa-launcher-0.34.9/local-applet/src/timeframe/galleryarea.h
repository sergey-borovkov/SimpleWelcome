/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#ifndef __galleryarea_h_
#define __galleryarea_h_

#include "activityeventsarea.h"

class TimeFrameListView;
class TimeFrameDirModel;
class TimeFrameItemDelegate;
class QModelIndex;
class KFileItem;

class QGalleryArea : public QActivityEventsArea
{
    Q_OBJECT
public:
  QGalleryArea(QGraphicsItem *parent = 0, Qt::WindowFlags wFlags = 0);
  ~QGalleryArea();
  void setupWidgets();

public slots:
  virtual void stopAnimation();
  virtual void startAnimation();
  virtual void showNewEvent(ActivityEvent* event);
  void updateIcon(const KFileItem&);
  void updateIcon(const QModelIndex&);

protected:
   virtual void clearArea();

private:
  TimeFrameListView* m_view;
  TimeFrameDirModel* m_model;
  TimeFrameItemDelegate* m_delegate;
  //KFilePreviewGenerator* m_previewGenerator;
};

#endif // __galleryarea_h_
