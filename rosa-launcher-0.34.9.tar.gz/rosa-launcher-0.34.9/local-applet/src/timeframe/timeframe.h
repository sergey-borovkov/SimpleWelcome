/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *   Julia Mineeva <julia.mineeva@osinit.ru>
 *   Evgeniy Augin <evgeniy.augin@osinit.ru>
 *   Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#ifndef __timeframe_h_
#define __timeframe_h_

#include <QGraphicsWidget>
#include <QTimer>
//Plasma
#include <plasma/widgets/label.h>
#include <plasma/widgets/toolbutton.h>

#include "activityeventssource.h"

class QGraphicsGridLayout;
class QGraphicsLinearLayout;
class QGraphicsItem;
class QTimeSlider;
class QEventTypesMenu;
class ActivityEvent;
class QActivityEventsScene;

class QTimeFrame : public QGraphicsWidget
{
  Q_OBJECT
  
public:
  QTimeFrame(QGraphicsItem* parent = 0, Qt::WindowFlags wFlags = 0);
  virtual ~QTimeFrame();
  void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

protected:
  void initHome();
  void initPhotos();
  void initVideo();
  void initDocuments();

public slots:
  void tabActivated();
  void setResetCallback();
  void slotConfigure();

protected slots:
  void showHome();
  void showPhotos();
  void showVideo();
  void showDocuments();
  void reset();

  void setNewPeriod(EventPeriod* period);

private:
  QGraphicsGridLayout*        m_layout;
  QGraphicsLinearLayout*      m_lineLayout;
  QTimeSlider*                m_timeSlider;
  QEventTypesMenu*            m_menu;
  QActivityEventsScene*       m_topScene;
  QActivityEventsScene*       m_bottomScene;
  Plasma::ToolButton*         m_configButton;
  Plasma::Label*              m_sorryLabel;
  EventPeriod                 m_period;
  bool                        m_resetCallbackSet;
  QTimer *                    m_resetCallbackTimer;
  QGraphicsWidget*            m_warningWidget;

};

#endif // __timeframe_h_
