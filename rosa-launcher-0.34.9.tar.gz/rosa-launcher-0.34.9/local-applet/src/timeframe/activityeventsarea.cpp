/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
// local
#include "activityeventsarea.h"
#include "activityeventsscene.h"
#include "activityeventssource.h"
#include "activityevent.h"
#include "eventwidgetfactory.h"

// QT
#include <QGraphicsItem>
#include <QGraphicsGridLayout>
#include <QGraphicsLinearLayout>
#include <QPainter>
#include <QLabel>

QActivityEventsArea::QActivityEventsArea(QGraphicsItem *parent, Qt::WindowFlags wFlags)
  : QGraphicsWidget(parent, wFlags)
{
    setAttribute(Qt::WA_NoSystemBackground);
    connect(this, SIGNAL(geometryChanged()), this, SLOT(onGeometryChanged()));
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    setAcceptHoverEvents(true);
    m_hoverIndicator = new Plasma::ItemBackground(this);
    m_hoverIndicator->setZValue(-100);
    m_hoverIndicator->hide();

    m_animationLabel = new Plasma::Label(this);
    m_animationLabel->setAlignment(Qt::AlignCenter);
    m_animationLabel->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);
    m_movie = new QMovie(":/gif/44.gif");
    m_movie->start();
    m_animationLabel->nativeWidget()->setMovie(m_movie);
    m_layout = new QGraphicsLinearLayout(Qt::Vertical);
    m_layout->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    m_layout->addItem(m_animationLabel);
    setLayout(m_layout);
    m_nepomukSource = new NepomukActivitySource();

    connect(m_nepomukSource, SIGNAL(signalNewEvent(ActivityEvent*)), this, SLOT(showNewEvent(ActivityEvent*)));
    connect(m_nepomukSource, SIGNAL(searchFinished()), this, SLOT(stopAnimation()));
};

QActivityEventsArea::~QActivityEventsArea()
{
    clearArea();
    while (m_layout->count() > 0)
        m_layout->removeAt(0);
    delete m_movie;
    delete m_animationLabel;
    delete m_hoverIndicator;
    delete m_nepomukSource;
};

void QActivityEventsArea::onGeometryChanged()
{
};

void QActivityEventsArea::init(ShowEventType showEventType, const EventPeriod* period)
{
  m_showEventType = showEventType;
  m_period = period;

  // before placing need delete all widgets
  clearArea();
  EventFilter filter(showEventType.eventType, *period);
  m_nepomukSource->getEvents(&filter);
};

void QActivityEventsArea::setPeriod(const EventPeriod *period)
{
    m_period = period;

    clearArea();
    EventFilter filter(m_showEventType.eventType, *m_period);
    m_nepomukSource->getEvents(&filter);
    startAnimation();
    updateAreaGeometry();
    setWidgetsGeometry();
};

bool QActivityEventsArea::canShowEventWidget(const ActivityEvent* event)
{
  if (event->type() != m_showEventType.eventType) return false;
  if (!m_period) return false;
  return (event->dateTime() >= m_period->startTime() && event->dateTime() <= m_period->endTime());
}

QSizeF QActivityEventsArea::getWidgetSize()
{
    //widgetSize = QSizeF(_W_R(event->rate()), _H_R(event->rate()));
    return QSizeF(W_MIN, H_MIN);
};

void QActivityEventsArea::showNewEvent(ActivityEvent* event)
{
 //   qDebug("NEW EVENT");
  return;// (bool)(event);
};

void QActivityEventsArea::updateAreaGeometry()
{
};

// calculate widgets geometries
void QActivityEventsArea::setWidgetsGeometry()
{
};

// deleting all widgets
void QActivityEventsArea::clearArea()
{
    map<string, QActivityEventWidget*>::iterator it;
    for (it = m_widgetsMap.begin(); it != m_widgetsMap.end(); it++)
    {
      QActivityEventWidget* ew = (*it).second;
      if (ew) delete ew;
    }
    m_widgetsMap.clear();
};

void QActivityEventsArea::paint(QPainter* painter,
                                const QStyleOptionGraphicsItem* option,
                                QWidget* widget)
{
  //QRectF g = contentsRect();
  //painter->drawRoundedRect(g.left(), g.top(), g.width(), g.height(), 5, 5);

  QGraphicsWidget::paint(painter, option, widget);
};

void QActivityEventsArea::setTargetItem(QGraphicsWidget* item)
{
  m_hoverIndicator->setTargetItem(item);
};

void QActivityEventsArea::hoverLeaveEvent(QGraphicsSceneHoverEvent*)
{
  m_hoverIndicator->setTargetItem(NULL);
};

void QActivityEventsArea::stopAnimation()
{
    m_movie->stop();
    m_animationLabel->hide();
}
void QActivityEventsArea::startAnimation()
{
    m_movie->start();
    m_animationLabel->show();
}
