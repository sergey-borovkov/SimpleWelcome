/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#include "activityeventwidget.h"
#include "activityevent.h"

#include <QGraphicsItem>
#include <QGraphicsGridLayout>
#include <QProcess>
#include <QApplication>


QActivityEventWidget::QActivityEventWidget(QGraphicsItem* parent, Qt::WindowFlags wFlags)
  : QGraphicsWidget(parent, wFlags)
  , m_activityEvent(0)
  , m_process(0)
  , m_widgetRect(QRectF(0,0,0,0))
{
    setAcceptHoverEvents(true);
    setAcceptedMouseButtons(Qt::LeftButton);
};

QActivityEventWidget::~QActivityEventWidget()
{
};

void QActivityEventWidget::init(ActivityEvent *event, const QRectF &widgetRect)
{
    m_activityEvent = event;
    m_widgetRect = widgetRect;
};

void QActivityEventWidget::openEvent()
{
    QString program = "/usr/bin/kioclient";
    QStringList arguments;

    arguments << "exec" << QString("%1").arg(QString::fromLocal8Bit(m_activityEvent->url().c_str()));

    if(m_process == 0)
      {
        m_process = new QProcess(this);

        m_process->start(program, arguments);
        m_process->waitForStarted();
      }
    else if(m_process->state() == QProcess::NotRunning)
      {
        delete m_process;

        m_process = new QProcess(this);

        m_process->start(program, arguments);
        m_process->waitForStarted();
      }

  //  QMetaObject::invokeMethod(static_cast<QObject*>(QApplication::activeWindow()), "hideWindow");

};

void QActivityEventWidget::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
}

void QActivityEventWidget::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
     openEvent();
}

void QActivityEventWidget::hoverEnterEvent(QGraphicsSceneHoverEvent *)
{
  emit hoverEnter(static_cast<QGraphicsWidget*>(this));
};

void QActivityEventWidget::hoverLeaveEvent(QGraphicsSceneHoverEvent *)
{
  emit hoverLeave(static_cast<QGraphicsWidget*>(this));
};
