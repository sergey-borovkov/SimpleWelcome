/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#ifndef CLOUDLAYOUT_H
#define CLOUDLAYOUT_H

#include <QList>
#include <QRectF>
#include <string>
#include "activityevent.h"

using namespace std;

enum Status
{
  empty = 0,
  notFree,
  text
};

struct RectLayoutItem
{
    QRectF rect;
    Status status;
    int rate;
    string url;
};


class CloudLayout
{
public:
     CloudLayout(QRectF rect,int rectCount, Qt::Alignment alignmentCaption, EventType typeE = Multimedia);
    void setRectCount(int rectCount);
    QList<RectLayoutItem> rectList();

protected:
    int m_rectCount;
    QList<RectLayoutItem> m_list;
    QRectF m_rect;
    EventType m_typeE;
    Qt::Alignment m_alignmentCaption;
    RectLayoutItem createRectItem(float x,float y,float w,float h, Status stat = empty);
    void checkLayout();
    void normalizeRect();
    void createLayout1();
    void createLayout2();
    void createLayout3();
    void createLayout4();
    void createLayout5();
    void createLayout6();
    void createLayout7();
    void createLayout8();
    void createLayout9();
    void createLayout10();
    void createDocLayout();

};

#endif // CLOUDLAYOUT_H
