/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#include "eventtypesmenuitem.h"

#include <QLabel>
#include <QFont>
#include <QPainter>
#include <QStyleOptionGraphicsItem>

#include <Plasma/Theme>

#define __MENUITEM_INDENT__     17
#define __MENUITEM_FONT_SIZE__  13

QEventTypesMenuItem::QEventTypesMenuItem(QGraphicsWidget* parent)
  : Plasma::Label(parent)
  , m_checked(false)
{
  // установим отступ
  nativeWidget()->setIndent(__MENUITEM_INDENT__);

  // установим высоту шрифта и цвет текста
  setItemFont(__MENUITEM_FONT_SIZE__);
  setItemPalette(Plasma::Theme::defaultTheme()->color(Plasma::Theme::TextColor));

  setAcceptHoverEvents(true);
  setAcceptedMouseButtons(Qt::LeftButton);

#ifdef __HOVER_INDICATOR__
  m_hoverIndicator = new Plasma::ItemBackground(this);
  m_hoverIndicator->setZValue(-100);
  m_hoverIndicator->hide();

  connect(this, SIGNAL(geometryChanged()), this, SLOT(setTarget()));
#endif

};

QEventTypesMenuItem::~QEventTypesMenuItem()
{
};

#ifdef __HOVER_INDICATOR__
void QEventTypesMenuItem::setTarget()
{
  if (m_checked)
  {
    QRectF r = boundingRect();
    r.setWidth(r.width() + 50);
    m_hoverIndicator->setTarget(r);
  }
  else
    m_hoverIndicator->setTarget(QRectF());
};
#endif

void QEventTypesMenuItem::setChecked(bool checked)
{
  m_checked = checked;
  setItemPalette(Plasma::Theme::defaultTheme()->color(m_checked ? Plasma::Theme::VisitedLinkColor
                                                                : Plasma::Theme::TextColor));
#ifdef __HOVER_INDICATOR__
  setTarget();
#endif
};

void QEventTypesMenuItem::hoverEnterEvent(QGraphicsSceneHoverEvent *)
{
  setItemPalette(Plasma::Theme::defaultTheme()->color(Plasma::Theme::LinkColor));
  setCursor(Qt::PointingHandCursor);
};

void QEventTypesMenuItem::hoverLeaveEvent(QGraphicsSceneHoverEvent *)
{
  setItemPalette(Plasma::Theme::defaultTheme()->color(m_checked ? Plasma::Theme::VisitedLinkColor
                                                                : Plasma::Theme::TextColor));
  setCursor(Qt::ArrowCursor);
};

void QEventTypesMenuItem::setItemFont(int pointSize)
{
  QFont f = font();
  f.setPointSize(pointSize);
  setFont(f);
};

void QEventTypesMenuItem::setItemPalette(const QColor& color)
{
  QPalette palette = nativeWidget()->palette();
  palette.setColor(QPalette::WindowText, color);
  nativeWidget()->setPalette(palette);
};

void QEventTypesMenuItem::mousePressEvent(QGraphicsSceneMouseEvent *)
{
    setChecked(true);
};

void QEventTypesMenuItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *)
{
  emit clicked();
};
