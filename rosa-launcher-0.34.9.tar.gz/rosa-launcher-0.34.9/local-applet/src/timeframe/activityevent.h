/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#ifndef __activityevent_h_
#define __activityevent_h_

#include <string>
#include <time.h>

using namespace std;

enum EventTypeFlag {
    ImageFlag    = 0x01,
    VideoFlag    = 0x02,
    AudioFlag    = 0x04,
    MailFlag     = 0x08,
    DocumentFlag = 0x10
};

enum EventType {
  none = 0,
  Image = ImageFlag,
  Video = VideoFlag,
  Audio = AudioFlag,
  Mail = MailFlag,
  Document = DocumentFlag,
  Multimedia = ImageFlag | VideoFlag | AudioFlag,
  All = Mail | Multimedia | Document
};

class ActivityEvent
{
public:

  ActivityEvent(const string& url, const string& text, time_t dt,
				const string& app, int rate, EventType type)
	: m_url(url)
	, m_text(text)
	, m_dateTime(dt)
	, m_processingApp(app)
        , m_rate(rate)
	, m_type(type)
  {};

  virtual ~ActivityEvent() {};

  string url() const { return m_url; };
  void setUrl(const string& url) { m_url = url; };

  string text() const { return m_text; };
  void setText(const string& text) { m_text = text; };

  time_t dateTime() const { return m_dateTime; }
  void setDateTime(time_t t) { m_dateTime = t; };

  string processingApp() const { return m_processingApp; }
  void setProcessingApp(const string& app) { m_processingApp = app; };

  int rate() const { return m_rate; };
  void setRate(int rate) { m_rate = rate; };

  EventType type() const { return m_type; };
  void setType(EventType type) { m_type = type; };

private:
  string      m_url;
  string      m_text;
  time_t      m_dateTime;
  string      m_processingApp;
  int         m_rate;
  EventType   m_type;

};

#endif // __activityevent_h_
