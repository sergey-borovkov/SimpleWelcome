/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#ifndef __cloudarea_h_
#define __cloudarea_h_

#include "activityeventsarea.h"
#include "cloudlayout.h"

#include <Plasma/Label>

class QCloudArea : public QActivityEventsArea
{
    Q_OBJECT

public:
  QCloudArea(QGraphicsItem *parent = 0, Qt::WindowFlags wFlags = 0);

  virtual void init(ShowEventType showEventType, const EventPeriod* period);
  //virtual void setPeriod(const EventPeriod* period);

  void stopAnimation();

protected:
  virtual void setWidgetsGeometry();
  void updateAreaGeometry();
  virtual void clearArea();
  void updateRectLayout();

  bool itemExist(string url);
  bool graphicItemExist(string url);
  RectLayoutItem createRectItem(qreal x,qreal y,qreal w,qreal h);

public slots:
  void showNewEvent(ActivityEvent* event);

protected slots:
  virtual void onGeometryChanged();

protected:
  QList<RectLayoutItem> m_rectList;
  Plasma::Label* m_label;
  static const int m_widgetsCount;
  ActivityEvent* m_minRateEvent;
};

#endif // __cloudarea_h_
