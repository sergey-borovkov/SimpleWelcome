/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#include "cloudlayout.h"
#include "qdebug.h"

CloudLayout::CloudLayout(QRectF rect,int rectCount, Qt::Alignment alignmentCaption, EventType typeE)
{
    m_rect = rect;

    m_rectCount = rectCount;
    m_alignmentCaption = alignmentCaption;
    m_typeE = typeE;
    normalizeRect();
    //if (m_rectCount > 4 )
      //      m_rectCount = 2;
    if (typeE == Document)
    {
        createDocLayout();
    }
    if (typeE == Video)
    {
        switch(m_rectCount)
        {
        case 1:
            createLayout1();
            break;
        case 2:
            createLayout2();
            break;
        case 3:
            createLayout3();
            break;
        default:
            createLayout3();
        }
    }
    if (typeE == Image)
    {
        //createLayout4();

        switch(m_rectCount)
        {
        case 1:
            createLayout1();
            break;
        case 2:
            createLayout2();
            break;
        case 3:
            createLayout3();
            break;
        case 4:
            createLayout4();
            break;
        default:
            createLayout4();
         }

     }

    /*
    switch(m_rectCount)
    {
    case 1:
        createLayout1();
        break;
    case 2:
        createLayout2();
        break;
    case 3:
        createLayout3();
        break;
    case 4:
        createLayout4();
        break;
    default:
        createLayout10();
    }
    */
   // checkLayout();
}

QList<RectLayoutItem> CloudLayout::rectList()
{
    return m_list;
}

void CloudLayout::setRectCount(int rectCount)
{
    m_rectCount = rectCount;
}

RectLayoutItem CloudLayout::createRectItem(float x,float y,float w,float h, Status stat)
{
    QRectF rect(x,y,w,h);
    RectLayoutItem item;
    item.rect = rect;
    item.rate = 0;
    item.status = stat;
    return item;
}

void CloudLayout::checkLayout()
{
    //qDebug() << "m_rect " << m_rect.x() << ":" << m_rect.y() << "  " <<  m_rect.width() << ":" << m_rect.height();
    if (m_list.size() == 0)
        return;
    m_rect.setWidth(m_rect.width()+1);
    m_rect.setHeight(m_rect.height()+1);
    QList<RectLayoutItem>::iterator it;
    for(it = m_list.begin(); it!=m_list.end();++it)
    {
        //qDebug() << (*it).rect.x() << ":" << (*it).rect.y() << "  " <<  (*it).rect.width() << ":" << (*it).rect.height();
        if ((!m_rect.contains((*it).rect)) && ((*it).status != text))
            m_list.erase(it);
            //qDebug("Erase");
    }
    //qDebug("end of check");
}

void CloudLayout::normalizeRect()
{
    double w = m_rect.width();
    double h = m_rect.height();
    double w1,h1,x1,y1, ratio;
    if (m_typeE == Video)
        ratio = 2.;
    else
        ratio = 2.3;

    if ( (w/h) < ratio )
    {
        h1 = w/ratio;
        w1 = w;
        y1 = m_rect.top() + ((h-h1)/2);
        x1 = m_rect.left();
        m_rect.setRect(x1,y1,w1,h1);
    }
}

void CloudLayout::createLayout1()
{
    QRectF g = m_rect;
    RectLayoutItem item1 = createRectItem( g.left() + g.width()/2 - (((g.height()*5)/6)*4)/6,
                                          (m_alignmentCaption & Qt::AlignTop
                                           ? g.top()
                                           : g.top() + g.height()/6 ),
                                          (((g.height()*5)/6)*4)/3,
                                          (g.height()*5)/6);

    RectLayoutItem text1 = createRectItem(item1.rect.left(),
                                          (m_alignmentCaption & Qt::AlignTop
                                           ? g.top() + (g.height()*5)/6
                                           : g.top()),
                                           item1.rect.width(),
                                           g.height()/6,
                                           text);
    m_list << item1 << text1;

}

void CloudLayout::createLayout2()
{
    QRectF g = m_rect;
    double margin = 0;

    RectLayoutItem item1 = createRectItem( g.left() + g.width()/2 - (((( (g.height()*2) / 3)*4)/3)*6)/7,
                                           g.top() + g.height()/6,
                                          (((g.height()*2)/3)*4)/3,
                                          (g.height()*2)/3);

    RectLayoutItem item2 = createRectItem(item1.rect.right() + margin,
                                          (m_alignmentCaption == Qt::AlignTop
                                           ? g.top()
                                           : g.top() + g.height()/2),
                                          ((g.height()/2)*4)/3,
                                          g.height()/2);

    RectLayoutItem text1 = createRectItem(item1.rect.right(),
                                          (m_alignmentCaption == Qt::AlignTop
                                           ? g.top() + (g.height()*3)/4 - g.height()/12
                                           : g.top() + g.height()/4 - g.height()/12 ),
                                           item2.rect.width(),
                                           g.height()/6,
                                           text);

    m_list << item1 << item2 << text1;
}

void CloudLayout::createLayout3()
{
    QRectF g = m_rect;
    double margin = 0;

    RectLayoutItem item1 = createRectItem((g.left()+(g.width()*9)/20),

                                          g.top(),

                                          (((g.height()*5)/6)*4)/3,
                                          (g.height()*5)/6);

    RectLayoutItem text1 = createRectItem(item1.rect.left(),
                                          (m_alignmentCaption & Qt::AlignTop
                                           ? item1.rect.bottom()
                                           : g.top()),

                                          item1.rect.width(),
                                          g.height()/6,
                                          text);

    RectLayoutItem item2 = createRectItem(item1.rect.left() - margin -((g.height()/2)*4)/3,
                                          item1.rect.top() + (item1.rect.height())/2,
                                          ((g.height()/2)*4)/3,
                                          g.height()/2);

    RectLayoutItem item3 = createRectItem(item1.rect.left() - margin - ((g.height()/3)*4)/3,
                                          item1.rect.top(),
                                          ((g.height()/3)*4)/3,
                                           g.height()/3);

    m_list << item1 << item2 << item3 << text1;

}
void CloudLayout::createLayout4()
{
    QRectF g = m_rect;
    double margin = 5;

    RectLayoutItem item1 = createRectItem((g.left()+g.width()/2) - (((g.height()*7)/10)*4)/6,
                                          (m_alignmentCaption & Qt::AlignTop
                                           ? g.top()+(g.height())/10
                                           : g.bottom()-(g.height())/10-(g.height()*7)/10),
//                                          g.top()+(g.height())/10,
                                          (((g.height()*7)/10)*4)/3,
                                          (g.height()*7)/10);

    RectLayoutItem text1 = createRectItem(item1.rect.left(),
                                          (m_alignmentCaption & Qt::AlignTop
                                           ? item1.rect.bottom()
                                           : g.top()),
//                                          item1.rect.bottom(),
                                          item1.rect.width(),
                                          g.bottom()-item1.rect.bottom(),
                                          text);

    RectLayoutItem item2 = createRectItem(item1.rect.right() + margin,
                                          g.top(),
                                          ((g.height()/2)*4)/3,
                                          g.height()/2);

    RectLayoutItem item3 = createRectItem(item1.rect.left() - margin - (((g.height()*2)/5)*4)/3,
                                          g.top() + g.height()/2 + margin,
                                          (((g.height()*2)/5)*4)/3,
                                           (g.height()*2)/5);

    RectLayoutItem item4 = createRectItem(item1.rect.right() + margin,
                                          item3.rect.top(),
                                          (((g.height()*2)/5)*4)/3,
                                           (g.height()*2)/5);

    //RectLayoutItem item5 = createRectItem(g.left()+g.width()/3 + (g.height()*4)/3, g.top() + g.height()/2, ((g.height()/2)*4)/3, g.height()/2);

    m_list << item1 << item2 << item3 << item4 << text1;// << item5;

}
void CloudLayout::createLayout5()
{

}
void CloudLayout::createLayout6()
{

}
void CloudLayout::createLayout7()
{

}

void CloudLayout::createLayout8()
{

}

void CloudLayout::createLayout9()
{

}

void CloudLayout::createLayout10()
{
    QRectF g = m_rect;
    double margin = g.height()/17;
    double hmargin = margin;//g.width()/17;
    double w1,h1,w2,h2,w3,h3,w4,h4,w5,h5,tw,th;

    h1 = 10*g.height()/17;
    w1 = (h1*4)/3;

    h2 = 6*g.height()/17;
    w2 = (h2*4)/3;

    h3 = 5*g.height()/17;
    w3 = (h3*4)/3;

    h4 = 4*g.height()/17;
    w4 = (h4*4)/3;

    h5 = 3*g.height()/17;
    w5 = (h5*4)/3;

    tw = w2;
    th = 2*g.height()/17;

    RectLayoutItem item1 = createRectItem(g.left()+g.width()/2 - w1/2,
                                              g.top() + margin + h3,
                                              w1, h1);
        RectLayoutItem item2 = createRectItem(item1.rect.left() - hmargin -w2,
                                              g.bottom() - h2,
                                              w2, h2);
        RectLayoutItem item3 = createRectItem(item1.rect.right() + hmargin,
                                              g.bottom() - h3 - margin - h2,
                                              w2, h2);
        RectLayoutItem item4 = createRectItem(item3.rect.left(),
                                              g.bottom() - h3,
                                              w3, h3);
        RectLayoutItem item5 = createRectItem(item1.rect.left(),
                                              g.top(),
                                              w3, h3);
        RectLayoutItem item6 = createRectItem(item1.rect.left()+ w3 + hmargin,
                                              item1.rect.top()-margin-h4,
                                              w4, h4);
        RectLayoutItem item7 = createRectItem(item1.rect.left() - hmargin - w3,
                                              g.bottom()-h2-margin*4-h3,
                                              w3, h3);
        RectLayoutItem item8 = createRectItem(item2.rect.left() - hmargin - w4,
                                              item2.rect.top()-margin*3,
                                              w4, h4);
        RectLayoutItem item9 = createRectItem(item4.rect.right() + hmargin,
                                              item4.rect.top(),
                                              w4, h4);
        RectLayoutItem item10 = createRectItem(item7.rect.left() - hmargin - w5,
                                              item8.rect.top() - margin - h5,
                                              w5, h5);
        RectLayoutItem item11 = createRectItem(item2.rect.left() - hmargin - w5,
                                              item8.rect.bottom() + margin,
                                              w5, h5);
        RectLayoutItem item12 = createRectItem(item3.rect.right() + hmargin,
                                              item9.rect.top() - margin -h5,
                                              w5, h5);
        RectLayoutItem item13 = createRectItem(item8.rect.left() - hmargin - w5,
                                              item11.rect.top() - margin -h5,
                                              w5, h5);
        RectLayoutItem text1 = createRectItem(item2.rect.left(),
                                              item7.rect.bottom() + margin,
                                              tw,
                                              th,
                                              text);
      m_list <<  item1 << item2 << item3 << item4 << item5
            << item6 << item7 << item8 << item9 << item10 << item11 << item12
              << item13 << text1;

    if (m_alignmentCaption == Qt::AlignBottom)
    {
        QList<RectLayoutItem>::iterator it;
        for(it = m_list.begin(); it!=m_list.end();++it)
        {

            (*it).rect.setRect(g.width() + g.left() - (*it).rect.x() - (*it).rect.width(),
                                   g.height() + g.top() - (*it).rect.y() - (*it).rect.height(),
                                   (*it).rect.width(),
                                   (*it).rect.height());

        }
   }
}

void CloudLayout::createDocLayout()

{
    QRectF g = m_rect;
    double margin = g.height()/24;

    double w = g.height()/3;

    double h = w;

    RectLayoutItem item1 = createRectItem(g.left() + g.width()/2 - margin*3 - w*2,
                                          g.top() + margin,
                                          w, h);

    RectLayoutItem item2 = createRectItem(g.left() + g.width()/2 - w - margin,
                                          g.top() + margin,
                                          w, h);

    RectLayoutItem item3 = createRectItem(g.left() + g.width()/2 + margin,
                                          g.top() + margin,
                                          w, h);

    RectLayoutItem item4 = createRectItem(g.left() + g.width()/2 + margin*3 + w,
                                          g.top() + margin,
                                          w, h);

    RectLayoutItem item5 = createRectItem(g.left() + g.width()/2 - w*2 - margin*3,
                                          g.top() + h + margin*2,
                                          w, h);

    RectLayoutItem item6 =  createRectItem(g.left() + g.width()/2 - w - margin,
                                           g.top() + h + margin*2,
                                           w, h);

    RectLayoutItem item7 = createRectItem(g.left() + g.width()/2 + margin,
                                               g.top() + h + margin*2,
                                              w, h);

    RectLayoutItem item8 = createRectItem(g.left() + g.width()/2 + margin*3 + w ,
                                               g.top() + h + margin*2,
                                              w, h);

    RectLayoutItem text1 = createRectItem(g.left() + g.width()/2 - w*2,
                                         item5.rect.bottom(),
                                           w*4, g.height()/5, text) ;

    if (m_alignmentCaption == Qt::AlignBottom)
    {
        m_list << item8 << item7 << item6 << item5 << item4 << item3 << item2 << item1 << text1;
        QList<RectLayoutItem>::iterator it;
        for(it = m_list.begin(); it!=m_list.end();++it)
        {

            (*it).rect.setRect(g.width() + g.left() - (*it).rect.x() - (*it).rect.width(),
                                   g.height() + g.top() - (*it).rect.y() - (*it).rect.height(),
                                   (*it).rect.width(),
                                   (*it).rect.height());
        }
    } else
        m_list <<  item1 << item2 << item3 << item4 << item5 << item6 << item7 << item8 << text1;

}
