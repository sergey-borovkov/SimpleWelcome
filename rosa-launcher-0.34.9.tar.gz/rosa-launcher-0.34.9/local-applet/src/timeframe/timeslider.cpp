/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

// QT
#include <QSlider>
#include <QLabel>
#include <QGraphicsLinearLayout>
#include <QGraphicsGridLayout>
#include <QDateTime>
#include <QPainter>
#include <QPointF>
#include <QColor>
#include <QLinearGradient>

// KDE
#include <kcolorutils.h>

// Plasma
#include <plasma/theme.h>

// local
#include "timeslider.h"
#include "timeframeslider.h"

QTimeSlider::QTimeSlider(QGraphicsItem* parent, Qt::WindowFlags wFlags)
  : QGraphicsWidget(parent, wFlags)
{
  // main layout
  QGraphicsGridLayout* m_layout = new QGraphicsGridLayout(this);
  m_layout->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

  m_mode = MONTH_MODE;
  // slider label (year)
  m_labelSlider = new Plasma::Label(this);
  m_labelSlider->setAlignment(Qt::AlignCenter);

  QPalette palette = m_labelSlider->palette();
  palette.setColor(QPalette::WindowText, Plasma::Theme::defaultTheme()->color(Plasma::Theme::TextColor));
  m_labelSlider->setPalette(palette);

  m_rightButton = new Plasma::ToolButton(this);
  m_rightButton->setText(">");

  m_leftButton = new Plasma::ToolButton(this);
  m_leftButton->setText("<");
  // day mode button
  m_dayButton = new Plasma::ToolButton(this);
  m_dayButton->setText(i18n("D"));
  // month mode button
  m_monthButton = new Plasma::ToolButton(this);
  m_monthButton->setText(i18n("M"));
  // slider
  m_slider = new TimeFrameSlider();

  m_layout->addItem(m_leftButton, 0, 0);
  m_layout->addItem(m_labelSlider, 0, 1);
  m_layout->addItem(m_rightButton, 0, 2);
  m_layout->addItem(m_dayButton, 0, 3);
  m_layout->addItem(m_monthButton, 0, 4);
  m_layout->addItem(m_slider, 0, 5);

  for (int i = 0; i < m_layout->count(); i++)
    m_layout->setAlignment(m_layout->itemAt(i),Qt::AlignCenter);

  setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Minimum);
  m_layout->setSpacing(1);
  setLayout(m_layout);

  connect(m_slider, SIGNAL(valueChanged(int)), this, SLOT(sliderChanged(int)));
  connect(m_leftButton, SIGNAL(clicked()), this, SLOT(leftButtonSlot()));
  connect(m_rightButton, SIGNAL(clicked()), this, SLOT(rightButtonSlot()));
  connect(m_dayButton, SIGNAL(clicked()), this, SLOT(dayButtonSlot()));
  connect(m_monthButton, SIGNAL(clicked()), this, SLOT(monthButtonSlot()));


  m_monthList  << i18n("JAN") << i18n("FEB") << i18n("MAR") << i18n("APR") << i18n("MAY")
        << i18n("JUNE") << i18n("JULY") << i18n("AUG") << i18n("SEP") << i18n("OCT")
        << i18n("NOV") << i18n("DEC");
};

QTimeSlider::~QTimeSlider()
{
};

void QTimeSlider::paint(QPainter *painter, const QStyleOptionGraphicsItem *,QWidget *)
{
    QPointF p1(rect().width()/2,0);
    QPointF p2(rect().width()/2,(rect().height()));
    QColor color(KColorUtils::mix(Plasma::Theme::defaultTheme()->color(Plasma::Theme::BackgroundColor), Plasma::Theme::defaultTheme()->color(Plasma::Theme::TextColor), 0.3));
    QLinearGradient fade( p1, p2 );
    fade.setColorAt( 0.0, color);
    fade.setColorAt( 1.0, Qt::transparent);
    painter->fillRect( rect(), fade );
}

void QTimeSlider::setPeriod(EventPeriod* period)
{
  if (m_period == *period)
  {
    emit periodChanged(&m_period);
    return;
  }

  m_period = *period;
  int val = periodToValue(&m_period);
  m_slider->setValue(val-1);
  updatePeriodLabel();
};

void QTimeSlider::sliderChanged(int value)
{
    m_period = valueToPeriod(value);
    emit periodChanged(&m_period);
};

int QTimeSlider::periodToValue(const EventPeriod* period)
{
    if (!period) return (-1);

    QDateTime dt = QDateTime::fromTime_t(period->startTime());

    if (m_mode == DAY_MODE)
    {
        return dt.date().day();
    }
    return dt.date().month();
};

EventPeriod QTimeSlider::valueToPeriod(int val)
{
  val++;
  QDateTime dtStart, dtEnd;
  dtStart = QDateTime::fromTime_t(m_period.startTime());
  int year = dtStart.date().year();
  int month = dtStart.date().month();
  if (m_mode == MONTH_MODE)
  {
      dtStart.setDate(QDate(year, val, 1));
      dtEnd.setDate(QDate(year, val, dtStart.date().daysInMonth()));
  } else
  {
      dtStart.setDate(QDate(year, month, val));
      dtEnd.setDate(QDate(year, month, val));
  }
  dtEnd.setTime(QTime(23, 59, 59));

  return EventPeriod(dtStart.toTime_t(), dtEnd.toTime_t());
}

void QTimeSlider::leftButtonSlot()
{

    QDateTime dtStart, dtEnd;
    dtStart = QDateTime::fromTime_t(m_period.startTime());
    dtEnd = QDateTime::fromTime_t(m_period.endTime());

    if (dtStart.date().year() == 1975)
        return;

    if (m_mode == MONTH_MODE)
    {
       dtStart = dtStart.addYears(-1);
       dtEnd =  dtEnd.addYears(-1);
    }
    else
    {
        dtStart = dtStart.addMonths(-1);
        dtEnd = dtEnd.addMonths(-1);
        int days = dtStart.date().daysInMonth();
        QStringList list;
        for(int i = 1; i<= days; i++ )
            list << QString::number(i,10);
        m_slider->setNewSkale(list);
    }

    m_period.setStartTime(dtStart.toTime_t());
    m_period.setEndTime(dtEnd.toTime_t());
    emit periodChanged(&m_period);
    updatePeriodLabel();
}

void QTimeSlider::rightButtonSlot()
{
    QDateTime dtStart, dtEnd;
    dtStart = QDateTime::fromTime_t(m_period.startTime());
    dtEnd = QDateTime::fromTime_t(m_period.endTime());

    if (m_mode == MONTH_MODE)
    {
        dtStart = dtStart.addYears(1);
        dtEnd = dtEnd.addYears(1);
    }
    else
    {
        dtStart = dtStart.addMonths(1);
        dtEnd = dtEnd.addMonths(1);
        int days = dtStart.date().daysInMonth();
        QStringList list;
        for(int i = 1; i<= days; i++ )
            list << QString::number(i,10);
        m_slider->setNewSkale(list);

    }
    m_period.setStartTime(dtStart.toTime_t());
    m_period.setEndTime(dtEnd.toTime_t());
    emit periodChanged(&m_period);
    updatePeriodLabel();
}

void QTimeSlider::dayButtonSlot()
{
    if (m_mode == DAY_MODE)
        return;
    m_mode = DAY_MODE;
    QStringList list;
    QDateTime dt = QDateTime::fromTime_t(m_period.startTime());
    int days = dt.date().daysInMonth();
    for(int i = 1; i<= days; i++ )
        list << QString::number(i,10);
    m_slider->setNewSkale(list);
    //set value on first day in month
    m_slider->setValue(0);
    sliderChanged(0);
    updatePeriodLabel();
}

void QTimeSlider::monthButtonSlot()
{

    if (m_mode == MONTH_MODE)
        return;
    m_mode = MONTH_MODE;
    QDateTime time;
    time = QDateTime::fromTime_t(m_period.startTime());
    m_slider->setValue(time.date().month()-1);
    sliderChanged(time.date().month()-1);
    m_slider->setNewSkale(m_monthList);
    updatePeriodLabel();

}

void QTimeSlider::updatePeriodLabel()
{

    if (m_mode == MONTH_MODE)
    {
        m_labelSlider->setText(QDateTime::fromTime_t(m_period.startTime()).toString("yyyy"));
    } else
    {
        QDateTime time;
        time = QDateTime::fromTime_t(m_period.startTime());
        m_labelSlider->setText(QDateTime::fromTime_t(m_period.startTime()).toString("yyyy") +"\n"+ m_monthList[time.date().month() - 1]);
    }

}
