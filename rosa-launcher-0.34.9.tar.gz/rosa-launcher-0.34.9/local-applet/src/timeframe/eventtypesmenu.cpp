/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#include "eventtypesmenu.h"
#include "eventtypesmenuitem.h"

#include <QGraphicsLinearLayout>


QEventTypesMenu::QEventTypesMenu(QGraphicsItem* parent, Qt::WindowFlags wFlags)
  : QGraphicsWidget(parent, wFlags)
  , m_currentMenuItem(-1)
{
  m_layout = new QGraphicsLinearLayout(Qt::Vertical);
  m_layout->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Minimum);

  setLayout(m_layout);
};

QEventTypesMenu::~QEventTypesMenu()
{
};

QGraphicsWidget* QEventTypesMenu::addMenuItem(const QString& text, bool checked)
{
  QEventTypesMenuItem* item = new QEventTypesMenuItem(this);
  item->setText(text);
  item->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
  item->setChecked(checked);
  m_layout->addItem(item);
  if (checked)
      setCurrentMenuItem(getIndexMenuItem(item));

  return (QGraphicsWidget*)(item);
};

int QEventTypesMenu::getIndexMenuItem(const QEventTypesMenuItem* menuItem)
{
  int layoutItemCount = m_layout->count();
  for (int i = 0; i < layoutItemCount; i++)
  {
    QGraphicsLayoutItem* gli = m_layout->itemAt(i);
    if (!gli) continue;

    QEventTypesMenuItem* item = dynamic_cast<QEventTypesMenuItem*>(gli);
    if (!item) continue;

    if (item == menuItem) return (i);
  }

  return (-1);
};

void QEventTypesMenu::addStretch()
{
  m_layout->addStretch();
};

void QEventTypesMenu::setCurrentMenuItem(int id)
{
  m_currentMenuItem = id;

  int layoutItemCount = m_layout->count();
  for (int i = 0; i < layoutItemCount; i++)
  {
    QGraphicsLayoutItem* gli = m_layout->itemAt(i);
    if (!gli) continue;
    QEventTypesMenuItem* item = dynamic_cast<QEventTypesMenuItem*>(gli);
    if (!item) continue;

    item->setChecked(id == i);
  }
};
