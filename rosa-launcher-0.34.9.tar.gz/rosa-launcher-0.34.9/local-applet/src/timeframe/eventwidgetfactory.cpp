/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#include "eventwidgetfactory.h"

#include "photoeventwidget.h"
#include "videoeventwidget.h"
#include "documenteventwidget.h"

QActivityEventWidget* QEventWidgetFactory::createWidget(EventType eventType, QGraphicsItem* parent, Qt::WindowFlags wFlags)
{
  QActivityEventWidget* w = 0;

  switch (eventType)
  {
  case Image: w = new QImageEventWidget(parent, wFlags); break;
  case Video: w = new QVideoEventWidget(parent, wFlags); break;
  case Document: w = new QDocumentEventWidget(parent, wFlags); break;
  default: break;
  }

  return w;
};
