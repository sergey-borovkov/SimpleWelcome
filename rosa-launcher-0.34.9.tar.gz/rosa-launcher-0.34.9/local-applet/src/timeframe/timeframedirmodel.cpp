/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *   Julia Mineeva <julia.mineeva@osinit.ru>
 *   Evgeniy Augin <evgeniy.augin@osinit.ru>
 *   Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

// local
#include "timeframedirmodel.h"

// KDE
#include <kfileitem.h>
//#include <kicon.h>

// QT
#include <QIcon>
#include <QPainter>
#include <QtSvg/QSvgRenderer>

// nepomuk
#include <nepomuk/resource.h>



TimeFrameDirModel::TimeFrameDirModel(QObject *parent)
    : KDirModel(parent)
{
};

QVariant TimeFrameDirModel::data(const QModelIndex & index, int role) const
{
    if (!index.isValid())
        return QVariant();

    //DirModelNode* node = static_cast<DirModelNode*>(index.internalPointer());
    const KFileItem& item = itemForIndex(index);


    switch (role)
    {
    case Qt::DecorationRole:
    {
        return QIcon(":/icons/null.png");
    }
    case Qt::ToolTipRole:
    {
        Nepomuk::Resource res(item.localPath());
        int rating = static_cast<int>(res.rating());

        // tooltip with event role
        QString ttText = i18n("%1\nrating: %2", item.text(), rating);
        return ttText;
    }
    default:
        return KDirModel::data(index, role);
    }
};
