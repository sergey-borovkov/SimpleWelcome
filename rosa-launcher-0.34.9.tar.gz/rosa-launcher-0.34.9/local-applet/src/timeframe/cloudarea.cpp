/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#include "cloudarea.h"

#include "activityeventsarea.h"
#include "activityeventsscene.h"
#include "activityeventssource.h"
#include "activityevent.h"
#include "activityeventwidget.h"

#include <QDebug>
#include <QGraphicsItem>
#include <QGraphicsGridLayout>
#include <QPainter>
#include <QFont>
#include "eventwidgetfactory.h"
#include <Plasma/Label>

const int QCloudArea::m_widgetsCount = 13;

QCloudArea::QCloudArea(QGraphicsItem *parent, Qt::WindowFlags wFlags)
  : QActivityEventsArea(parent, wFlags)
{
  // create label for area
  m_label = new Plasma::Label(this);
  QFont font = QGraphicsWidget::font();
  font.setPointSize(20);
  m_label->setFont(font);
  m_label->setAlignment(Qt::AlignCenter);
  m_label->hide();
  m_minRateEvent = 0;
};

void QCloudArea::init(ShowEventType showEventType, const EventPeriod* period)
{
   QActivityEventsArea::init(showEventType, period);
   m_label->setText(m_showEventType.eventName);
};

void QCloudArea::onGeometryChanged()
{
  updateRectLayout();

  setWidgetsGeometry();
};

void QCloudArea::updateAreaGeometry()
{
  //  qDebug("QCloudArea::updateAreaGeometry()");
    updateRectLayout();
};

void QCloudArea::clearArea()
{
    //qDebug("cloud clear");
    map<string, QActivityEventWidget*>::iterator it;
    for (it = m_widgetsMap.begin(); it != m_widgetsMap.end(); it++)
    {
      QActivityEventWidget* ew = (*it).second;
      if (ew) delete ew;
    }
    m_widgetsMap.clear();
}

void QCloudArea::showNewEvent(ActivityEvent* event)
{
  //  qDebug("!!!   it's QCloudArea::showNewEvent!!!");
  if (!event)
  {
      //delete event;
      return;
  }
  if( m_widgetsMap.size() == 0)
      m_minRateEvent = 0;
  //qDebug() << "new Event"<< QString::fromStdString(event->url());
  if (m_widgetsMap.size() > 4)
    stopAnimation();

  // !!! перед добавлением сделать проверку на дубликат !!!
  //
  map<string, QActivityEventWidget*>::iterator it;
  //it = m_widgetsMap.find(event->url());
  //if (it != m_widgetsMap.end()) return; //???? такой виджет уже есть ????

  // проверим, можем ли мы добавить элемент в область
  //if (!canShowEventWidget(event))
    //  return;
  if (m_widgetsMap.size() == m_widgetsCount)
  {
     if (m_minRateEvent->rate() < event->rate())
     {
         it = m_widgetsMap.find(m_minRateEvent->url());

         QActivityEventWidget* item = (*it).second;
         m_widgetsMap.erase(it);
         QList<RectLayoutItem>::iterator i;
         for (i = m_rectList.begin(); i != m_rectList.end(); ++i)
         {
            if ((*i).url == item->getEvent()->url())
             {
                 (*i).url = "";
                 (*i).status = empty;
                 (*i).rate = 0;
                 break;
             }
         }
         delete item;
         //find widget with minimal rate
         m_minRateEvent = 0;
         for (it = m_widgetsMap.begin(); it != m_widgetsMap.end(); ++it )
         {
            QActivityEventWidget* ew = (*it).second;
            if (!m_minRateEvent)
                m_minRateEvent = ew->getEvent();
            if (ew->getEvent()->rate() < m_minRateEvent->rate() )
                m_minRateEvent = ew->getEvent();
         }
     } else
     {
         delete event;
         return;
     }
   }
  if (!m_minRateEvent)
      m_minRateEvent = event;
  else  if (m_minRateEvent->rate() > event->rate())
    m_minRateEvent = event;
  // создадим виджет нужного типа
  QActivityEventWidget* w = 0;
  QEventWidgetFactory factory;
  w = factory.createWidget(m_showEventType.eventType, this);
  if (!w) return;
  w->init(event, QRectF());

  connect(w, SIGNAL(hoverEnter(QGraphicsWidget*)), this, SLOT(setTargetItem(QGraphicsWidget*)));
  m_widgetsMap[event->url()] = w;
 // qDebug() << "new Event"<< QString::fromStdString(event->url());
  setWidgetsGeometry();
  //delete event;
};

// set widgets geometries
void QCloudArea::setWidgetsGeometry()
{
  //  qDebug("QCloudArea::setWidgetsGeometry()");
  if (m_widgetsMap.size() <= 5)
    updateRectLayout();

  QList<RectLayoutItem>::iterator i;
  for (i = m_rectList.begin(); i != m_rectList.end(); ++i)
  {
      if ((*i).status == text)
      {
          m_label->setGeometry((*i).rect);
          if (m_widgetsMap.size() > 0)
          {
              if (!m_animationLabel->isVisible())
                m_label->show();
          }
          else
            m_label->hide();
          continue;
      }

       map<string, QActivityEventWidget*>::iterator it;
       for (it = m_widgetsMap.begin(); it != m_widgetsMap.end(); ++it )
       {
          QActivityEventWidget* ew = (*it).second;
          if (!ew) continue;

          if (graphicItemExist(ew->getEvent()->url()))
          {
              if (!m_animationLabel->isVisible())
              {
                  //qDebug() << "window show"<< QString::fromStdString(ew->getEvent()->url());
                ew->show();
              }
              //qDebug() << "window item show"<< QString::fromStdString(ew->getEvent()->url());
              continue;
          }
          if (((*i).status == empty) || ((*i).rate < ew->getEvent()->rate()))
          {

              ew->setGeometry((*i).rect.x(), (*i).rect.y(),
                              (*i).rect.width(), (*i).rect.height());
            //  ew->setSize((*i).rect.x(), (*i).rect.y(),
              //                         (*i).rect.width(), (*i).rect.height());
              if (!m_animationLabel->isVisible())
              {
                  //qDebug() << "window show"<< QString::fromStdString(ew->getEvent()->url());
                ew->show();
              }


              (*i).status = notFree;
              (*i).url = ew->getEvent()->url();
              (*i).rate = ew->getEvent()->rate();
              continue;
           }
           ew->hide();
           // qDebug() << "window hide"<< QString::fromStdString(ew->getEvent()->url());
        }
      }
};

bool QCloudArea::graphicItemExist(string url)
{
    for (int i=0; i<m_rectList.size(); ++i)
    {
        if (m_rectList.at(i).url == url)
            return true;
    }
    return false;
};

void QCloudArea::updateRectLayout()
{
    map<string, QActivityEventWidget*>::iterator it;
    for (it = m_widgetsMap.begin(); it != m_widgetsMap.end(); ++it )
    {
       QActivityEventWidget* ew = (*it).second;
       if (!ew) continue;
       ew->hide();
    }
    m_label->hide();
    m_rectList.clear();
    int n = m_widgetsMap.size();
    QRectF g = contentsRect();
    CloudLayout cloud(g,n, m_showEventType.alignmentCaption, m_showEventType.eventType);
    m_rectList = cloud.rectList();
}

void QCloudArea::stopAnimation()
{
    QActivityEventsArea::stopAnimation();
    setWidgetsGeometry();
}
