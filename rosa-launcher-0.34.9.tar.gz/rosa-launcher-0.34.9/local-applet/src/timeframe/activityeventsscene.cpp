/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

// local
#include "activityeventsscene.h"
#include "activityevent.h"
#include "eventsareafactory.h"

// QT
#include <QGraphicsItem>
#include <QGraphicsLinearLayout>
#include <QPainter>
#include <QLabel>
#include <QMovie>

// PLasma
#include <Plasma/ScrollWidget>
#include <plasma/widgets/label.h>

const int QActivityEventsScene::m_scrollOffset = 9;

QActivityEventsScene::QActivityEventsScene(QGraphicsItem *parent, Qt::WindowFlags wFlags)
  : QGraphicsWidget(parent, wFlags)
  , m_layout(0)
{
  m_layout = new QGraphicsLinearLayout(Qt::Horizontal);
  connect(this, SIGNAL(geometryChanged()), this, SLOT(onGeometryChanged()));
  setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
  m_layout->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
  setLayout(m_layout);
};

QActivityEventsScene::~QActivityEventsScene()
{
  clearScene();
};

void QActivityEventsScene::setStrechFactor(int index, int strech)
{
    QGraphicsLayoutItem * item = m_layout->itemAt(index);
    if (item)
    {
        m_layout->setStretchFactor(item,strech);
    }
    setLayout(m_layout);
}

void QActivityEventsScene::onGeometryChanged()
{
  // set new size and position for scrolls
  QRectF g = contentsRect();

//  qDebug("  QActivityEventsScene::onGeometryChanged(): %f, %f, %f, %f",
//         g.left(), g.top(), g.width(), g.height());

};

void QActivityEventsScene::init(list<ShowEventType>* showEventTypeList, const EventPeriod* period)
{
  if (!showEventTypeList) return;

  // delete all areas and widgets
  clearScene();

  // создадим области отображения событий
  list<ShowEventType>::iterator it;
  for (it = showEventTypeList->begin(); it != showEventTypeList->end(); it++)
  {
    ShowEventType set = *it;

    QEventsAreaFactory factory;
    QActivityEventsArea* area = factory.createArea(set.showType);
    if (!area)
      continue;

    m_layout->addItem(area);
    area->init(set, period);
    m_areaList.push_back(area);
  };
};

void QActivityEventsScene::setPeriod(const EventPeriod *period)
{
//  qDebug("scene:             setPeriod() ");
  // set first area for widgets
//  onGeometryChanged();

  // set new period for areas
  list<QActivityEventsArea*>::iterator it;
  for (it = m_areaList.begin(); it != m_areaList.end(); it++)
  {
    QActivityEventsArea* area = *it;
    if (!area) continue;
    area->setPeriod(period);
  };
};

void QActivityEventsScene::clearScene()
{
  while (m_layout->count())
  {
    QGraphicsLayoutItem* item = m_layout->itemAt(0);
    m_layout->removeItem(item);
    if (item) delete item;
  }

  m_areaList.clear();
};

void QActivityEventsScene::paint(QPainter* painter,
                                 const QStyleOptionGraphicsItem* option,
                                 QWidget* widget)
{
//  QRectF g = contentsRect();
 //painter->drawRoundedRect(g.topLeft().x(), g.topLeft().y(), g.width(), g.height(), 10, 10);

  QGraphicsWidget::paint(painter, option, widget);
};

