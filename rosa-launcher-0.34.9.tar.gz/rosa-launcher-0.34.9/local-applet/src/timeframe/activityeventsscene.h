/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 *  Julia Mineeva <julia.mineeva@osinit.ru>
 *  Evgeniy Augin <evgeniy.augin@osinit.ru>
 *  Ivan Kulkov   <ivan.kulkov@osinit.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#ifndef __activityeventsscene_h_
#define __activityeventsscene_h_

#include <list>
using namespace std;

#include <QGraphicsWidget>

#include "activityeventsarea.h"
#include "activityeventssource.h"

class QGraphicsItem;
class QGraphicsLinearLayout;
class ActivityEvent;
class EventPeriod;
class QActivityEventScrollArea;

// describe events scene (area)
class QActivityEventsScene : public QGraphicsWidget
{
  Q_OBJECT

public:
  QActivityEventsScene(QGraphicsItem *parent = 0, Qt::WindowFlags wFlags = 0);
  virtual ~QActivityEventsScene();

  void init(list<ShowEventType>* showEventTypeList, const EventPeriod* period);
  void setPeriod(const EventPeriod* period);

  void clearScene();

  void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget = 0);
  void setStrechFactor(int index, int strech);

protected:

protected slots:
  void onGeometryChanged();

protected:
  list<QActivityEventsArea*> m_areaList;

  QGraphicsLinearLayout* m_layout;

  static const int m_scrollOffset;


};

#endif // __activityeventsscene_h_

