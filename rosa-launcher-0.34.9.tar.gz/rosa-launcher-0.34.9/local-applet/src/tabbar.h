/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef __tabbar_h_
#define __tabbar_h_

#include <QGraphicsLinearLayout>
#include <QGraphicsWidget>
#include <QTabBar>
#include <QString>
#include <QGraphicsItem>
#include <QTimer>

#include <Plasma/TabBar>
#include <Plasma/Applet>

class TabBar : public QGraphicsWidget
{
  Q_OBJECT
    public:
  TabBar(QGraphicsItem *parent = 0, Qt::WindowFlags wFlags = 0);
  virtual ~TabBar();


  void addTab(QString name, QGraphicsWidget *widget, bool hidden = false);

  QGraphicsWidget *currentItem(void);

  void setApplet(Plasma::Applet *applet);
  
 public slots:
  void tabChanged(int index, bool hiddenIndex = false);
  void reset(void);
  void setResetCallback(void);
  void changeTab(int index);
  int currentTabIndex(void) { return m_currentTabIndex - m_hiddenTabsCount; };

  Plasma::TabBar *nativeWidget(void) { return m_tabBar; };

 private slots:

  void removeFocusHandling(void);
  void setHiddenWidgetWidth(void);

 private:
  Plasma::TabBar *m_tabBar;
  QGraphicsLinearLayout *m_layout;
  
  std::vector<QGraphicsWidget*> m_tabWidgets;
  std::vector<QString> m_tabNames;

  QGraphicsWidget *m_hiddenWidget;
  QGraphicsLinearLayout *m_hiddenWidgetLayout;

  int m_currentTabIndex;
  QGraphicsWidget *m_currentTabWidget;

  int m_hiddenTabsCount;
  
  bool m_resetCallbackSet;
  QTimer *m_resetCallbackTimer;

  Plasma::Applet *m_applet;

  QTimer *m_focusTimer;
};

#endif // __tabbar_h_
