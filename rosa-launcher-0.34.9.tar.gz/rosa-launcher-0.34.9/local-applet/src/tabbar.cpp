/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "tabbar.h"

#include <KDebug>
#include <Plasma/Label>

#include <QObject>
#include <QMetaObject>
#include <QApplication>
#include <QTimer>
#include <QGraphicsItem>
#include <QGraphicsScene>

TabBar::TabBar(QGraphicsItem *parent, Qt::WindowFlags wFlags)
  : QGraphicsWidget(parent, wFlags), m_resetCallbackSet(false), m_focusTimer(0)
{
  m_layout = new QGraphicsLinearLayout(Qt::Vertical);

  setLayout(m_layout);

  m_tabBar = new Plasma::TabBar();
  
  m_tabBar->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Minimum);
  //m_tabBar->setData(0, 3);

  m_tabBar->setFlag(QGraphicsItem::ItemIsFocusable, false);
  
  //m_layout->addStretch();
  m_layout->addItem(m_tabBar);

  m_hiddenWidget = new QGraphicsWidget();
  m_hiddenWidgetLayout = new QGraphicsLinearLayout(Qt::Vertical);
  m_hiddenWidget->setLayout(m_hiddenWidgetLayout);

  /*
  m_layout->addItem(m_hiddenWidget);
  m_hiddenWidget->setFlag(QGraphicsItem::ItemIsFocusable, false);
  m_hiddenWidget->setVisible(false);

  m_hiddenWidget->setMaximumHeight(0);
  */
  m_hiddenWidgetLayout->setContentsMargins(0, 0, 0, 0);
  m_hiddenWidget->setContentsMargins(0, 0, 0, 0);

  connect(this, SIGNAL(geometryChanged()), this, SLOT(setHiddenWidgetWidth()));
  
  m_currentTabWidget = NULL;
  m_currentTabIndex = 0;

  m_hiddenTabsCount = 0;
  
  connect(m_tabBar, SIGNAL(currentChanged(int)), this, SLOT(tabChanged(int)));
  
  m_resetCallbackTimer = new QTimer(this);
  connect(m_resetCallbackTimer, SIGNAL(timeout()), this, SLOT(setResetCallback()));
  m_resetCallbackTimer->start(500);

  QTimer::singleShot(1000, this, SLOT(removeFocusHandling()));

  m_focusTimer = new QTimer(this);
  m_focusTimer->setSingleShot(true);    
}

TabBar::~TabBar()
{
  delete m_resetCallbackTimer;
}

void TabBar::setHiddenWidgetWidth(void)
{
  QSizeF tabbarSize = m_tabBar->size();
  m_hiddenWidget->setMaximumWidth(tabbarSize.width());
  m_hiddenWidget->setMinimumWidth(tabbarSize.width());  
}

void TabBar::removeFocusHandling(void)
{
  foreach(QGraphicsItem *item, scene()->items())
    {
      int itemOrder = item->data(0).toInt();
      if(itemOrder == 0)
        item->setFlag(QGraphicsItem::ItemIsFocusable, false);
    }
}

void TabBar::reset(void)
{
  m_tabBar->setCurrentIndex(0);
  tabChanged(0);
}

void TabBar::changeTab(int index)
{
  m_tabBar->setCurrentIndex(index);
  tabChanged(index);
}

QGraphicsWidget *TabBar::currentItem(void)
{
  return m_currentTabWidget;
}


void TabBar::addTab(QString name, QGraphicsWidget *widget, bool hidden)
{
  if(! hidden) {
    m_tabBar->addTab(name);
  } else {
    if(m_tabBar->count() > m_hiddenTabsCount) // If trying to add hidden tab after visible tabs
      return;
    
    m_hiddenTabsCount++;
  }

  m_tabNames.push_back(name);
  m_tabWidgets.push_back(widget);

  m_hiddenWidgetLayout->addItem(widget);

  /////////////
  if(m_currentTabWidget == NULL)
    {
      m_currentTabWidget = widget;
      m_currentTabIndex = 0;
      m_layout->insertItem(0, widget);
    }
}

void TabBar::tabChanged(int index, bool hiddenIndex)
{ 
  if(! hiddenIndex)
    index += m_hiddenTabsCount;

  QSizeF currentWidgetSize = m_currentTabWidget->size();
  m_hiddenWidget->setMaximumWidth(currentWidgetSize.width());
  m_hiddenWidget->setMinimumWidth(currentWidgetSize.width());
    
  //if(m_currentTabWidget != NULL)
  m_hiddenWidgetLayout->addItem(m_currentTabWidget);
  m_currentTabWidget = m_tabWidgets[index];
  m_currentTabIndex = index;
  m_layout->insertItem(0, m_currentTabWidget);

  kDebug() << "Changing tab to " << m_tabNames[index];
  QMetaObject::invokeMethod(m_currentTabWidget, "tabActivated");
  // if(m_currentTabWidget->metaObject()->indexOfMethod("tabActivated") != -1)
  //   {
  //     kDebug() << "Going to call a tabActivated on " << index << " widget";
  //     QMetaObject::invokeMethod(m_currentTabWidget, "tabActivated");
  //   }
  // else
  //   {
  //     kDebug() << "Oops: " << m_currentTabWidget->metaObject()->indexOfMethod("tabActivated");
  //   }

  if(! (index == 0 && hiddenIndex == true))
    {
      m_focusTimer->stop();
      m_focusTimer->start(500);      
    }
}

void TabBar::setApplet(Plasma::Applet *applet)
{
  m_applet = applet;
  connect(m_focusTimer, SIGNAL(timeout()), m_applet, SLOT(setIconsFocus()));
};

void TabBar::setResetCallback(void)
{
  if(QApplication::activeWindow() != NULL)
    m_resetCallbackSet = connect(QApplication::activeWindow(), SIGNAL(hiden()), this, SLOT(reset()));

  //kDebug() << "Setting callback: " << m_resetCallbackSet;
  if(m_resetCallbackSet)
    m_resetCallbackTimer->stop();
}
