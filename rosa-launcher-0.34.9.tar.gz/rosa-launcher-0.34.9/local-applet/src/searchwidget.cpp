/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "searchwidget.h"
#include "groupgridwidget.h"

#include <KIcon>
#include <QIcon>
#include <KServiceGroup>
#include <KSycoca>
#include <KDebug>

#include "rosa-launcher.h"

SearchWidget::SearchWidget(QGraphicsItem *parent)
  : SWScrollWidget(parent),
    m_appLaunchReciever(0),
    m_firstButton(0)
{
  setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
  setOverShoot(false);

  GroupGridWidget *groupGrid = new GroupGridWidget();
  groupGrid->setScrollWidget(this);
  setWidget(groupGrid);

  /*
  GroupGridWidgetGroup *group = groupGrid->newGroup("Office");

  for(int i = 0; i < 35; i++)
    {
      AppButton *button = new AppButton(static_cast<QIcon>(KIcon("face-wink")), QString("Smiley smile ") + QString::number(i), QString("This is Smily. Glad to know U!"), QString("file:///usr/share/applications/kde4/kcalc.desktop"));
      group->append(button);
    }

  group->repopulate();

  group = groupGrid->newGroup("Internet");

  for(int i = 0; i < 31; i++)
    {
      AppButton *button = new AppButton(static_cast<QIcon>(KIcon("face-wink")), QString("Smiley smile ") + QString::number(i), QString("This is Smily. Glad to know U!"), QString("file:///usr/share/applications/kde4/kcalc.desktop"));
      group->append(button);
    }

  group->repopulate();
  */

  //retrieveApps();
  //connectToEngine();
}

SearchWidget::~SearchWidget()
{
}

void SearchWidget::registerRunnerManager(Plasma::RunnerManager *manager)
{
  m_runnerManager = manager;
  connect(m_runnerManager, SIGNAL(matchesChanged(const QList<Plasma::QueryMatch> &)), this, SLOT(newSearchMatches(const QList<Plasma::QueryMatch> &)));
}

void SearchWidget::newSearchMatches(const QList<Plasma::QueryMatch> &matches)
{
  GroupGridWidget *gridWidget = static_cast<GroupGridWidget*>(widget());
  AppButton *button;

  GroupGridWidgetGroup *gridWidgetGroup;

  gridWidget->clear();
  /*
  delete gridWidget;

  gridWidget = new GroupGridWidget();
  gridWidget->setScrollWidget(this);
  setWidget(gridWidget);
  */
  
  m_firstButton = NULL;
  
  QString firstGroupName;
  
  for(int i = 0; i < matches.count(); i++)
    {
      const Plasma::QueryMatch *match = &(matches[i]);

      if(firstGroupName.isEmpty())
        firstGroupName = match->runner()->name();
      
      if(! gridWidget->hasGroup(match->runner()->name()))
          gridWidgetGroup = gridWidget->newGroup(match->runner()->name());
    }

  bool assignedFirstButton = false;
  
  for(int i = 0; i < matches.count(); i++)
    {
      const Plasma::QueryMatch *match = &(matches[i]);

      gridWidgetGroup = gridWidget->getGroup(match->runner()->name());

      button = new AppButton(match->icon(), match->text(), match->subtext(), m_runnerManager, match);

      // First match run by Enter press
      if(!assignedFirstButton && firstGroupName == match->runner()->name())
        {
          m_firstButton = button;
          assignedFirstButton = true;
        }

      if(m_appLaunchReciever != NULL)
        connect(button, SIGNAL(appLaunched(QString)), m_appLaunchReciever, SLOT(registerLaunchedApp(QString)));
      
      gridWidgetGroup->append(button);
      gridWidgetGroup->repopulate();
    }

  //kDebug() << "SIZE: " << gridWidget->size();

  gridWidget->setGroupsMarginsForWidth(gridWidget->size().width());
  
  /*
  button = new AppButton(static_cast<QIcon>(KIcon(desktopFile->readIcon())), desktopFile->readName(), fileName, fileName);

  gridWidgetGroup->append(button);
  */
  

  /*
  kDebug() << "==============\nNEW MATCHES!!!\n==============";

  for(int i = 0; i < matches.count(); i++)
    {
      kDebug() << matches[i].text();

      QList<QAction*> actionList = m_runnerManager->actionsForMatch(matches[i]);

      if (!actionList.isEmpty()) {
        for(int y = 0; y < actionList.count(); y++)
          {
            kDebug() << "Action:" << actionList[y]->text();
          }
      }
      else
      {
        //kDebug() << "No actions.";
      };

      //matches[i].run(*(m_runnerManager->searchContext())); // THE KEY
    };
  */
}

void SearchWidget::runFirstApp(void)
{
  if(m_firstButton)
    m_firstButton->runApp();
}

void SearchWidget::reposition()
{
  //GroupGridWidget *gridWidget = static_cast<GroupGridWidget*>(widget());
  //AppButton *button;

  /*
  // ----------------------------------------------------------------
  // Recent Applications
  GroupGridWidgetGroup *gridWidgetGroup;

  if(gridWidget->hasGroup(i18n("Recent Applications")))
    {
      gridWidgetGroup = gridWidget->getGroup(i18n("Recent Applications"));
      gridWidgetGroup->clear();
    }
  else
     {
       gridWidgetGroup = gridWidget->newGroup(i18n("Recent Applications"));
     }

  KDesktopFile *desktopFile;

  for(int i = 0; i < m_recentApplications.size(); i++)
    {
      QString fileName = m_recentApplications[i];
      //kDebug() << fileName;

      if(! KDesktopFile::isDesktopFile(fileName))
        continue;
      
      desktopFile = new KDesktopFile(fileName);

      if(desktopFile->noDisplay())
        continue;

      button = new AppButton(static_cast<QIcon>(KIcon(desktopFile->readIcon())), desktopFile->readName(), fileName, fileName);

      gridWidgetGroup->append(button);

      delete desktopFile;
      
    }

  gridWidgetGroup->repopulate();
  */
}
