#!/bin/bash

if [ x$1 != "x" ]; then
  echo $1 >version.txt
fi

VERSION=`cat version.txt`

./prebuild.sh

make

sudo rpm -U ~/rpmbuild/RPMS/noarch/rosa-launcher-${VERSION}-*
