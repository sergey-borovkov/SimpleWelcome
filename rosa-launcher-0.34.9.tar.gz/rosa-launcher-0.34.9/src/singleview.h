/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 * Based on plasma-windowed by:
 * 2006-2008 Aaron Seigo <aseigo@kde.org>
 * 2009 Marco Martin <notmart@gmail.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef SINGLEVIEW_H
#define SINGLEVIEW_H

#include <QPixmap>
#include <QGraphicsView>

#include <KUniqueApplication>

#include <Plasma/Plasma>
#include <Plasma/FrameSvg>

namespace Plasma
{
    class Containment;
    class Applet;
    class Corona;
} // namespace Plasma

class SingleView;

class SingleView : public QGraphicsView
{
    Q_OBJECT

public:
    SingleView(Plasma::Corona *corona, Plasma::Containment *containment, QWidget *parent=0);
    ~SingleView();


    Plasma::Applet *applet();
    Plasma::Location location() const;
    Plasma::FormFactor formFactor() const;

    void dragEnterEvent(QDragEnterEvent *event);
    void dragMoveEvent(QDragMoveEvent *event);
    void dropEvent(QDropEvent *event);

    bool focusNextPrevChild(bool next);
    bool focusNextChild(void);
    bool focusPreviousChild(void);
    
public Q_SLOTS:
    void setContainment(Plasma::Containment *containment);
    void updateGeometry();
    void updateSnapshot();
    void hideWindow(void);
    void showWindow(void);
    void toggleWindow(void);
    bool event(QEvent *event);
    //void keyPressEvent(QKeyEvent *event);

    void setApplication(KUniqueApplication *application) { m_application = application; };
    
    void reposition();
    
Q_SIGNALS:
    void locationChanged(const SingleView *view);
    void geometryChanged();
    void containmentActivated();
    void storeApplet(Plasma::Applet *applet);
    void hiden();
    void shown();

protected:
    void paintEvent(QPaintEvent *event);
    void resizeEvent(QResizeEvent *event);
    void hideEvent(QHideEvent *event);
    void drawBackground(QPainter* p, const QRectF& rect);

    void updateMask(void);

private:
    Plasma::Applet *m_applet;
    Plasma::Containment *m_containment;
    Plasma::Corona *m_corona;

    QPixmap m_appletSnapshot;

    Plasma::FrameSvg *m_background;
    bool m_firstShow;
    KUniqueApplication *m_application;
};

#endif // multiple inclusion guard
