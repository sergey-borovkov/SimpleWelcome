/*
 * Copyright (c) ROSA Laboratory 2011
 * License: GPLv3
 *
 * Authors:
 * Alexey Yermakov <alexey.yermakov@rosalab.ru>
 *
 * Based on plasma-windowed by:
 * 2006-2008 Aaron Seigo <aseigo@kde.org>
 * 2009 Marco Martin <notmart@gmail.com>
 *
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as
 *   published by the Free Software Foundation; either version 3,
 *   or (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details
 *
 *   You should have received a copy of the GNU General Public
 *   License along with this program; if not, write to the
 *   Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "singleview.h"
#include <iostream>

#include <QAction>
#include <QDir>
#include <QFileInfo>
#include <QDesktopWidget>
#include <QApplication>
#include <QObject>
#include <QApplication>
#include <QBitmap>
#include <QWidget>
#include <QTimer>
#include <QDragEnterEvent>
#include <QDragMoveEvent>
#include <QDropEvent>

#include <KStandardAction>
#include <KAction>
#include <KIconLoader>
#include <KWindowSystem>

#include <Plasma/Applet>
#include <Plasma/Label>
#include <Plasma/Containment>
#include <Plasma/Corona>
#include <Plasma/PopupApplet>
#include <Plasma/WindowEffects>

#include <X11/Xlib.h>
#include <X11/Xlibint.h>
#include <X11/Xproto.h>
#include <X11/extensions/Xrandr.h>
//#include <X11/extensions/XRender.h>

SingleView::SingleView(Plasma::Corona *corona, Plasma::Containment *containment, QWidget *parent)
    : QGraphicsView(parent),
      m_applet(0),
      m_containment(containment),
      m_corona(corona),
      m_firstShow(true)
{
    setScene(m_corona);

    QString pluginName("rosa-launcher");

    QFileInfo info(pluginName);
    if (!info.isAbsolute()) {
        info = QFileInfo(QDir::currentPath() + '/' + pluginName);
    }

    if (info.exists()) {
        m_applet = Plasma::Applet::loadPlasmoid(info.absoluteFilePath());
    }

    if (!m_applet) {
        m_applet = Plasma::Applet::load(pluginName);
    }

    if (!m_applet) {
        kDebug() << "failed to load" << pluginName;
        return;
    }

    kDebug() << "Setting acceptDrops";
    setAcceptDrops(true);
    
    /*
    setBackgroundRole( QPalette::Window );
    setAutoFillBackground( true );
    QColor color = Qt::white;
    color.setAlpha( 0 );
    QPalette p = palette();
    p.setColor( QPalette::Window, QApplication::activeWindow() );
    setPalette( p );
    */

    setAttribute(Qt::WA_TranslucentBackground);
    QPalette pal = palette();
    pal.setColor(backgroundRole(), Qt::transparent);
    setPalette(pal);

    m_background = new Plasma::FrameSvg(this);
    m_background->setImagePath(QLatin1String("dialogs/krunner"));
    m_background->setEnabledBorders(Plasma::FrameSvg::AllBorders);

    /* // Border margins
    m_leftBorderWidth = qMax(0, int(m_background->marginSize(Plasma::LeftMargin)));
    m_rightBorderWidth = qMax(0, int(m_background->marginSize(Plasma::RightMargin)));
    m_bottomBorderHeight = qMax(0, int(m_background->marginSize(Plasma::BottomMargin)));
    */

    //connect(m_background, SIGNAL(repaintNeeded()), this, SLOT(themeUpdated()));
    
    //setStyleSheet("background: transparent");
    //setAutoFillBackground(false);
    m_containment->setAttribute(Qt::WA_TranslucentBackground);
    m_containment->setAutoFillBackground(false);
        
    m_containment->addApplet(m_applet, QPointF(-1, -1), false);

    /*
    //QRectF screenRect = QDesktopWidget().screenGeometry();
    QRect workArea = KWindowSystem::workArea();

    resize(screenRect.width() - 20, screenRect.height() - 50);
    move(screenRect.x() + 10, screenRect.y() + 60);
    */

    connect(KWindowSystem::self(), SIGNAL(workAreaChanged()), this, SLOT(reposition()));
    reposition();

    // m_containment->resize(QWIDGETSIZE_MAX, QWIDGETSIZE_MAX);

    m_applet->setPos(0, 0);
    m_applet->setFlag(QGraphicsItem::ItemIsMovable, false);
    m_applet->setFocus(Qt::ActiveWindowFocusReason);

    QRectF newSceneRect = m_applet->sceneBoundingRect();

    newSceneRect.setX(newSceneRect.x() + 4);
    newSceneRect.setY(newSceneRect.y() + 4);
    newSceneRect.setWidth(newSceneRect.width() - 8); 
    newSceneRect.setHeight(newSceneRect.height() - 8);
    
    setSceneRect(newSceneRect);
    setWindowTitle(m_applet->name());
    setWindowIcon(SmallIcon(m_applet->icon()));
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setFrameStyle(QFrame::NoFrame);

    QAction *action = m_applet->action("remove");
    delete action;

    m_applet->addAction(QString("remove"), KStandardAction::quit(this, SLOT(hide()), m_applet));

    // enforce the applet being our size
    connect(m_applet, SIGNAL(geometryChanged()), this, SLOT(updateGeometry()));
    connect(this, SIGNAL(geometryChanged()), m_applet, SLOT(resizeSelf()));
    //connect(m_applet, SIGNAL(hideEvent()), this, SLOT(close()));

    updateGeometry();
    QRectF curSceneRect(pos().x(), pos().y(), size().width(), size().height());
    /*
    std::cout << "TEST: " << curSceneRect.x() << ":" << curSceneRect.y() << "; " << curSceneRect.width() << "x" << curSceneRect.height() << ";" << std::endl;
    setSceneRect(0, 0, curSceneRect.width() - curSceneRect.x(), curSceneRect.height() - curSceneRect.y());
    */
   
}

SingleView::~SingleView()
{
    m_containment->destroy(false);
}

void SingleView::dragEnterEvent(QDragEnterEvent *event)
{
  event->accept();
}

void SingleView::dragMoveEvent(QDragMoveEvent *event)
{
  event->accept();
}

void SingleView::dropEvent(QDropEvent *event)
{
  event->accept();
}

void SingleView::setContainment(Plasma::Containment *c)
{
    if (m_containment) {
        disconnect(m_containment, 0, this, 0);
    }

    m_containment = c;
    updateGeometry();
}


void SingleView::resizeEvent(QResizeEvent *event)
{
    Q_UNUSED(event)
    updateGeometry();
    emit geometryChanged();
}

void SingleView::hideEvent(QHideEvent *event)
{
    Q_UNUSED(event)

      /*
    if (m_applet) {
        KConfigGroup dummy;
        m_containment->save(dummy);
        emit storeApplet(m_applet);
        m_applet = 0;
    }

    deleteLater();
      */
}

void SingleView::toggleWindow()
{
  if(isVisible())
    hideWindow();
  else
    showWindow();
  
  //return isVisible();
}

void SingleView::hideWindow()
{
  hide();
  emit hiden();
}

void SingleView::showWindow()
{
  if(m_firstShow)
    {
      QDesktopWidget *desktopWidget = m_application->desktop();
      QRect screenRect = desktopWidget->screenGeometry(desktopWidget->primaryScreen());

      Q_UNUSED(screenRect);
      
      /*
      kDebug() << "IS VIRTUAL: " << desktopWidget->isVirtualDesktop();
      kDebug() << "PRIMARY SCREEN: " << desktopWidget->primaryScreen();
      kDebug() << "TOTAL SCREENS: " << desktopWidget->screenCount();
      kDebug() << "NUM SCREENS: " << desktopWidget->numScreens();
      kDebug() << "SCREEN 0 GEOMETRY: " << desktopWidget->screenGeometry(0);
      kDebug() << "SCREEN 1 GEOMETRY: " << desktopWidget->screenGeometry(1);
      kDebug() << "WORKAREA: " << KWindowSystem::workArea();
      kDebug() << "WORKAREA1: " << KWindowSystem::workArea(1);
      kDebug() << "WORKAREA2: " << KWindowSystem::workArea(2);
      */

      //setGeometry(screenRect);

      reposition();
      
      m_firstShow = false;
    }

  reposition();

  //KWindowSystem::setOnDesktop(winId(), KWindowSystem::currentDesktop());

  updateGeometry();

  //emit m_containment->proxy->show();
  show();
  activateWindow();
  raise();

  QRectF curSceneRect = sceneRect();
  setSceneRect(0, 0, curSceneRect.width() - curSceneRect.x(), curSceneRect.height() - curSceneRect.y());
  emit shown();
}

void SingleView::reposition()
{
  // Checking for multimonitor setup

  QDesktopWidget *desktopWidget = m_application->desktop();

  Display *xDisplay = XOpenDisplay(NULL);
  int xScreen = DefaultScreen(xDisplay);
  Window xRoot = RootWindow(xDisplay, xScreen);
  
  int topMargin = 10;
  int bottomMargin = 10;
  int leftMargin = 10;
  int rightMargin = 10;

  int panelMargin = 48;

  /*
  kDebug() << "XRANDR QUERY";
  kDebug() << "SCREEN COUNT: " << ScreenCount(xDisplay);
  kDebug() << "DEFAULT SCREEN: " << DefaultScreen(xDisplay);
  kDebug() << "XRROUTPUTPRIMARY: " << XRRGetOutputPrimary(xDisplay, xRoot);
  */

  XRRScreenResources *xResources = XRRGetScreenResourcesCurrent(xDisplay, xRoot);
  RROutput xPrimaryOutput = XRRGetOutputPrimary(xDisplay, xRoot);

  /*
  for(int i = 0; i < sizesCount; i++)
    {
      kDebug() << "SIZE " << i << ": (" << sizes[i].width << "x" << sizes[i].height << ", " << sizes[i].mwidth << "x" << sizes[i].mheight << ")";
    }
  */
  
  if(desktopWidget->isVirtualDesktop() && desktopWidget->screenCount() > 1) // Xinerama
    {
      kDebug() << "Xinerama detected.";
      QRect primaryScreenGeom = desktopWidget->screenGeometry(desktopWidget->primaryScreen());

      kDebug() << "GEOMETRY: " << primaryScreenGeom;
      
      resize(primaryScreenGeom.width() - leftMargin - rightMargin, primaryScreenGeom.height() - topMargin - bottomMargin - panelMargin);
      move(primaryScreenGeom.x() + leftMargin, primaryScreenGeom.y() + topMargin);
    }
  /*
  else if(xResources->noutput > 1) // XRandr
    {
      int sizesCount = 0;
      XRRScreenSize *sizes = XRRSizes(xDisplay, xScreen, &sizesCount);

      kDebug() << "XRandr detected.";
      int defaultScreen = DefaultScreen(xDisplay);
    }
  */
  else if(ScreenCount(xDisplay) > 1)
    {
      kDebug() << "XRandr detected.";

      XRROutputInfo *xPrimaryOutputInfo = XRRGetOutputInfo(xDisplay, xResources, xPrimaryOutput);
      XRRCrtcInfo *xPrimaryOutputCrtcInfo = XRRGetCrtcInfo(xDisplay, xResources, xPrimaryOutputInfo->crtc);

      kDebug() << "CRTC GEOMETRY: " << xPrimaryOutputCrtcInfo->width << "x" << xPrimaryOutputCrtcInfo->height << "+" << xPrimaryOutputCrtcInfo->x << "+" << xPrimaryOutputCrtcInfo->y;

      QRect primaryScreenGeom;

      primaryScreenGeom.setWidth(xPrimaryOutputCrtcInfo->width);
      primaryScreenGeom.setHeight(xPrimaryOutputCrtcInfo->height);
      primaryScreenGeom.setX(xPrimaryOutputCrtcInfo->x);
      primaryScreenGeom.setY(xPrimaryOutputCrtcInfo->y);

      resize(primaryScreenGeom.width() - leftMargin - rightMargin, primaryScreenGeom.height() - topMargin - bottomMargin - panelMargin);
      move(primaryScreenGeom.x() + leftMargin, primaryScreenGeom.y() + topMargin);
      
    }
  else // Single screen
    {  
      QRect workArea = KWindowSystem::workArea();
      kDebug() << "Got Work Area: " << workArea;

      resize(workArea.width() - leftMargin - rightMargin, workArea.height() - topMargin - bottomMargin);
      move(workArea.x() + leftMargin, workArea.y() + topMargin);
    }
  
}

Plasma::Applet *SingleView::applet()
{
    return m_applet;
}

Plasma::Location SingleView::location() const
{
    return m_containment->location();
}

Plasma::FormFactor SingleView::formFactor() const
{
    return m_containment->formFactor();
}

void SingleView::updateGeometry()
{
    if (!m_containment) {
        return;
    }

    //kDebug() << "New applet geometry is" << m_applet->geometry();

    if (m_applet && m_applet->size().toSize() != size()) {
        if (m_applet) {
            m_applet->resize(size());
        }

        setSceneRect(m_applet->sceneBoundingRect());

    }

    // Update background
    m_background->resizeFrame(size());
    


    // if ((windowFlags() & Qt::FramelessWindowHint) &&
    //         applet()->backgroundHints() != Plasma::Applet::NoBackground) {

      if(KWindowSystem::compositingActive())
        {
          // TODO: Use the background's mask for blur
          QRegion mask;
          mask += QRect(QPoint(), size());
          //mask = m_background->mask();

          //updateMask();
          
          Plasma::WindowEffects::enableBlurBehind(winId(), true, mask);
          Plasma::WindowEffects::overrideShadow(winId(), true);
        }
      else
        {
          //QTimer::singleShot(0, this, SLOT(updateSnapshot()));
          updateMask();
        };
    // }
    
}

void SingleView::drawBackground(QPainter* p, const QRectF& rect) {

  Q_UNUSED(p);
  Q_UNUSED(rect);
 
  
  //QPainter::CompositionMode c = p->compositionMode();
  //p->setCompositionMode(QPainter::CompositionMode_Source);
  //p->fillRect(rect, Qt::transparent);
  //p->setCompositionMode(c);

  //p->setClipping(true);
  //p->setClipRegion(m_applet->boundingRegion(m_applet->sceneTransform()));
  //p->setClipRect(QRect(0, 0, 100, 100));
  //QPainterPath ppath = m_applet->opaqueArea();
  //p->setClipPath(ppath);

  //p->fillRect(rect, QColor(255, 0, 255, 255));

};

void SingleView::updateSnapshot()
{
  /*
  m_appletSnapshot = QPixmap::grabWidget(this);
  QBitmap mask = m_appletSnapshot.createMaskFromColor(QColor(255, 0, 255, 255));
  m_appletSnapshot.setMask(mask);
  m_appletSnapshot.save("blabla-test.png");
  
  QApplication::activeWindow()->setMask(m_appletSnapshot.mask());
  */
}

void SingleView::updateMask()
{
  setMask(m_background->mask());
}

bool SingleView::event(QEvent *event)
{
  /*
  kDebug() << "EVENT: " << event->type();
  if(event->type() == QEvent::ApplicationDeactivate)
    {
      QMetaObject::invokeMethod(static_cast<QObject*>(QApplication::activeWindow()), "hideWindow");
    }
  */
  if (event->type() == QEvent::Paint) {
    QPainter p(this);
    p.setCompositionMode(QPainter::CompositionMode_Source);
    p.fillRect(rect(), Qt::transparent);
  }

  return QGraphicsView::event(event);
}

void SingleView::paintEvent(QPaintEvent *e)
{
  
  QPainter painter(viewport());
  //p.setRenderHint(QPainter::Antialiasing);
  //p.setClipRect(e->rect());

  m_background->paintFrame(&painter);
  
  QGraphicsView::paintEvent(e);
}

bool SingleView::focusNextPrevChild(bool next)
{

  /*
    QGraphicsItem *target;
    QGraphicsItem *current;

    if( scene()->focusItem() )
    {
      //target = qgraphicsitem_cast<QGraphicsPolygonItem*>( scene()->focusItem() );
      target = scene()->focusItem();

        bool is_focus_next=false;
        foreach( QGraphicsItem *item, scene()->items() )
        {
          //current = qgraphicsitem_cast<QGraphicsPolygonItem*>( item );
          current = item;

  // set focus for next before selected
            if( current && is_focus_next )
            {
                item->setFocus( Qt::MouseFocusReason );
                return true;
            }

  // searching for selected item 
            if( current && current == target )
            {
                is_focus_next = true;
            }
        }

    }
  */

  return QGraphicsView::focusNextPrevChild(next);
}

bool SingleView::focusNextChild()
{
  kDebug() << "focusNextChild() called!!!";
  return QGraphicsView::focusNextChild();
}

bool SingleView::focusPreviousChild()
{
  kDebug() << "focusPreviousChild() called!!!";
  return QGraphicsView::focusPreviousChild();
}

#include "singleview.moc"

