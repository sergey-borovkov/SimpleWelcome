#!/bin/bash

grep -q ROSA /etc/mandriva-release && exit 0 || exit 1
