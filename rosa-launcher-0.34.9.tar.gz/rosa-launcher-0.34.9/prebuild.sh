#!/bin/bash

if [ x$1 != "x" ]; then
  echo $1 >version.txt
fi

VERSION=`cat version.txt`

for tmpl in *.tmpl; do
  sed -e "s|%version%|$VERSION|" $tmpl >`echo $tmpl | sed -e 's|\.tmpl$||'`
done
